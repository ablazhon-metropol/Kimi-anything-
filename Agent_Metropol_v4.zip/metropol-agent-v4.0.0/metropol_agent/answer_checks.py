"""Local clock, safe map search URLs and post-generation consistency checks."""
import re
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from urllib.parse import urlencode

MINSK = ZoneInfo('Europe/Minsk')
DAYS = ('понедельник','вторник','среда','четверг','пятница','суббота','воскресенье')
CITIES = {'минск':'Europe/Minsk','москв':'Europe/Moscow','берлин':'Europe/Berlin','лондон':'Europe/London','дуба':'Asia/Dubai'}

def clock_context(query='', current=None):
    current = current or datetime.now(MINSK)
    zone = next((z for city,z in CITIES.items() if city in query.lower()), 'Europe/Minsk')
    local = current.astimezone(ZoneInfo(zone))
    result = f'Текущее серверное время: {local:%d.%m.%Y %H:%M}, {DAYS[local.weekday()]}, часовой пояс {zone}. Это источник «сегодня», а не даты из истории. '
    for label, days in [('завтра',1),('послезавтра',2),('через неделю',7),('через две недели',14)]:
        result += f'{label}: {local + timedelta(days=days):%d.%m.%Y}. '
    for n in re.findall(r'через\s+(\d{1,3})\s+д', query.lower()):
        result += f'Через {n} дней: {local + timedelta(days=int(n)):%d.%m.%Y}. '
    return result + 'Гипотетические даты клиента рассматривай отдельно. Другие часовые пояса уточняй, не угадывай. Расчёт дат не является проверкой расписания.'

def clock_answer(query, current=None):
    q = query.lower().strip(' ?.!')
    if re.fullmatch(r'(какая сегодня дата|какое сегодня число|какой сегодня день(?: недели)?|который час(?: в .+)?|сколько сейчас времени(?: в .+)?|какая дата сегодня)',q):
        if ' в ' in q and not any(city in q for city in CITIES):
            return 'Уточните часовой пояс этого города (например, Europe/Paris). По умолчанию ориентируюсь на Минск.'
        return clock_context(query,current).split(' Это источник')[0]
    return None

def map_answer(query, history):
    q = query.lower()
    if re.search(r'банковск|кредитн\w* карт|оплат\w* карт',q): return None
    prior_in = [m.get('text','') for m in history if m.get('direction') == 'in']
    map_intent = bool(re.search(r'карт[аеуы]|маршрут|как (?:к вам )?(?:доехать|проехать|добраться)',q))
    if q.strip(' ?!') in {'где','ссылка','где ссылка','пришли ссылку','пришлите ссылку'}:
        map_intent = any(re.search(r'карт[аеуы]|маршрут',m.get('text','').lower()) for m in history[-6:])
    if any(city in q for city in CITIES) and any('уточните город' in m.get('text','').lower() for m in history[-2:]):
        map_intent=True
    if not map_intent:
        return None
    context = ' '.join((prior_in[-5:] + [query]))[-2200:]
    lower = context.lower()
    addresses_in_context = re.findall(r'(?:проспект\w*|пр-т|улиц\w*|ул\.)\s+[А-Яа-яA-Za-z\- ]{2,65},?\s+\d+[А-Яа-яA-Za-z]?', context)
    own = bool(re.search(r'метропол|горецкого|мазурова|к вам|ваши площад', q)) or (not addresses_in_context and bool(re.search(r'метропол|горецкого|мазурова|к вам|ваши площад',lower)))
    if own:
        addresses = []
        if 'мазуров' not in lower or 'горецкого' in lower: addresses.append('Минск, улица Горецкого, 6А, Метрополь Авто')
        if 'горецкого' not in lower or 'мазуров' in lower: addresses.append('Минск, улица Мазурова, 1, Метрополь Авто')
    else:
        found = re.findall(r'(?:проспект\w*|пр-т|улиц\w*|ул\.)\s+[А-Яа-яA-Za-z\- ]{2,65},?\s+\d+[А-Яа-яA-Za-z]?', context)
        if not found:
            return 'Напишите город и адрес или название места — пришлю ссылку поиска на карте.'
        cities = re.findall(r'Минск\w*|Москв\w*|Берлин\w*|Лондон\w*|Дуба\w*', context, re.I)
        if not cities:
            return 'Уточните город для этого адреса — тогда пришлю поиск на карте.'
        addresses = [cities[-1] + ', ' + found[-1]]
        if 'кафе' in lower: addresses[0] = 'кафе рядом с ' + addresses[0]
    return '\n\n'.join('Поиск на карте: ' + a + '\nhttps://www.google.com/maps/search/?' + urlencode({'api':'1','query':a}) for a in addresses)

def check_answer(text, allowed, exact=False):
    from .conversation import bound_links
    text = bound_links(text, allowed)
    # Remove empty Markdown labels left after URL filtering.
    text = re.sub(r'\[([^\]]*)\]\(\s*\)', r'\1', text)
    sentences = re.split(r'(?<=[.!?])(?=\s)|(?=\n)', text)
    safe = []
    for part in sentences:
        if re.search(r'\b(?:передал[аи]?|передаю|передам|переключил|соединил|уведомил|свяжемся|уточню)\b',part,re.I):
            safe.append('Чтобы передать обращение сотруднику, напишите «позови менеджера».')
        elif re.search(r'есть в наличии|имеется в наличии|точно есть|есть на (?:нашей|наших) площад',part,re.I):
            safe.append('Подходящие карточки найдены в сохранённом каталоге.' if exact else 'Подтверждения наличия у меня сейчас нет.')
        elif exact and re.search(r'не вижу|не наш[её]л|не найден',part,re.I) and re.search(r'карточк|модел|автомобил|каталог',part,re.I):
            safe.append('Подходящие карточки найдены в сохранённом каталоге.')
        else:
            safe.append(part)
    result = ''.join(safe).strip()
    if not re.search(r'https://',result) and re.search(r'вот (?:ссылк|карт)|(?:ссылк\w*|карт\w*)\s*:',result,re.I):
        result = 'Ссылку не удалось подготовить. Уточните, какую карточку или какой адрес на карте нужно показать.'
    return result or 'Не удалось подготовить ответ. Уточните, пожалуйста, ваш вопрос.'
