"""Resolve short vehicle choices before price lookup. Never infer stock or price."""
import re
from .catalog_selection import words, mentioned_brands
from .conversation import normalized, simple_price
from .credit import payment_request

FILLER=words('давай давайте беру берём берем выберу выбираю выбрал выбираем остановимся на этот эту это тот ту его ее вариант автомобиль машину модель мне нам ну тогда лучше нужен нужна нужны хочу интересует пожалуйста')
PRONOUNS={'беру этот','беру эту','давай этот','давай эту','выбираю этот','выбираю эту','берем этот','берем эту','давай его','давай ее','выбираю его','этот вариант','эту машину'}

def resolve(query,pref,prices,catalog):
    q=normalized(query)
    lookup_rows=catalog+[{'brand':r['label'].split()[0]} for r in prices if r['label'].split()]
    explicit=mentioned_brands(lookup_rows,query)
    selected=next((r for r in prices if r['id']==pref.get('commerce',{}).get('price_id')),None)
    brand=pref.get('brand') or (selected['label'].split()[0] if selected else '')
    if q in PRONOUNS:
        shown=pref.get('shown',[])
        if len(shown)>1:
            return query,False,'Какой вариант выбираете? Напишите модель или пришлите ссылку на конкретную машину.'
        if len(shown)==1:
            card=next((r for r in catalog if r['url']==shown[0]),None)
            if card: return card['brand']+' '+card['model_name'],True,''
        if selected and (not brand or words(brand)<=words(selected['label'])):
            return selected['label'],True,''
        return query,False,'Какую модель выбираете? Напишите название или пришлите ссылку на машину.'
    meaningful=words(query)-FILLER
    names=set().union(*(words(r['label']+' '+r['matcher']) for r in prices)) if prices else set()
    for r in catalog: names |= words(r['brand']+' '+r['model_name'])
    codes={w for w in meaningful if re.fullmatch(r'[a-z]{1,3}\d{1,4}',w)}
    choice=bool(meaningful-explicit and meaningful<=names|codes)
    if choice:
        query=' '.join(sorted(meaningful))
    commercial=choice or simple_price(query) or payment_request(query)
    if commercial and not explicit and (codes or (choice and meaningful)):
        if brand:
            query=brand+' '+query
        elif codes:
            return query,False,'Уточните марку автомобиля для '+', '.join(sorted(codes)).upper()+'.'
    return query,choice,''
