"""Small structured buying preferences, persisted separately for every conversation."""
import json
import re
from .catalog_selection import words, model_core, select, BRANDS, brand_only
from .db import now

class Preferences:
    def __init__(self, db): self.db = db

    def get(self, scope):
        row = self.db._execute('SELECT body FROM customer_preferences WHERE scope=%s',(scope,),'one')
        return json.loads(self.db.cipher.decrypt(row['body'])) if row else {}

    def save(self, scope, body):
        self.db._execute('INSERT INTO customer_preferences(scope,body,updated_at) VALUES(%s,%s,%s) ON CONFLICT(scope) DO UPDATE SET body=excluded.body,updated_at=excluded.updated_at',
            (scope,self.db.cipher.encrypt(json.dumps(body,ensure_ascii=False)),now()))

    def clear(self, scope):
        self.db._execute('DELETE FROM customer_preferences WHERE scope=%s',(scope,))

    def update(self, scope, query, rows):
        p = self.get(scope)
        q = words(query)
        low = query.lower()
        if re.search(r'сбросить (?:пожелания|подбор)|забудь (?:подбор|пожелания)',low):
            self.clear(scope); return {}
        known_brands={r['brand'] for r in rows} | {b.title() for b in BRANDS.values()} | {'Changan','Geely','BMW','BYD','Chery','Exeed','Zeekr','Voyah','Li'}
        brands = sorted({b.lower():b for b in known_brands if words(b) <= q and words(b)}.values())
        if len(brands) == 1:
            if p.get('brand') != brands[0] or brand_only(rows,query):
                p.pop('model',None); p.pop('year',None); p.pop('min_year',None)
                p.pop('generation',None); p.pop('trim',None)
            p['brand'] = brands[0]
        models = { ' '.join(sorted(model_core(r))) for r in rows if model_core(r) and model_core(r) <= q and (not brands or r['brand'] in brands)}
        if len(models) == 1:
            model = models.pop()
            if p.get('model') != model:
                p.pop('year',None); p.pop('min_year',None)
                p.pop('generation',None); p.pop('trim',None)
            p['model'] = model
        codes={w for w in q if re.fullmatch(r'[a-zа-я]{1,3}\d{1,4}',w) or (re.fullmatch(r'\d{3,4}',w) and not re.fullmatch(r'(19|20)\d{2}',w))}
        if len(codes)==1 and not re.search(r'бюджет|тысяч|byn|руб|доллар|usd',low):
            candidate=codes.pop()
            if p.get('model')!=candidate:
                p.pop('year',None); p.pop('min_year',None)
                p.pop('generation',None); p.pop('trim',None)
            p['model']=candidate
        generation=q & {'i','ii','iii','iv'}
        if len(generation)==1 and p.get('model'): p['generation']=generation.pop()
        trim=q & {'plus','pro','max','ultra'}
        if trim and p.get('model'): p['trim']=' '.join(sorted(trim))
        if re.search(r'любого года|любой год|без ограничений по году',low):
            p.pop('year',None); p.pop('min_year',None)
        year = re.search(r'\b(19\d{2}|20\d{2})\b',low)
        if year and (p.get('model') or brands):
            p['year']=int(year[1]); p.pop('min_year',None)
        budget = re.search(r'(?:до|бюджет)\s*(\d[\d ]*)\s*(тыс\w*)?\s*(byn|руб\w*|белорусских рублей|usd|доллар\w*|\$|eur|евро)',low)
        if budget:
            p['budget']=int(budget[1].replace(' ',''))*(1000 if budget[2] else 1)
            p['currency']='BYN' if budget[3].startswith(('byn','руб','бел')) else ('EUR' if budget[3] in {'eur','евро'} else 'USD')
        if re.search(r'без кредита|не (?:хочу|нужен) кредит',low): p['finance']='без кредита'
        elif 'кредит' in low: p['finance']='кредит'
        elif 'лизинг' in low: p['finance']='лизинг'
        if re.search(r'без обмена|не (?:нужен|хочу) обмен',low): p['trade_in']=False
        elif re.search(r'обмен|трейд|trade.in',low): p['trade_in']=True
        if 'дешевле' in low and p.get('last_prices'):
            p['budget']=min(p['last_prices'])-1; p['currency']='BYN'
        if 'поновее' in low:
            base = p.get('year') or (max(p.get('last_years',[])) if p.get('last_years') else None)
            if base: p['min_year']=base+1; p.pop('year',None)
        if p: self.save(scope,p)
        return p

    def query(self, original, p):
        if not p or ' или ' in original.lower() or not re.search(r'покаж|подбер|другие вариант|дешевле|поновее|такую|такой|варианты|есть|ищу|интересует',original.lower()): return original
        parts = [original, p.get('brand',''), p.get('model','')]
        parts.extend([p.get('generation',''),p.get('trim','')])
        if p.get('year') and not re.search(r'\b(?:19|20)\d{2}\b',original): parts.append(str(p['year']))
        if p.get('currency') == 'BYN' and p.get('budget'): parts.append(f"до {p['budget']} BYN")
        return ' '.join(parts)

    def pick(self, scope, query, rows, history=()):
        p=self.update(scope,query,rows)
        effective=self.query(query,p)
        if p.get('min_year') and re.search(r'поновее|подбер|покаж|другие вариант',query.lower()):
            rows=[r for r in rows if int(r.get('year') or 0)>=p['min_year']]
        more = bool(re.search(r'другие варианты|следующие|ещ[её] варианты',query.lower()))
        # Context is stable for paging; filters changed by a new question reset the shown set.
        signature = json.dumps({k:p.get(k) for k in ('brand','model','generation','trim','year','min_year','budget','currency')},sort_keys=True)
        excluded=p.get('shown',[]) if more and p.get('signature')==signature else []
        result=select(rows,effective,exclude_urls=set(excluded))
        p['_page_excluded']=excluded
        p['_page_signature']=signature
        return effective,p,result

    def shown(self,scope,p,rows):
        p['shown']=(p.pop('_page_excluded',[]) + [r['url'] for r in rows])[-300:]
        p['last_prices']=[int(r['price_byn']) for r in rows if r.get('price_byn')]
        p['last_years']=[int(r['year']) for r in rows if r.get('year')]
        p['signature']=p.pop('_page_signature','')
        self.save(scope,p)

    @staticmethod
    def context(p):
        return 'Пожелания клиента (не спрашивай повторно; новые слова клиента важнее): '+json.dumps({k:v for k,v in p.items() if k in {'brand','model','generation','trim','year','min_year','budget','currency','finance','trade_in'}},ensure_ascii=False)
