from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path


CONTACTS = (
    "Горецкого, 6А — +375 29 678-22-55; "
    "Мазурова, 1, БЦ «Камелот» — +375 44 722-22-55. "
    "Работаем ежедневно с 9:00 до 20:00 и до последнего клиента."
)


@dataclass
class LocalAnswer:
    text: str
    intent: str
    priority: int = 50


def deterministic_answer(text: str) -> LocalAnswer | None:
    q = text.lower().replace("ё", "е")
    if any(x in q for x in ("адрес", "где вы", "находит", "как проехать", "локац")):
        return LocalAnswer(f"У нас две площадки в Минске: {CONTACTS} Куда вам удобнее приехать?", "contacts")
    if any(x in q for x in ("телефон", "номер", "позвон")):
        return LocalAnswer(f"Контакты площадок: {CONTACTS} На какую площадку вам удобнее позвонить?", "callback", 30)
    if any(x in q for x in ("график", "до сколь", "работаете", "время работы")):
        return LocalAnswer("Работаем ежедневно с 9:00 до 20:00 и до последнего клиента. Поздний приезд лучше заранее подтвердить по телефону. На какую площадку планируете приехать?", "schedule")
    if "первоначаль" in q or "первый взнос" in q or "без взнос" in q:
        return LocalAnswer("Возможен кредит до 10 лет без первоначального взноса. По лизингу тоже бывают варианты без взноса — условия уточнит менеджер. Приезжайте, подберём программу.", "financing")
    if "лизинг" in q:
        return LocalAnswer("Лизинг обычно оформляют на 5–7 лет, возможен срок до 10 лет. Первый взнос может не потребоваться, а если он есть — это может улучшить условия. Точный расчёт сделает менеджер на площадке.", "financing")
    if "кредит" in q or "рассроч" in q:
        return LocalAnswer("Подберём выгодные условия под ваш бюджет: возможен кредит до 10 лет без первоначального взноса, также есть лизинг и рассрочка. Точные условия рассчитает специалист на площадке.", "financing")
    if any(x in q for x in ("тест драйв", "тест-драйв", "диагност", "проверить авто")):
        return LocalAnswer("Машины тщательно отбираем и проверяем перед продажей. Тест-драйв доступен на любом авто, дополнительная диагностика — по вашему запросу.", "visit")
    if "гарант" in q:
        return LocalAnswer("На любой автомобиль можно оформить дополнительную платную гарантию: обычно до года, в отдельных случаях до трёх лет. Полное покрытие и условия специалист покажет на площадке.", "warranty")
    if any(x in q for x in ("трейд", "trade", "выкуп", "продать машину")):
        return LocalAnswer("Доступны Trade-in и выкуп. Менеджер по всем вопросам оценит ваш автомобиль и предложит варианты на площадке. Напишите марку, модель и год — подготовим обращение.", "tradein", 20)
    if any(x in q for x in ("жалоб", "обман", "претенз", "ужас", "руководител")):
        return LocalAnswer("Понимаю вас. Зафиксирую обращение и передам руководителю утром либо сразу в рабочее время. Напишите, пожалуйста, коротко суть ситуации и удобный номер для связи.", "complaint", 10)
    return None


def classify_complexity(text: str) -> str:
    q = text.lower()
    risky = ("жалоб", "суд", "юрист", "обман", "угроз", "персональн", "договор", "ставк", "одобр")
    return "sol" if any(word in q for word in risky) else "luna"


class KnowledgeBase:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.sections: list[tuple[str, str]] = []
        self._mtime_ns = -1
        self.reload()

    def reload(self) -> None:
        if not self.path.exists():
            self.sections = []
            self._mtime_ns = -1
            return
        text = self.path.read_text(encoding="utf-8")
        self.sections = self._markdown_chunks(text)
        self._mtime_ns = self.path.stat().st_mtime_ns

    @classmethod
    def _markdown_chunks(cls, text: str, target: int = 1800) -> list[tuple[str, str]]:
        """Index subsections instead of truncating a very long top-level section."""
        rows: list[tuple[str, str]] = []
        parent = "Общие сведения"
        title = parent
        body: list[str] = []

        def flush() -> None:
            raw = "\n".join(body).strip()
            if not raw:
                return
            paragraphs = [p.strip() for p in re.split(r"\n\s*\n", raw) if p.strip()]
            current = ""
            part = 1
            for paragraph in paragraphs:
                pieces = [paragraph[i:i + target] for i in range(0, len(paragraph), target)] or [""]
                for piece in pieces:
                    candidate = piece if not current else current + "\n\n" + piece
                    if current and len(candidate) > target:
                        suffix = f" · часть {part}" if part > 1 else ""
                        rows.append((title + suffix, current))
                        part += 1
                        current = piece
                    else:
                        current = candidate
            if current:
                suffix = f" · часть {part}" if part > 1 else ""
                rows.append((title + suffix, current))

        for line in text.splitlines():
            heading = re.match(r"^(#{2,4})\s+(.+?)\s*$", line)
            if not heading:
                body.append(line)
                continue
            flush()
            body = []
            level, name = len(heading[1]), heading[2].strip()
            if level == 2:
                parent = name
                title = parent
            else:
                title = parent + " → " + name
        flush()
        return rows

    def reload_if_changed(self) -> None:
        mtime = self.path.stat().st_mtime_ns if self.path.exists() else -1
        if mtime != self._mtime_ns:
            self.reload()

    @staticmethod
    def _tokens(text: str) -> set[str]:
        return set(KnowledgeBase._token_list(text))

    @staticmethod
    def _token_list(text: str) -> list[str]:
        aliases = {
            "чанань": "changan", "чанган": "changan", "джили": "geely",
            "бмв": "bmw", "мерседес": "mercedes", "шевроле": "chevrolet",
            "эквинокс": "equinox", "трейдин": "tradein", "трейд": "tradein",
        }
        stop = {"это", "как", "для", "или", "при", "что", "все", "так", "уже", "еще",
                "его", "она", "они", "мы", "вы", "ваш", "наш", "быть", "есть", "если", "после"}
        result = []
        for raw in re.findall(r"[а-яa-z0-9]{2,}", text.lower().replace("ё", "е")):
            word = aliases.get(raw, raw)
            if word in stop:
                continue
            # Light Russian stemming improves matches such as гарантия/гарантии.
            if re.fullmatch(r"[а-я]+", word) and len(word) > 5:
                word = re.sub(r"(иями|ями|ами|ого|ему|ими|ый|ий|ая|ое|ие|ые|ов|ев|ам|ям|ах|ях|ом|ем|ы|и|а|я|у|ю|е)$", "", word)
            result.append(word)
        return result

    def search(self, query: str, limit: int = 3, max_chars: int = 4200) -> list[str]:
        self.reload_if_changed()
        query_list = self._token_list(query)
        q = set(query_list)
        if not q:
            return []
        documents = [(title, body, Counter(self._token_list(title + " " + body))) for title, body in self.sections]
        total_docs = max(1, len(documents))
        frequency = {token: sum(1 for _, _, counts in documents if token in counts) for token in q}
        normalized_query = " ".join(re.findall(r"[а-яa-z0-9]+", query.lower().replace("ё", "е")))
        ranked = []
        for index, (title, body, counts) in enumerate(documents):
            title_tokens = self._tokens(title)
            matched = q & set(counts)
            if not matched:
                continue
            score = 0.0
            for token in matched:
                inverse = math.log((total_docs + 1) / (frequency[token] + 1)) + 1
                score += inverse * (1 + min(counts[token], 3) * 0.2)
                if token in title_tokens:
                    score += inverse * 2.5
            coverage = len(matched) / len(q)
            score += coverage * 4
            searchable = " ".join(re.findall(r"[а-яa-z0-9]+", (title + " " + body).lower().replace("ё", "е")))
            if len(normalized_query) >= 6 and normalized_query in searchable:
                score += 8
            ranked.append((score, -index, title, body))
        ranked.sort(reverse=True)
        result, total = [], 0
        for _, _, title, body in ranked[:limit]:
            piece = f"## {title}\n{body}"
            if total + len(piece) > max_chars:
                piece = piece[: max(0, max_chars - total)]
            if piece:
                result.append(piece)
                total += len(piece)
        return result
