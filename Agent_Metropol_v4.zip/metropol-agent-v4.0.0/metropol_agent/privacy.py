from __future__ import annotations

from cryptography.fernet import Fernet, InvalidToken


class DataCipher:
    """Совместимое шифрование полей: старый открытый текст продолжает читаться."""

    prefix = "enc:v1:"

    def __init__(self, key: str = ""):
        self.enabled = bool(key)
        self.fernet = Fernet(key.encode("ascii")) if key else None

    def encrypt(self, value: str | None) -> str:
        text = str(value or "")
        if not self.fernet or not text or text.startswith(self.prefix):
            return text
        token = self.fernet.encrypt(text.encode("utf-8")).decode("ascii")
        return self.prefix + token

    def decrypt(self, value: str | None) -> str:
        text = str(value or "")
        if not text.startswith(self.prefix):
            return text
        if not self.fernet:
            return "[зашифровано]"
        try:
            return self.fernet.decrypt(text[len(self.prefix) :].encode("ascii")).decode("utf-8")
        except (InvalidToken, ValueError):
            return "[ошибка расшифровки]"
