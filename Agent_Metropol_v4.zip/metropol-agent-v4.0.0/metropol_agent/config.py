from __future__ import annotations

import os
from dataclasses import dataclass


def _bool(name: str, default: bool) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}


def _float(name: str, default: float) -> float:
    value = os.getenv(name, "").strip()
    return float(value) if value else default


def _int(name: str, default: int) -> int:
    value = os.getenv(name, "").strip()
    return int(value) if value else default


@dataclass(frozen=True)
class Settings:
    telegram_token: str
    webhook_secret: str
    public_base_url: str
    owner_id: int
    database_url: str
    openai_api_key: str
    luna_model: str
    sol_model: str
    fallback_models: tuple[str, ...]
    admin_token: str
    data_encryption_key: str
    global_mode: str
    quality_mode: str
    sol_enabled: bool
    history_messages: int
    history_chars: int
    knowledge_chunks: int
    knowledge_chars: int
    reasoning_effort: str
    max_output_tokens: int
    agent_max_rounds: int
    agent_max_tool_calls: int
    web_search_context_size: str
    second_pass_review: bool
    monthly_budget_usd: float
    luna_input_rate: float
    luna_output_rate: float
    sol_input_rate: float
    sol_output_rate: float
    message_retention_days: int
    audit_retention_days: int
    debounce_seconds: int
    max_job_attempts: int
    catalog_url: str
    port: int

    @classmethod
    def from_env(cls) -> "Settings":
        owner = os.getenv("OWNER_TELEGRAM_ID", "0").strip()
        mode = os.getenv("AGENT_GLOBAL_MODE", "auto").strip().lower()
        if mode not in {"auto", "approval", "human"}:
            raise ValueError("AGENT_GLOBAL_MODE must be auto, approval or human")
        quality = os.getenv("AGENT_QUALITY_MODE", "maximum").strip().lower()
        if quality not in {"maximum", "balanced", "economy"}:
            raise ValueError("AGENT_QUALITY_MODE must be maximum, balanced or economy")
        reasoning = os.getenv("OPENAI_REASONING_EFFORT", "medium").strip().lower()
        if reasoning not in {"none", "low", "medium", "high"}:
            raise ValueError("OPENAI_REASONING_EFFORT must be none, low, medium or high")
        web_context = os.getenv("WEB_SEARCH_CONTEXT_SIZE", "medium").strip().lower()
        if web_context not in {"low", "medium", "high"}:
            raise ValueError("WEB_SEARCH_CONTEXT_SIZE must be low, medium or high")
        return cls(
            telegram_token=os.getenv("TELEGRAM_BOT_TOKEN", "").strip(),
            webhook_secret=os.getenv("TELEGRAM_WEBHOOK_SECRET", "").strip(),
            public_base_url=os.getenv("PUBLIC_BASE_URL", "").strip().rstrip("/"),
            owner_id=int(owner or 0),
            database_url=os.getenv("DATABASE_URL", "sqlite:///data/metropol.db").strip(),
            openai_api_key=os.getenv("OPENAI_API_KEY", "").strip(),
            luna_model=os.getenv("OPENAI_LUNA_MODEL", "gpt-5.6-luna").strip(),
            sol_model=os.getenv("OPENAI_SOL_MODEL", "gpt-5.6-sol").strip(),
            fallback_models=tuple(
                model.strip()
                for model in os.getenv("OPENAI_FALLBACK_MODELS", "gpt-5.6-terra,gpt-5.6-luna").split(",")
                if model.strip()
            ),
            admin_token=os.getenv("ADMIN_TOKEN", "").strip(),
            data_encryption_key=os.getenv("DATA_ENCRYPTION_KEY", "").strip(),
            global_mode=mode,
            quality_mode=quality,
            sol_enabled=_bool("SOL_ENABLED", True),
            history_messages=max(12, min(60, _int("AGENT_HISTORY_MESSAGES", 30))),
            history_chars=max(3500, min(40000, _int("AGENT_HISTORY_CHARS", 16000))),
            knowledge_chunks=max(2, min(10, _int("AGENT_KNOWLEDGE_CHUNKS", 6))),
            knowledge_chars=max(3500, min(20000, _int("AGENT_KNOWLEDGE_CHARS", 10000))),
            reasoning_effort=reasoning,
            max_output_tokens=max(800, min(4000, _int("OPENAI_MAX_OUTPUT_TOKENS", 1800))),
            agent_max_rounds=max(6, min(12, _int("AGENT_MAX_ROUNDS", 8))),
            agent_max_tool_calls=max(8, min(20, _int("AGENT_MAX_TOOL_CALLS", 12))),
            web_search_context_size=web_context,
            second_pass_review=_bool("AGENT_SECOND_PASS_REVIEW", True),
            monthly_budget_usd=_float("MONTHLY_OPENAI_BUDGET_USD", 500.0),
            # Консервативные стандартные ставки. Их можно переопределить в Railway.
            luna_input_rate=_float("LUNA_INPUT_USD_PER_M", 0.20),
            luna_output_rate=_float("LUNA_OUTPUT_USD_PER_M", 1.20),
            sol_input_rate=_float("SOL_INPUT_USD_PER_M", 4.00),
            sol_output_rate=_float("SOL_OUTPUT_USD_PER_M", 20.00),
            message_retention_days=_int("MESSAGE_RETENTION_DAYS", 365),
            audit_retention_days=_int("AUDIT_RETENTION_DAYS", 180),
            debounce_seconds=max(0, min(2, _int("MESSAGE_DEBOUNCE_SECONDS", 1))),
            max_job_attempts=_int("MAX_JOB_ATTEMPTS", 5),
            catalog_url=os.getenv("CATALOG_URL", "https://metropol-auto.by/vehicles/").strip(),
            port=_int("PORT", 8080),
        )
