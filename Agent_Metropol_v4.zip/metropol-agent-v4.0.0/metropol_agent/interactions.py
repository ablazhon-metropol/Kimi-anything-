import json
import uuid
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from .db import now

class Sessions:
    def __init__(self,db): self.db=db

    def create(self,scope,body):
        token=uuid.uuid4().hex[:24]
        self.db._execute('INSERT INTO interaction_sessions(id,scope,body,created_at) VALUES(%s,%s,%s,%s)',
            (token,scope,self.db.cipher.encrypt(json.dumps(body,ensure_ascii=False)),now()))
        return token

    def get(self,token,scope=None):
        row=self.db._execute('SELECT * FROM interaction_sessions WHERE id=%s',(token,),'one')
        if not row or (scope is not None and row['scope']!=scope): return None
        if datetime.fromisoformat(row['created_at']) < datetime.now(timezone.utc)-timedelta(days=7): return None
        row['body']=json.loads(self.db.cipher.decrypt(row['body']))
        return row

    def update(self,token,body,status):
        self.db._execute('UPDATE interaction_sessions SET body=%s,status=%s WHERE id=%s',
            (self.db.cipher.encrypt(json.dumps(body,ensure_ascii=False)),status,token))

    def approve(self,token,owner):
        # Atomic approval: duplicate presses cannot create duplicate learned examples.
        with self.db.lock, self.db.connect() as conn:
            row=self.db._fetchone(conn,'SELECT * FROM interaction_sessions WHERE id=%s',(token,))
            if not row or row['scope']!=f'test:{owner}' or row['status']!='ready': return False
            body=json.loads(self.db.cipher.decrypt(row['body']))
            changed=conn.execute(self.db._sql("UPDATE interaction_sessions SET status='approved' WHERE id=%s AND status='ready'"),(token,))
            if changed.rowcount!=1: return False
            stamp=now()
            conn.execute(self.db._sql("INSERT INTO corrections(client_id,original_text,corrected_text,context,status,author_id,created_at,approved_at) VALUES(%s,%s,%s,%s,'approved',%s,%s,%s)"),
                (0,self.db.cipher.encrypt(body['query']),self.db.cipher.encrypt(body['correction']),self.db.cipher.encrypt(body['query']),str(owner),stamp,stamp))
            return True

def working_seconds(start,end):
    zone=ZoneInfo('Europe/Minsk')
    start=start.astimezone(zone); end=end.astimezone(zone)
    total=0.0
    day=start.replace(hour=0,minute=0,second=0,microsecond=0)
    while day<=end:
        total+=max(0,(min(end,day.replace(hour=21))-max(start,day.replace(hour=8))).total_seconds())
        day+=timedelta(days=1)
    return total

class Handoffs:
    def __init__(self,db,staff,owner): self.db,self.staff,self.owner=db,staff,owner

    def ensure(self,cid):
        row=self.db._execute('SELECT * FROM handoff_receipts WHERE client_id=%s',(cid,),'one')
        if row and row['status'] not in {'closed'}: return row
        request=uuid.uuid4().hex[:20]
        self.db._execute("INSERT INTO handoff_receipts(client_id,request_id,status,created_at) VALUES(%s,%s,'waiting',%s) ON CONFLICT(client_id) DO UPDATE SET request_id=excluded.request_id,status='waiting',notified_at=NULL,accepted_by=NULL,created_at=excluded.created_at",(cid,request,now()))
        return self.db._execute('SELECT * FROM handoff_receipts WHERE client_id=%s',(cid,),'one')

    def delivered(self,cid,request):
        self.db._execute("UPDATE handoff_receipts SET notified_at=%s,status='notified' WHERE client_id=%s AND request_id=%s AND status='waiting'",(now(),cid,request))

    def accept(self,cid,actor,request=None):
        if not self.staff.can_reply(actor,cid): return False
        row=self.db._execute('SELECT * FROM handoff_receipts WHERE client_id=%s',(cid,),'one')
        if not row or row['status']=='closed' or (request and row['request_id']!=request): return False
        self.db._execute("UPDATE handoff_receipts SET status='accepted',accepted_by=%s WHERE client_id=%s AND request_id=%s AND status!='closed'",(actor,cid,row['request_id']))
        return True

    def close(self,cid): self.db._execute("UPDATE handoff_receipts SET status='closed' WHERE client_id=%s",(cid,))

    def check(self):
        current=datetime.now(timezone.utc)
        if not 8<=current.astimezone(ZoneInfo('Europe/Minsk')).hour<21: return 0
        count=0
        for row in self.db._execute("SELECT * FROM handoff_receipts WHERE status='notified'",(),'all'):
            client=self.db.client_by_id(row['client_id'])
            if not client or client.get('do_not_contact') or client['mode']!='human': self.close(row['client_id']); continue
            if not row['notified_at'] or working_seconds(datetime.fromisoformat(row['notified_at']),current)<600: continue
            markup={'inline_keyboard':[[{'text':'Взял в работу','callback_data':f"take:{row['client_id']}:{row['request_id']}"}],
                [{'text':'Ответить клиенту','callback_data':f"humanreply:{row['client_id']}:0"}]]}
            self.db.enqueue_outbox(self.owner,f"Обращение клиента №{row['client_id']} не принято за 10 рабочих минут после доставки уведомления. Проверьте, кто сможет ответить.",markup,
                metadata={'handoff_escalation':row['client_id'],'handoff_request':row['request_id']},dedupe_key=f"escalation-{row['request_id']}")
            self.db._execute("UPDATE handoff_receipts SET status='escalated' WHERE client_id=%s AND request_id=%s AND status='notified'",(row['client_id'],row['request_id']))
            count+=1
        return count
