from __future__ import annotations

import logging
import time
from typing import Any

import httpx

log = logging.getLogger(__name__)


class TelegramAPI:
    def __init__(self, token: str):
        self.base = f"https://api.telegram.org/bot{token}"
        self.client = httpx.Client(timeout=httpx.Timeout(25.0, connect=10.0), trust_env=False)

    def call(self, method: str, payload: dict[str, Any]) -> dict:
        last_error = ""
        for attempt in range(1, 6):
            try:
                response = self.client.post(f"{self.base}/{method}", json=payload)
                data = response.json()
                if data.get("ok"):
                    return data
                retry_after = int((data.get("parameters") or {}).get("retry_after") or 0)
                last_error = f"HTTP {response.status_code}: {data}"
                if response.status_code == 429 or retry_after:
                    time.sleep(min(30, max(1, retry_after)))
                    continue
                if response.status_code >= 500:
                    time.sleep(min(8, 2 ** (attempt - 1)))
                    continue
                raise RuntimeError(f"Telegram {method}: {last_error}")
            except (httpx.TimeoutException, httpx.NetworkError) as exc:
                last_error = f"{type(exc).__name__}: {exc}"
                if attempt < 5:
                    time.sleep(min(8, 2 ** (attempt - 1)))
                    continue
        raise RuntimeError(f"Telegram {method} failed after retries: {last_error}")

    def send_message(self, chat_id: int | str, text: str, reply_markup: dict | None = None) -> dict:
        payload: dict[str, Any] = {"chat_id": chat_id, "text": text, "disable_web_page_preview": True}
        if reply_markup:
            payload["reply_markup"] = reply_markup
        return self.call("sendMessage", payload)

    def answer_callback(self, callback_id: str, text: str = "") -> None:
        self.call("answerCallbackQuery", {"callback_query_id": callback_id, "text": text})

    def set_webhook(self, url: str, secret: str) -> None:
        payload: dict[str, Any] = {
            "url": url,
            "allowed_updates": ["message", "callback_query"],
            "drop_pending_updates": False,
        }
        if secret:
            payload["secret_token"] = secret
        self.call("setWebhook", payload)

    def set_commands(self, owner_id: int) -> None:
        self.call(
            "setMyCommands",
            {"commands": [{"command": "start", "description": "Начать разговор с Агентом Метрополь"}]},
        )
        if owner_id:
            self.call(
                "setMyCommands",
                {
                    "scope": {"type": "chat", "chat_id": owner_id},
                    "commands": [
                        {"command": "start", "description": "Меню владельца"},
                        {"command": "menu", "description": "Меню владельца"},
                        {"command": "test", "description": "Тестировать агента как клиент"},
                        {"command": "staff", "description": "Сотрудники и ответственный"},
                        {"command": "catalog", "description": "Диагностика и проверка поиска"},
                        {"command": "rates", "description": "Курсы НБРБ: значения и дата"},
                        {"command": "stats", "description": "Статистика: наличие, курсы, расходы"},
                        {"command": "preferences", "description": "Пожелания покупателя в тесте"},
                        {"command": "feedback", "description": "Замечания и исправления теста"},
                        {"command": "testreset", "description": "Очистить тестовый разговор"},
                        {"command": "testoff", "description": "Выйти из теста"},
                        {"command": "prices", "description": "Изменить цены китайских авто"},
                        {"command": "panel", "description": "Панель управления"},
                        {"command": "status", "description": "Состояние агента"},
                        {"command": "clients", "description": "Последние клиенты"},
                        {"command": "queue", "description": "Ночная очередь"},
                        {"command": "costs", "description": "Токены и расходы"},
                    ],
                },
            )


def owner_keyboard(client_id: int, draft_id: int, base_url: str = "") -> dict:
    return {"inline_keyboard": [
        [
            {"text": "✅ Отправить", "callback_data": f"send:{client_id}:{draft_id}"},
            ({"text": "✏️ Исправить", "url": f"{base_url}/admin/drafts/{draft_id}"} if base_url else {"text": "✏️ Исправить", "callback_data": f"edit:{client_id}:{draft_id}"}),
        ],
        [
            {"text": "🚫 Не отправлять", "callback_data": f"drop:{client_id}:{draft_id}"},
            {"text": "👤 Передать", "callback_data": f"human:{client_id}:{draft_id}"},
        ],
        [{"text": "🤖 Включить автоответ", "callback_data": f"auto:{client_id}:{draft_id}"}],
    ]}
