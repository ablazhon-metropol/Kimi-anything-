import json

class Staff:
    def __init__(self, db, owner_id):
        self.db, self.owner = db, owner_id

    def active(self, telegram_id):
        return self.db._execute('SELECT * FROM staff WHERE telegram_id=%s AND active=1', (telegram_id,), 'one')

    def rows(self):
        return self.db._execute('SELECT * FROM staff WHERE active=1 ORDER BY name', (), 'all')

    def responsible(self, client_id):
        row = self.db._execute('SELECT telegram_id FROM staff_assignments WHERE client_id=%s', (client_id,), 'one')
        if row and (row['telegram_id'] == self.owner or self.active(row['telegram_id'])):
            return int(row['telegram_id'])
        primary = int(self.db.get_setting('primary_staff', str(self.owner)))
        target = primary if primary == self.owner or self.active(primary) else self.owner
        self.assign(client_id, target)
        return target

    def assign(self, client_id, target):
        if target != self.owner and not self.active(target):
            raise ValueError('Inactive employee')
        self.db._execute('INSERT INTO staff_assignments(client_id,telegram_id) VALUES(%s,%s) ON CONFLICT(client_id) DO UPDATE SET telegram_id=excluded.telegram_id', (client_id,target))

    def can_reply(self, actor, client_id):
        return actor == self.owner or bool(self.active(actor) and self.responsible(client_id) == actor)

    def register(self, telegram_id, name):
        self.db._execute('INSERT INTO staff(telegram_id,name,active) VALUES(%s,%s,1) ON CONFLICT(telegram_id) DO UPDATE SET name=excluded.name,active=1', (telegram_id,name[:150]))

    def remove(self, telegram_id):
        self.db._execute('UPDATE staff SET active=0 WHERE telegram_id=%s', (telegram_id,))
        self.db._execute('UPDATE staff_assignments SET telegram_id=%s WHERE telegram_id=%s', (self.owner,telegram_id))
        if self.db.get_setting('primary_staff') == str(telegram_id):
            self.db.set_setting('primary_staff',str(self.owner))
        self.db.set_setting(f'owner-reply-target-{telegram_id}','')

    def menu(self):
        primary = self.db.get_setting('primary_staff',str(self.owner))
        rows = [[{'text':'＋ Добавить сотрудника','callback_data':'staff:add:0'}],
                [{'text':'Я — ответственный' + (' ✓' if primary == str(self.owner) else ''),'callback_data':f'staff:primary:{self.owner}'}]]
        for employee in self.rows():
            tid = employee['telegram_id']
            rows.append([{'text':employee['name'] + (' ✓' if primary == str(tid) else ''),'callback_data':f'staff:primary:{tid}'},
                         {'text':'Отключить','callback_data':f'staff:remove:{tid}'}])
        return {'inline_keyboard':rows}
