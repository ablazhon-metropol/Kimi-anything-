"""Deterministic preliminary annuity calculation, not a bank offer."""
import re
from decimal import Decimal, ROUND_HALF_UP
from .conversation import normalized

RATE = Decimal('17.2')
NUMBER = r'\d+(?:[ \u00a0\u202f]\d{3})*(?:[.,]\d+)?'
CURRENCY = r'белорусск\w*\s+руб\w*|российск\w*\s+руб\w*|byn|usd|eur|rub|cny|доллар\w*|евро|юан\w*|руб\w*|\$|€|₽'
MONEY = re.compile(rf'(?<![\w\d])(-?{NUMBER})\s*(тыс\w*|тыс\.)?\s*({CURRENCY})(?!\w)', re.I)

def money(text):
    matches = list(MONEY.finditer(text))
    result = []
    for match in matches:
        value = Decimal(re.sub(r'[ \u00a0\u202f]', '', match[1]).replace(',', '.'))
        if match[2]: value *= 1000
        unit = match[3].lower()
        currency = ('USD' if unit.startswith(('usd','доллар','$')) else
                    'EUR' if unit.startswith(('eur','евро','€')) else
                    'RUB' if unit.startswith(('rub','россий','₽')) else
                    'CNY' if unit.startswith(('cny','юан')) else 'BYN')
        result.append((value, currency, match.start(), match.end()))
    return result

def payment_request(text):
    q = normalized(text)
    return bool(re.search(r'платеж|сколько\s+(?:кредит\s+)?платить|сколько.*в месяц|рассчита\w*.*кредит|расчет.*кредит|переплат|общая сумма выплат', q))

def monthly(principal, months=120):
    principal = Decimal(str(principal))
    if not principal.is_finite() or principal <= 0 or not 1 <= months <= 120:
        raise ValueError('invalid loan')
    rate = RATE / 1200
    return principal * rate / (1 - (1 + rate) ** (-months))

def calculate(text, base, fx):
    """Return customer text and durable parameters (no LLM arithmetic)."""
    q = text.lower().replace('ё','е')
    if 'лизинг' in q and 'кредит' not in q:
        return 'Для расчёта лизинга нужны условия конкретной программы. Могу предложить связаться с менеджером.', base
    state = dict(base)
    if re.search(r'максимальн\w* срок|на максимум',q):
        state['months']=120
    if re.search(r'(?:первый |первоначальный )?взнос\s*0(?:\s|$|[%.!?])',q):
        state['down']='0'; state['down_currency']='BYN'; state.pop('down_percent',None)
    amounts = money(text)
    for amount, currency, start, end in amounts:
        prefix = q[max(0,start-40):start]
        if re.search(r'(?:взнос\w*|первоначальн\w*|пв)\s*(?:в размере\s*)?$', prefix):
            state['down'] = str(amount); state['down_currency'] = currency; state.pop('down_percent',None)
        elif not re.search(r'ставк\w*\s*$',prefix):
            state['amount'] = str(amount); state['currency'] = currency
    term = re.search(r'(?:(?:на|срок(?:ом)?)\s+)?(\d+)\s*(лет|год\w*|мес\w*)\b', q)
    if term:
        state['months'] = int(term[1]) * (1 if term[2].startswith('мес') else 12)
    pct = re.search(r'(?:взнос|пв)\s*(\d+(?:[.,]\d+)?)\s*%', q)
    if pct: state['down_percent'] = pct[1].replace(',','.'); state.pop('down',None)
    if re.search(r'без (?:первого |первоначального )?взноса', q):
        state['down'] = '0'; state['down_currency'] = 'BYN'; state.pop('down_percent',None)
    if not state.get('amount'):
        return 'Какую стоимость автомобиля взять для расчёта? Напишите сумму и валюту или пришлите ссылку на машину.', state
    try:
        total, note = fx.convert(state['amount'],state['currency'])
        down, down_note = fx.convert(state.get('down','0'),state.get('down_currency','BYN'))
        if 'down_percent' in state:
            percent = Decimal(state['down_percent'])
            if not 0 <= percent < 100: raise ValueError('invalid down payment')
            down = total * percent / 100
        if total <= 0 or down < 0 or down >= total:
            raise ValueError('invalid amount')
        months = int(state.get('months',120))
        value = monthly(total-down, months)
    except (ValueError, ArithmeticError, KeyError):
        return 'Уточните стоимость в BYN, срок от 1 до 120 месяцев и взнос меньше стоимости автомобиля. Если нужен пересчёт валюты, её сохранённый курс должен быть доступен.', state
    formatted = f'{value.quantize(Decimal("1"), rounding=ROUND_HALF_UP):,}'.replace(',', ' ')
    duration = '10 лет' if months == 120 else f'{months} мес.'
    answer = f'Примерный платёж — от {formatted} BYN в месяц на {duration}.'
    if re.search(r'переплат|общая сумма выплат|полная стоимость', q):
        # Answer an explicit question transparently; never add these to a normal quote.
        interest = value*months-(total-down)
        interest_text=f'{interest.quantize(Decimal("1"), rounding=ROUND_HALF_UP):,}'.replace(',', ' ')
        answer += f' При неизменной ставке 17,2% расчётная сумма процентов — {interest_text} BYN.'
    if re.search(r'ставк|услови|как.*счита', q):
        answer += ' Расчёт при ставке 17,2% годовых.'
    answer += ' Без учёта возможных страховок и комиссий.'
    for n in dict.fromkeys([note,down_note]):
        if n: answer += ' ' + n[0].upper() + n[1:] + '.'
    return answer, state
