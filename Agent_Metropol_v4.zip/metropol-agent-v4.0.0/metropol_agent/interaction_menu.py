import re
from .catalog_selection import select, matches, words
from .conversation import CATALOG_URL, full_catalog_request

class InteractionMenu:
    def _response_markup(self, scope, query, answer):
        links=re.findall(r'https://(?:www\.)?metropol-auto\.by/vehicles/[^\s<>]+',answer)
        is_test=scope.startswith('test:')
        if not links and not is_test and not (full_catalog_request(query) and CATALOG_URL in answer): return None
        body={'query':query,'answer':answer,'links':links,'signature':self.preferences.get(scope).get('signature')}
        token=self.sessions.create(scope,body)
        buttons=[]
        if full_catalog_request(query) and CATALOG_URL in answer:
            buttons.append([{'text':'Открыть каталог','url':CATALOG_URL}])
        elif links:
            buttons.append([{'text':'Другие варианты','callback_data':f'x:next:{token}'},{'text':'Хочу посмотреть','callback_data':f'x:visit:{token}'}])
        if is_test: buttons.append([{'text':'Плохой ответ','callback_data':f'x:bad:{token}'}])
        return {'inline_keyboard':buttons}

    def _interaction_callback(self, callback):
        actor=int((callback.get('from') or {}).get('id') or 0)
        cb=str(callback.get('id') or '')
        try: _,action,token=callback['data'].split(':',2)
        except ValueError:
            self.telegram.answer_callback(cb,'Некорректная кнопка'); return
        row=self.sessions.get(token)
        allowed=False
        if row:
            if row['scope']==f'test:{self.settings.owner_id}': allowed=actor==self.settings.owner_id
            elif row['scope'].startswith('client:'):
                client=self.db.client_by_id(int(row['scope'].split(':')[1]))
                allowed=bool(client and str(actor)==str(client['external_id']) and not client.get('do_not_contact'))
        if not allowed:
            self.telegram.answer_callback(cb,'Кнопка недоступна или устарела'); return
        body=row['body']; test=row['scope'].startswith('test:')
        if action in {'bad','approve','reject'}:
            if not test: self.telegram.answer_callback(cb,'Только для владельца'); return
            if action=='bad':
                if row['status'] not in {'open','noted'}:
                    self.telegram.answer_callback(cb,'Замечание уже обрабатывается'); return
                self.db.set_setting('feedback-input',token)
                self.sessions.update(token,body,'note')
                self._send(actor,'Что не так в этом ответе? Напишите замечание. /cancel — отмена.')
            elif action=='approve':
                ok=self.sessions.approve(token,actor)
                self._send(actor,'Исправление подтверждено и добавлено в примеры ответов.' if ok else 'Уже обработано или нет готового исправления.')
            else:
                if row['status']!='approved': self.sessions.update(token,body,'rejected')
                self.db.set_setting('feedback-input','')
                self._send(actor,'Замечание сохранено без обучения. Ранее подтверждённые примеры этой кнопкой не удаляются.')
            self.telegram.answer_callback(cb,'Готово'); return
        # manager remains accepted only for already-sent buttons from older releases.
        if action not in {'next','visit','manager'} or not body.get('links'):
            self.telegram.answer_callback(cb,'Некорректная кнопка'); return
        if self.preferences.get(row['scope']).get('signature')!=body.get('signature'):
            self.telegram.answer_callback(cb,'Условия поиска изменились. Используйте новую подборку.'); return
        if action=='next':
            text='Покажите другие варианты'
        elif action=='visit':
            text='Хочу приехать посмотреть автомобили из подборки: '+' '.join(body['links'])
        else:
            text='Соедините с менеджером. Подборка: '+' '.join(body['links'])
        if test:
            self._run_owner_test(text,f'button-{action}-{token}')
        else:
            self.db.enqueue_client_message(f'button-{action}-{token}',client['id'],text,0)
        self.telegram.answer_callback(cb,'Запрос принят')

    def _feedback_text(self,text):
        token=self.db.get_setting('feedback-input')
        if not token: return False
        row=self.sessions.get(token,f'test:{self.settings.owner_id}')
        if not row:
            self.db.set_setting('feedback-input',''); return False
        body=row['body']; owner=self.settings.owner_id
        if row['status']=='note':
            body['note']=text[:3500]; self.sessions.update(token,body,'correction')
            self._send(owner,'Замечание записано. Теперь напишите правильный вариант ответа. Он не применяется без подтверждения. /cancel — оставить только замечание.')
        elif row['status']=='correction':
            body['correction']=text[:2500]; self.sessions.update(token,body,'ready')
            self.db.set_setting('feedback-input','')
            self._send(owner,'Применить этот пример ответа?\n\n'+body['correction'],{'inline_keyboard':[[
                {'text':'Подтвердить исправление','callback_data':f'x:approve:{token}'},
                {'text':'Не применять','callback_data':f'x:reject:{token}'}]]})
        else:
            self.db.set_setting('feedback-input',''); return False
        return True

    def _catalog_diagnostics(self,query=''):
        status=self.catalog.status()
        result=f"Каталог: {status['count']} доступных карточек.\nПоследнее успешное обновление (UTC): {status.get('last_success') or 'ещё не было'}\nОшибка: {(status.get('last_error') or 'нет')[:350]}\n"
        if query:
            rows=self.db.catalog_rows(); selection=select(rows,query)
            if selection:
                mode,picked,_=selection
                result+=f"\nПроверка «{query[:120]}»: {'совпадение' if mode=='exact' else 'только альтернативы'}, показано {len(picked)}.\n"
                result+='\n'.join(f"• {r['title']} · {r.get('year') or 'год не указан'}\n{r['url']}" for r in picked)
            else: result+='\nМодель не распознана.'
        else: result+='\nДля проверки: /catalog Пежо 3008'
        return result[:3900]
