"""Typed year filtering and pagination safeguards, independent of AI wording."""
import re
from datetime import datetime
from zoneinfo import ZoneInfo


def explicit_year(text):
    """A single vehicle year in the latest request; never infer age or money."""
    if re.search(r'\bвозраст|мне\s+\d+|кредит|плат[её]ж|взнос', text, re.I):
        return None
    matches = re.findall(r'(?<!\d)((?:19|20)\d{2})(?!\d|\s*(?:BYN|USD|EUR|руб))', text, re.I)
    if not matches:
        matches = [str(2000 + int(y)) for y in re.findall(r'(?<!\d)(\d{2})(?:[- ]го)?\s*(?:года?\b|г\.)', text, re.I)]
    if len(set(matches)) != 1 or re.search(r'\b(?:от|до|после|раньше|новее|старше|с)\s+\d', text, re.I):
        return None
    return int(matches[0])


def wants_more(text):
    return bool(re.search(r'ещ[её]|другие варианты|следующ|продолжи|дальше', text, re.I))


def normalize_year(value):
    if value is None:
        return None
    if type(value) is not int:
        raise ValueError('year must be integer')
    if 0 <= value <= 99:
        value += 2000 if value <= datetime.now(ZoneInfo('Europe/Minsk')).year % 100 + 1 else 1900
    if not 1900 <= value <= datetime.now(ZoneInfo('Europe/Minsk')).year + 1:
        raise ValueError('year out of range')
    return value


def year_rows(rows, minimum, maximum):
    minimum, maximum = normalize_year(minimum), normalize_year(maximum)
    if minimum is not None and maximum is not None and minimum > maximum:
        raise ValueError('invalid year range')
    return [r for r in rows if (minimum is None and maximum is None) or
            (type(r.get('year')) is int and
             (minimum is None or r['year'] >= minimum) and
             (maximum is None or r['year'] <= maximum))]
