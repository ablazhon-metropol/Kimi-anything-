"""Owner-supplied aggregate statistic, not an individual approval probability."""
import re

STATEMENT = 'По нашей внутренней статистике за последние три года, одобрение получают 99% заявок на кредит или лизинг.'
DECISION = 'Окончательное решение принимает банк или лизинговая компания.'
INSTRUCTION = (
    'Владелец подтвердил внутреннюю статистику компании за три года: 99% одобренных заявок, показатель относится к кредиту и лизингу. '
    'Это сведения владельца, не независимая проверка и не персональная вероятность клиента. '
    'Не говори «вам одобрят с вероятностью 99%», «гарантируем», «одобряем всем», «банк точно одобрит». '
    'При обсуждении одобрения можно использовать формулировку: '+STATEMENT+' '+DECISION+
    ' Не выдумывай размер выборки, даты начала/конца периода, отдельные показатели для банков, клиентов с отказами или просрочками. '
    'Не повторяй статистику в каждом сообщении. Решение и условия подтверждает финансовый партнёр.'
)

def with_statistic(answer, query, history):
    if not re.search(r'кредит|лизинг|финансирован|одобр',query,re.I): return answer
    # Replace model paraphrases of the percentage with the agreed attributed sentence.
    parts=re.split(r'(?<=[.!?])\s+|\n+',answer)
    has_stat=False
    cleaned=[]
    for part in parts:
        if re.search(r'99\s*(?:%|процент)',part,re.I) and re.search(r'одобр|заявк|гарант',part,re.I):
            has_stat=True
            continue
        cleaned.append(part)
    seen=any(re.search(r'99\s*%',m.get('text','')) for m in history if m.get('direction')=='out')
    requested=bool(re.search(r'99|статистик|процент|гарант|вероятност',query,re.I))
    if has_stat or not seen or requested:
        cleaned=[p for p in cleaned if not (re.search(r'решени|условия.*подтверж',p,re.I) and re.search(r'банк|партн[её]р|лизингов',p,re.I))]
        body=' '.join(cleaned).strip()
        return (body+'\n\n' if body else '')+STATEMENT+' '+DECISION
    return answer
