import re

ICONS = ('🚗', '🚙', '🙂', '😊', '🌸', ')')
SERIOUS = ('жалоб', 'претенз', 'обман', 'суд', 'угроз', 'кредит', 'лизинг', 'ставк', 'платеж', 'платёж', 'долг')

def decorate(text, query, history, sequence=0):
    if any(word in query.lower() for word in SERIOUS):
        return text
    # Rotate using persisted conversation history, not a process-local counter.
    recent = ' '.join(str(m.get('text', '')) for m in history if m.get('direction') == 'out')
    if any(icon in text for icon in ICONS[:-1]) or text.rstrip().endswith(')'):
        return text
    options = [icon for icon in ICONS if icon not in recent[-1500:]] or [icon for icon in ICONS if icon not in recent[-400:]]
    if not options or sequence % 4 == 0:
        return text
    # Gift icons only accompany real, explicitly approved gift information.
    if 'подарок включён' in text.lower() and '🎁' not in recent[-1500:]:
        options = ['🎁']
    icon = options[sequence % len(options)]
    head, sep, rest = text.partition('\n\n')
    return head + ' ' + icon + (sep + rest if sep else '')
