"""Ground commercial answers in owner records and deterministic calculators."""
import re
from .prices import candidate_rows, tokens
from .credit import payment_request, calculate, money
from .conversation import simple_price, normalized, plain_text
from .catalog_selection import mentioned_brands, model_core, words, reply as catalog_reply
from .selection_context import resolve

FOLLOWUP = {'да','да верно','верно','именно','она','он','на нее','на него','цена','какая цена',
            'сколько стоит','сколько стоят','почем','по чем','платеж','какой платеж',
            'сколько платить','а сколько платить','рассчитай платеж','рассчитать платеж'}

def catalogue_match(rows, query):
    from .catalog_selection import select
    links=re.findall(r'https?://[^\s<>]+',query)
    if links:
        links={url.rstrip('.,!?)') for url in links}
        found=[r for r in rows if r['url'] in links]
        return ('exact',found,True) if len(found)==1 and len(links)==1 else None
    return select(rows,query)

class Commerce:
    def __init__(self, db, preferences, exchange):
        self.db, self.preferences, self.exchange = db, preferences, exchange

    def route(self, scope, query, history):
        pref = self.preferences.get(scope)
        state = pref.get('commerce', {})
        q = normalized(query)
        rows = self.db.approved_prices(10000)
        catalog_rows=self.db.catalog_rows()
        query,choice,clarification=resolve(query,pref,rows,catalog_rows)
        if clarification:
            return clarification,'local-price-clarify','Неоднозначный выбор автомобиля'
        candidates = candidate_rows(rows,query)
        is_payment = payment_request(query)
        is_price = simple_price(query) or choice
        previous_out = next((m.get('text','') for m in reversed(history) if m.get('direction')=='out'), '')
        # Short replies are interpreted only inside an established calculation.
        active=bool(state.get('pending')=='payment' or state.get('price_id') or state.get('catalog_url'))
        adjustment=bool(re.search(r'максимальн\w* срок|на максимум|(?:первый |первоначальный )?взнос|без (?:первого |первоначального )?взноса',q) or re.fullmatch(r'(?:а )?(?:на )?\d+ (?:лет|года|год|месяцев|мес)',q))
        bare=re.fullmatch(r'\d+(?:[ .,]\d+)*',query.strip())
        if active and bare:
            if q=='0' and (state.get('pending')=='payment' or re.search(r'взнос[^.!?]*\?',previous_out,re.I)):
                query='Первый взнос 0'; adjustment=True
            elif state.get('pending')=='payment':
                currency=state.get('currency')
                if not currency and re.search(r'\bBYN\b|белорусск\w*\s+руб',previous_out,re.I): currency='BYN'
                if not currency:
                    state['pending_number']=query.strip()
                    self.save(scope,pref,state)
                    return 'Эта сумма в белорусских рублях (BYN)?','local-credit','Уточнение валюты суммы'
                query=query.strip()+' '+currency
                is_payment=True
        if state.get('pending_number') and q in {'да','byn','в рублях','белорусские рубли'}:
            query=state.pop('pending_number')+' BYN'; is_payment=True
        # A newly named model must never borrow another car's approved price.
        named=bool(candidates or mentioned_brands(catalog_rows,query) or
                   re.search(r'\b[a-zа-я]{1,3}\d{1,4}\b',q) or
                   (not money(query) and re.search(r'\b(?!19\d{2}\b|20\d{2}\b)\d{3,4}\b',q)) or
                   any(model_core(r) and model_core(r)<=words(query) for r in catalog_rows))
        if state.get('pending')=='payment' and money(query):
            is_payment=True
        followup = q in FOLLOWUP or bool(re.fullmatch(r'(?:а )?(?:на )?\d+ (?:лет|года|год|месяцев|мес)',q)) or bool(re.match(r'^(?:а )?(?:взнос|без взноса|без первого взноса)',q))
        followup=(followup or (active and (is_payment or adjustment or q in {'проверь','проверь цену','проверить','узнай цену'}))) and not named
        if any(not re.search(r'(?:взнос\w*|пв)\s*$',query[max(0,start-40):start],re.I) for _,_,start,_ in money(query)):
            followup=False
        if active and adjustment: is_payment=True
        if active and q in {'проверь','проверь цену','проверить','узнай цену'}: is_price=True
        # Resolve a bare "yes" only against an actual preceding model clarification.
        previous_out = next((m.get('text','') for m in reversed(history) if m.get('direction')=='out'), '')
        if q in {'да','верно','да верно','именно'} and '?' in previous_out:
            suggested = candidate_rows(rows,re.sub(r'\b(?:вы|это)\s+про\b',' ',previous_out,flags=re.I))
            if len(suggested)==1:
                candidates=suggested; is_price=True
        if not candidates and followup and state.get('price_id'):
            candidates=[r for r in rows if r['id']==state['price_id']]
        if candidates and state.get('pending')=='price': is_price=True
        if is_payment or (followup and state.get('pending')=='payment'):
            is_payment=True
        diagnostics = ''
        if len(candidates)>1:
            state={'pending':'payment' if is_payment else 'price'}
            self.save(scope,pref,state)
            labels='; '.join(r['label'] for r in candidates[:5])
            return f'Уточните модель или комплектацию: {labels}.', 'local-price-clarify', 'Несколько утверждённых записей: '+labels
        row = candidates[0] if candidates else None
        if row and not is_payment and not is_price:
            name_words=words(query)-words('ну мне нужен нужна хочу интересует пожалуйста')
            known_names=words(row['label']+' '+row['matcher'])
            if name_words and name_words<=known_names:
                is_price=True
        # An explicitly selected catalogue card can be remembered for the next "платёж".
        if not row and not followup and not money(query):
            selection=catalogue_match(self.db.catalog_rows(),query)
            if selection and selection[2]:
                state={}
                if selection[0]=='exact' and len(selection[1])==1:
                    card=selection[1][0]
                    chinese={'geely','changan','chery','haval','exeed','zeekr','byd','li','voyah','belgee'}
                    if not (tokens(card['brand']) & chinese) and card.get('price_byn'):
                        state={'catalog_url':card['url']}
                self.save(scope,pref,state)
        if followup and state.get('catalog_url'):
            card=next((r for r in self.db.catalog_rows() if r['url']==state['catalog_url']),None)
            state.pop('amount',None); state.pop('currency',None)
            if card and card.get('price_byn'):
                state.update(amount=str(card['price_byn']),currency='BYN')
        if row:
            if row['id'] != state.get('price_id'):
                state={}
            state['price_id']=row['id']
            # Persist a grounded selection even when returning before the general dialogue path.
            pref['brand']=row['label'].split()[0]
            pref['model']=' '.join(row['label'].split()[1:])
            diagnostics=f"Цена: запись #{row['id']} · {row['label']} · панель владельца"
            values=money(row['price_text'])
            # No arbitrary choice between several amounts in a free-text owner price.
            state.pop('amount',None); state.pop('currency',None)
            if len(values)==1:
                state.update(amount=str(values[0][0]),currency=values[0][1])
            if is_price and not is_payment:
                state['pending']=''
                self.save(scope,pref,state)
                return plain_text(f"{row['label']} — {row['price_text']}"), 'approved-price', diagnostics
            self.save(scope,pref,state)
        if is_payment:
            base = dict(state) if (followup or row or money(query) or state.get('pending')=='payment') else {}
            if not row and any(not re.search(r'(?:взнос\w*|пв)\s*$',query[max(0,start-40):start],re.I) for _,_,start,_ in money(query)):
                base={}
            if not row and not followup and not money(query):
                # Never use a previous car for a newly named model; consider exact catalogue matches only.
                selection=catalogue_match(self.db.catalog_rows(),query)
                if selection and selection[0]=='exact' and len(selection[1])==1:
                    card=selection[1][0]
                    chinese={'geely','changan','chery','haval','exeed','zeekr','byd','li','voyah','belgee'}
                    if not (tokens(card['brand']) & chinese) and card.get('price_byn'):
                        base={'amount':str(card['price_byn']),'currency':'BYN','catalog_url':card['url']}
                        diagnostics='Цена: конкретная карточка каталога'
            # An owner price overrides numbers casually quoted alongside the named model.
            calculation_query=query
            if row and money(query):
                # Keep explicit deposit amounts, but do not allow a different car price to override approval.
                for _,_,start,end in reversed(money(query)):
                    if not re.search(r'(?:взнос|пв)\s*$',query[max(0,start-30):start],re.I):
                        calculation_query=calculation_query[:start]+calculation_query[end:]
            answer, base=calculate(calculation_query,base,self.exchange)
            base['pending']='payment'
            self.save(scope,pref,base)
            return answer,'local-credit',diagnostics or 'Кредит: сумма клиента / сохранённые условия; ставка 17,2%'
        if is_price:
            selection = catalogue_match(self.db.catalog_rows(), query)
            if selection and selection[0] == 'exact' and selection[1]:
                cards = selection[1][:15]
                if len(cards) == 1:
                    pref['brand'], pref['model'] = cards[0]['brand'], cards[0]['model_name']
                    pref['commerce'] = {'catalog_url': cards[0]['url']}
                    self.preferences.save(scope, pref)
                return catalog_reply(('exact', cards, True), show_price=True), 'local-catalog-price', 'Цена: актуальные карточки сайта'
            if selection and selection[2]:
                return catalog_reply(('alternatives', [], True)), 'local-catalog-price-missing', 'Точная карточка на сайте не найдена'
            self.save(scope,pref,{'pending':'price'})
            return 'Для какой модели нужна цена? Уточните название и комплектацию — проверю цену на сайте.', 'local-price-clarify', 'Модель не указана; сумма не генерировалась'
        if re.fullmatch(r'(?:а )?(?:кредит можно|можно (?:в )?кредит|есть кредит|можно в рассрочку)',q):
            from .finance_policy import with_statistic
            answer='Можно рассмотреть кредит без первого взноса на срок до 10 лет. Рассчитать примерный платёж на выбранный автомобиль?'
            return with_statistic(answer,query,history),'local-finance','Условия компании; окончательное решение финансового партнёра'
        return None

    def save(self,scope,pref,state):
        pref['commerce']=state
        self.preferences.save(scope,pref)

def guard_money(answer, label=''):
    """AI is not a source of car prices or payment numbers; direct routes bypass this."""
    answer=plain_text(answer)
    if money(answer) or re.search(r'\d[\d ]*\s*(?:р\.|₽|руб)',answer,re.I):
        if label:
            return f'По {label} сумму пока не удалось подтвердить. Напишите «проверь цену» или «позови менеджера».'
        return 'Сумму пока не удалось подтвердить. Уточните модель или напишите «позови менеджера».'
    return answer
