import html

def page(title, body):
    return """<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>""" + html.escape(title) + """ — Агент Метрополь</title><style>
*{box-sizing:border-box}body{font-family:system-ui;background:#071a2d;color:#fff;margin:0;padding:18px;max-width:760px;margin:auto}h1,h2{color:#e3c274}h1{font-size:28px}h2{font-size:21px}.card{background:#102b47;border:1px solid #52606a;border-radius:16px;padding:18px;margin:18px 0;overflow-wrap:anywhere}label{display:block;margin-top:12px}input,textarea{font:inherit;width:100%;padding:12px;margin:6px 0 12px;border-radius:10px;border:1px solid #678;background:#eef;color:#071a2d}textarea{resize:vertical}button,.button{font:inherit;display:inline-block;background:#e3c274;color:#071a2d;border:0;border-radius:10px;padding:12px 16px;font-weight:700;text-decoration:none;cursor:pointer}a{color:#e3c274}small{color:#bfcedd}nav{display:flex;gap:16px;flex-wrap:wrap}button{min-height:46px}</style><nav><a href="/admin">Панель</a><a href="/admin/prices">Китайские авто</a></nav><h1>""" + html.escape(title) + "</h1>" + body + "</html>"

def price_form(row=None):
    r = row or {}
    e = lambda name: html.escape(str(r.get(name, "")), quote=True)
    hidden = (f'<input type="hidden" name="price_id" value="{int(r["id"])}"><input type="hidden" name="expected" value="{e("updated_at")}">' if row else '')
    return f'''<form method="post" action="/admin/prices">{hidden}
<label>Марка и модель<input name="label" value="{e('label')}" placeholder="Changan X5 Plus" required maxlength="150"></label>
<label>Другие названия<textarea name="matcher" rows="2" maxlength="150" placeholder="Чанган X5 Plus; Чанань X5 Плюс">{e('matcher')}</textarea></label>
<small>Полные варианты названия разделяйте точкой с запятой. Короткие обозначения X5, L9 учитываются.</small>
<label>Как назвать цену клиенту<textarea name="price_text" rows="4" required maxlength="300" placeholder="От … белорусских рублей. Зависит от комплектации.">{e('price_text')}</textarea></label>
<button type="submit">{'Сохранить и утвердить изменения' if row else 'Добавить и утвердить цену'}</button></form>'''

def prices_page(rows):
    cards = ''.join(f'<section class="card"><h2>{html.escape(r["label"])}</h2><p>{html.escape(r["price_text"])}</p><a class="button" href="/admin/prices/{int(r["id"])}">Изменить цену</a></section>' for r in rows)
    return page('Цены китайских авто', '<p>Утверждённые изменения сразу используются агентом. Перезапуск не нужен.</p>' + cards + '<details class="card"><summary>＋ Добавить автомобиль</summary>' + price_form() + '</details>')

def draft_page(draft, client):
    name = html.escape(str(client.get('name') or client.get('username') or client['external_id']))
    return page('Исправить ответ', f'''<section class="card"><p>Получатель: <strong>{name}</strong> · клиент №{int(client['id'])}</p><form method="post" action="/admin/drafts/{int(draft['id'])}"><label>Ответ клиенту<textarea name="text" rows="12" required maxlength="4000">{html.escape(draft['text'])}</textarea></label><button type="submit">Отправить клиенту</button></form><p><a href="/admin">Отмена — не отправлять изменения</a></p></section>''')
