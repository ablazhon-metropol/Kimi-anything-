"""Daily official NBRB cache. Never replace good rates with failed downloads."""
import json
import threading
from datetime import datetime
from decimal import Decimal
from zoneinfo import ZoneInfo
import httpx

MINSK = ZoneInfo('Europe/Minsk')
ENDPOINT = 'https://api.nbrb.by/exrates/rates'

class ExchangeRates:
    def __init__(self, db):
        self.db = db
        self.lock = threading.Lock()

    def state(self):
        try:
            return json.loads(self.db.get_setting('nbrb-rates', '{}'))
        except (ValueError, TypeError):
            return {}

    def refresh(self, now=None):
        now = (now or datetime.now(MINSK)).astimezone(MINSK)
        day = now.date().isoformat()
        with self.lock:
            state = self.state()
            if state.get('updated_day') == day:
                return False
            attempts = state.get('attempts', 0) if state.get('attempt_day') == day else 0
            if attempts >= 3:
                return False
            if attempts and now.timestamp() - state.get('attempt_at', 0) < 900:
                return False
            state.update(attempt_day=day, attempt_at=now.timestamp(), attempts=attempts+1)
            try:
                new = {}
                with httpx.Client(timeout=10, trust_env=False) as client:
                    for periodicity in (0, 1):
                        response = client.get(ENDPOINT, params={'ondate':day,'periodicity':periodicity})
                        response.raise_for_status()
                        rows = response.json()
                        if not isinstance(rows, list) or not rows:
                            raise ValueError('empty rates')
                        for row in rows:
                            currency = row['Cur_Abbreviation']
                            date = row['Date'][:10]
                            rate = Decimal(str(row['Cur_OfficialRate']))
                            scale = int(row['Cur_Scale'])
                            if date > day or not rate.is_finite() or rate <= 0 or scale <= 0:
                                raise ValueError('invalid rate')
                            new[currency] = {'rate':str(rate),'scale':scale,'date':date,
                                             'received_at':now.isoformat(),'source':ENDPOINT}
                if not {'USD','EUR','RUB'} <= new.keys():
                    raise ValueError('incomplete rates')
                state['rates'] = {**state.get('rates', {}), **new}
                state.update(updated_day=day, error='')
            except Exception as exc:
                # Exception type only: avoid putting transport details in customer-visible state.
                state['error'] = type(exc).__name__
            self.db.set_setting('nbrb-rates', json.dumps(state, ensure_ascii=False))
            return not state.get('error')

    def convert(self, amount, currency, now=None):
        amount = Decimal(str(amount))
        if currency == 'BYN':
            return amount, ''
        row = self.state().get('rates', {}).get(currency)
        day = (now or datetime.now(MINSK)).astimezone(MINSK).date().isoformat()
        if not row or row['date'] > day:
            raise ValueError('no saved exchange rate')
        rate, scale = Decimal(row['rate']), Decimal(row['scale'])
        if not rate.is_finite() or rate <= 0 or scale <= 0:
            raise ValueError('invalid saved exchange rate')
        prefix = 'по курсу' if row['date'] == day else 'по последнему известному курсу'
        return amount * rate / scale, f"{prefix} НБРБ на {row['date']}"

    def diagnostics(self):
        state = self.state()
        dates = sorted({r['date'] for r in state.get('rates', {}).values()})
        return ('Курсы НБРБ: ' + (', '.join(dates) or 'ещё не загружены') +
                '\nПоследнее успешное обновление: ' + state.get('updated_day', 'нет') +
                '\nОшибка обновления: ' + (state.get('error') or 'нет') +
                '\nПри сбое используем последний сохранённый курс с его датой.')
