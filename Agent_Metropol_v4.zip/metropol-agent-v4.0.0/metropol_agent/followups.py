from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from .db import now, later

MINSK = ZoneInfo('Europe/Minsk')
STOP = ('не пиш', 'не звон', 'не связы', 'не надо', 'не нуж', 'не интерес', 'отказ', 'до свидания', 'всего доброго', 'пока', 'купил', 'вопрос решен', 'вопрос решён', 'жалоб', 'претенз', 'обман', 'менеджер', 'андре', 'руководител')
SALES = ('купить', 'покупк', 'хочу авто', 'ищу авто', 'подберите', 'цена', 'сколько стоит', 'приеха', 'посмотреть авто', 'кредит', 'лизинг', 'трейд', 'trade-in')
TEXT = ('Если вопрос с выбором автомобиля ещё актуален, будем рады помочь. '
        'Наши площадки: Минск, ул. Горецкого, 6А — +375 29 678-22-55; '
        'ул. Мазурова, 1, БЦ «Камелот» — +375 44 722-22-55. '
        'Работаем ежедневно 9:00–20:00. Если напоминания не нужны, напишите «не пишите мне».')

def daytime():
    return 9 <= datetime.now(MINSK).hour < 20

class Followups:
    def __init__(self, db):
        self.db = db

    def consider(self, client, query, source_id):
        q = query.lower()
        if client['mode'] != 'auto' or client.get('do_not_contact') or any(w in q for w in STOP):
            self.db._execute("UPDATE sales_followups SET status='cancelled' WHERE client_id=%s", (client['id'],))
            return
        if not any(w in q for w in SALES):
            return
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()
        self.db._execute(
            "INSERT INTO sales_followups(client_id,source_message_id,due_at,status,last_sent_at) VALUES(%s,%s,%s,'pending',NULL) "
            "ON CONFLICT(client_id) DO UPDATE SET source_message_id=excluded.source_message_id,due_at=excluded.due_at,status='pending' "
            "WHERE sales_followups.last_sent_at IS NULL OR sales_followups.last_sent_at<%s",
            (client['id'], source_id, later(7200), cutoff))

    def eligible(self, client_id, source_id):
        client = self.db.client_by_id(client_id)
        if not client or client['mode'] != 'auto' or client.get('do_not_contact') or client.get('status') in {'sold', 'closed', 'deleted'}:
            return False
        history = self.db.recent_messages(client_id, 20)
        incoming = [m for m in history if m['direction'] == 'in']
        outgoing = [m for m in history if m['direction'] == 'out']
        if not incoming or incoming[-1]['id'] != source_id or any(w in incoming[-1]['text'].lower() for w in STOP):
            return False
        return bool(outgoing and outgoing[-1]['id'] > source_id and outgoing[-1].get('model') not in {'human-correction', 'human'})

    def enqueue_due(self):
        if not daytime():
            return 0
        count = 0
        for row in self.db._execute("SELECT * FROM sales_followups WHERE status='pending' AND due_at<=%s", (now(),), 'all'):
            cid, sid = row['client_id'], row['source_message_id']
            if not self.eligible(cid, sid):
                self.db._execute("UPDATE sales_followups SET status='cancelled' WHERE client_id=%s AND source_message_id=%s", (cid, sid))
                continue
            client = self.db.client_by_id(cid)
            self.db.enqueue_outbox(client['external_id'], TEXT,
                metadata={'direction':'out', 'client_id':cid, 'event_id':f'followup-{cid}-{sid}', 'model':'local-followup', 'followup_source':sid},
                dedupe_key=f'followup-{cid}-{sid}')
            self.db._execute("UPDATE sales_followups SET status='queued',last_sent_at=%s WHERE client_id=%s AND source_message_id=%s", (now(), cid, sid))
            count += 1
        return count

    def before_delivery(self, item):
        meta = item.get('metadata') or {}
        sid = meta.get('followup_source')
        if not sid:
            return True
        if not self.eligible(meta['client_id'], sid):
            self.db._execute("UPDATE outbox SET status='cancelled',last_error='Follow-up no longer eligible' WHERE id=%s", (item['id'],))
            return False
        if not daytime():
            current = datetime.now(MINSK)
            next_day = current + timedelta(days=1) if current.hour >= 20 else current
            send_at = next_day.replace(hour=9,minute=0,second=0,microsecond=0).astimezone(timezone.utc).isoformat()
            self.db._execute("UPDATE outbox SET status='pending',send_after=%s WHERE id=%s", (send_at,item['id']))
            return False
        return True
