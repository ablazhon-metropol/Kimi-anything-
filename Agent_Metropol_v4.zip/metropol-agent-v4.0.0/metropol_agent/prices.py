"""Conservative matching for owner-approved vehicle prices."""
import re
import unicodedata

ALIASES = {"чанган": "changan", "чанань": "changan", "чaнган": "changan",
           "джили": "geely", "монжаро": "monjaro", "ли": "li", "лисян": "li",
           "плюс": "plus", "про": "pro", "макс": "max", "ультра": "ultra",
           "кулек": "coolray", "кульки": "coolray", "кулька": "coolray",
           "кулрей": "coolray", "кулрэй": "coolray", "кулрейи": "coolray",
           "чанганы":"changan", "чанганов":"changan", "чангана":"changan",
           "чангане":"changan", "чанганах":"changan", "джилей":"geely"}

def tokens(text):
    text = unicodedata.normalize("NFKC", text).lower().replace("ё", "е")
    text = re.sub(r"\b([a-zа-я]{1,3})[ -]+(\d+)(?!\d)", r"\1\2", text)
    result = []
    for word in re.findall(r"[a-zа-я0-9]+", text):
        if re.search(r"\d", word):
            word = word.replace("кс", "cs").translate(str.maketrans({"х":"x", "л":"l", "с":"c"}))
        result.append(ALIASES.get(word, word))
    return set(result)

def candidate_rows(rows, query):
    q = tokens(query)
    candidates = []
    known_brands = {"bmw", "бмв", "audi", "ауди", "changan", "geely", "li", "byd", "haval", "chery", "exeed", "zeekr", "voyah", "toyota"}
    known_brands.update(next(iter(re.findall(r"[a-zа-я]+", r["label"].lower())), "") for r in rows)
    for row in rows:
        canonical = tokens(row["label"])
        if (q & known_brands) - canonical:
            continue
        codes = {w for w in canonical if any(c.isdigit() for c in w)}
        variants = {"plus", "pro", "max", "ultra", "premium", "luxury"}
        if (q & variants) - canonical:
            continue
        alternatives = [canonical]
        alternatives += [tokens(x) for x in re.split(r"[;\n|]", row["matcher"]) if x.strip()]
        core = canonical - known_brands - variants
        if core:
            alternatives.append(core)
        valid = [x for x in alternatives if x and x - known_brands - variants and x <= q]
        # Numeric model identifiers must survive; a brand alone never selects a price.
        if codes:
            if not codes <= q and not valid:
                continue
            score = len(canonical & q)
        else:
            if not valid:
                continue
            score = max(map(len, valid))
        candidates.append((score, row))
    if not candidates:
        return []
    best = max(score for score, _ in candidates)
    winners = [row for score, row in candidates if score == best]
    # Never choose between two trims/brands/prices by row order.
    return winners

def matching_rows(rows, query):
    winners = candidate_rows(rows, query)
    return winners if len(winners) == 1 else []
