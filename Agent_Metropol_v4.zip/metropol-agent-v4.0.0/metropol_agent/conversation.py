"""Cheap routing is conservative: substantive conversation goes to the model."""
import re

def normalized(text):
    return ' '.join(re.sub(r'[^а-яa-z0-9 ]', ' ', text.lower().replace('ё', 'е')).split())

def simple_fact(text):
    q = normalized(text)
    return q in {
        'адрес', 'ваш адрес', 'где вы', 'где вы находитесь', 'как проехать',
        'телефон', 'ваш телефон', 'номер телефона', 'ваш номер телефона',
        'график работы', 'режим работы', 'до скольки работаете', 'когда работаете',
    }

def explicit_catalog_request(text):
    q = normalized(text)
    if any(w in q for w in ('сравн', 'лучше', 'почему', 'сомнев', 'стоит ли', 'шут', 'ахах', 'ха ха', 'объясн', 'обосну', 'чем отлич')) or any(w in text for w in ('😂','😅')):
        return False
    return bool(re.search(r'\b(покажите|покажи|скиньте|скинь|пришлите|пришли|отправьте|ссылк\w*|каталог|подберите)\b', q))

def simple_price(text):
    q = normalized(text)
    return bool(re.search(r'\b(сколь(?:ко|ка)? сто(?:ит|ят)|какая цена|цена|цену|цены|стоимость|почем|по чем)\b', q)) and not any(
        word in q for word in ('платеж', 'взнос'))

CATALOG_URL = 'https://metropol-auto.by/vehicles/'

def full_catalog_request(text):
    q = normalized(text)
    if re.search(r'\b(не надо|не нужен|не присылай)\b', q):
        return False
    return bool(re.search(r'(полный|весь|общий) каталог|каталог целиком|ссылк\w* на (?:ваш )?каталог|где посмотреть все (?:машины|авто)|^каталог$', q))

def plain_text(text):
    # Telegram is sent as plain text: remove paired formatting, not URL characters.
    text = text.replace(r'\*', '*')
    text = re.sub(r'\[([^\]]+)\]\((https?://[^\s)]+)\)', r'\1: \2', text)
    return re.sub(r'\*\*(.*?)\*\*', r'\1', text, flags=re.S)

def smalltalk(text):
    q = normalized(text)
    return bool(re.search(r'\b(привет|здравствуй\w*|спасибо|красав\w*|круто|ахах\w*|хаха\w*|шут\w*|настроение|улыб\w*)\b',q)) and not any(
        word in q for word in ('цен', 'кредит', 'лизинг', 'жалоб', 'претенз', 'договор', 'купить', 'сравн'))

def previous_links(history):
    return set(re.findall(r'https://(?:www\.)?metropol-auto\.by/vehicles/[^\s]+',
        ' '.join(m.get('text','') for m in history if m.get('direction') == 'out')))

def bound_links(text, allowed, limit=15):
    # No invented URLs, even if the language model ignores its instruction.
    used = set()
    def replace(match):
        raw = match.group(0)
        url = raw.rstrip('.,!?;:)')
        suffix = raw[len(url):]
        if url not in allowed or (url not in used and len(used) >= limit):
            return ''
        used.add(url)
        return url + suffix
    return re.sub(r'https?://[^\s<>\]\"]+', replace, text).strip()

def handoff_request(text):
    q = normalized(text)
    person = re.search(r'(менеджер|менежер|сотрудник|андре|руководител|человек|оператор|старш|начальник|директор)', q)
    request = re.search(r'(позов|свяж|связа|поговор|переда|соедин|соеден|нужен|нужна|хочу|позвон|звонок|подключ|давай|дайте|можно)', q)
    negated = re.search(r'(не надо|не нужно|не хочу|не зови|не позов|не связы|не звон)', q)
    complaint = any(word in q for word in ('жалоба', 'претензия', 'обманули'))
    return bool(not negated and (complaint or (person and request) or re.search(r'(позвоните мне|перезвоните|заказать звонок)',q)))

def leader_request(text):
    return handoff_request(text) and bool(re.search(r'старш|начальник|директор|руководител|андре|жалоб|претенз|обман', normalized(text)))

def hours_request(text, history=()):
    q = normalized(text)
    explicit = bool(re.search(r'со скольки|с которого часа|до скольки|график|режим работы|когда откры|когда закры|во сколько откры|во сколько закры', q))
    business = bool(re.search(r'работаете|открыты|откроетесь|закрываетесь|часы работы', q))
    followup = bool(re.search(r'по всем|всем филиал|все площад|а завтра|а в воскресенье|а в субботу', q))
    prior = any(re.search(r'работаете|график|скольки|9:00', m.get('text','').lower()) for m in history[-6:])
    return explicit or business or (followup and prior)

def invitation_due(query, history):
    texts = [m.get('text','') for m in history]
    context = normalized(' '.join(texts[-10:] + [query]))
    if re.search(r'не приглаш|не интерес|не надо|не хочу|не пиш|болез|умер|беда|суиц|депресс|жалоб|претенз|авари|врач|больниц', context):
        return False
    outputs = [m.get('text','') for m in history if m.get('direction') == 'out']
    return len(outputs) >= 3 and not any(re.search(r'метропол|приезж|загляд|тест.драйв|на площадк', t.lower()) for t in outputs[-6:])

def add_invitation(answer, query, history, sequence=0):
    if not invitation_due(query, history) or re.search(r'метропол|приезж|загляд|тест.драйв', answer.lower()):
        return answer
    context = normalized(' '.join(m.get('text','') for m in history[-8:]) + ' ' + query)
    if re.search(r'алкогол|выпить|пить|бар|танц|клуб|пьян', context):
        invitation = 'А в другой день заглядывайте в Метрополь Авто — поможем выбрать машину под ваш ритм.'
    else:
        invitations = ('Приезжайте в Метрополь Авто — сравним подходящие варианты вживую.',
                       'В Метрополь Авто можно посмотреть автомобили вживую и обсудить условия покупки.',
                       'Будем рады видеть вас в Метрополь Авто — поможем с выбором.')
        invitation = invitations[sequence % len(invitations)]
    return answer.rstrip() + '\n\n' + invitation
