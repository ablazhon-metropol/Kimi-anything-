"""Inventory counts are computed, never supplied by the language model."""
import re
from datetime import datetime
from zoneinfo import ZoneInfo
from .catalog_selection import select, words, model_core, mentioned_brands
from .conversation import CATALOG_URL

def snapshot(db, catalog):
    with db.lock:
        rows = db.catalog_rows()
        status = catalog.status()
    return rows, status

def stamp(value):
    try:
        return datetime.fromisoformat(value).astimezone(ZoneInfo('Europe/Minsk')).strftime('%d.%m.%Y %H:%M') + ' (Минск)'
    except (ValueError, TypeError):
        return 'нет данных'

def model_count(rows):
    return len({(tuple(sorted(words(r['brand']))), tuple(sorted(model_core(r)))) for r in rows})

def count_answer(db, catalog, query):
    low=query.lower()
    if not re.search(r'\bсколько\b|количеств|число ',low):
        return None
    if re.search(r'плат[её]ж|платить|кредит|лизинг|стоит|стоимость|цен[аыу]|руб|byn|usd|eur',low):
        return None
    rows,status=snapshot(db,catalog)
    specific=bool(mentioned_brands(rows,query) or re.search(r'\b(?:[a-zа-я]{1,3}\d+|\d{3,4})\b',low) or
                  any(model_core(r) and model_core(r)<=words(query) for r in rows))
    if not specific and not re.search(r'машин|автомобил|\bавто\b|модел|марок',low):
        return None
    if not status.get('last_success'):
        return f'Каталог ещё не загружен — количество пока не подтверждено. Полный каталог: {CATALOG_URL}'
    selected=select(rows,query,limit=None) if specific else None
    matched=(selected[1] if selected and selected[0]=='exact' else []) if specific else rows
    if re.search(r'модел',low):
        label='разных моделей'; count=model_count(matched)
    elif 'марок' in low:
        label='марок'; count=len({tuple(sorted(words(r['brand']))) for r in matched})
    else:
        label='автомобилей со статусом «В наличии»'; count=len(matched)
    heading='По вашему запросу' if specific else 'В каталоге'
    text=f'{heading}: {count} {label}. Данные на {stamp(status.get("last_success"))}.'
    if status.get('coverage')!='verified':
        text+=' Это число в загруженной части каталога; полнота загрузки пока не подтверждена.'
    if status.get('last_error'):
        text+=' Последнее обновление не удалось, использованы сохранённые данные.'
    return text+f'\nКаталог: {CATALOG_URL}'
