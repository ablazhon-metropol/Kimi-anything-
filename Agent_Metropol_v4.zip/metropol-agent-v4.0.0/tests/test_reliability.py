import sqlite3
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from cryptography.fernet import Fernet

from metropol_agent.ai import AIResult
from metropol_agent.app import AgentApp
from metropol_agent.catalog import Catalog
from metropol_agent.db import Database


class FakeTelegram:
    def __init__(self):
        self.sent = []
        self.callbacks = []

    def send_message(self, chat_id, text, reply_markup=None):
        self.sent.append((str(chat_id), text, reply_markup))
        return {"ok": True}

    def answer_callback(self, callback_id, text=""):
        self.callbacks.append((callback_id, text))


class FakeAI:
    def __init__(self):
        self.queries = []

    def generate(self, query, history, spent, extra_knowledge=None, corrections=None):
        self.queries.append((query, history, extra_knowledge or [], corrections or []))
        return AIResult("Приглашаю вас на площадку.", "fake-luna", {"input_tokens": 10, "output_tokens": 5, "cost_usd": 0.001})

    def status(self):
        return {"state": "ok", "last_error": ""}


def settings():
    return SimpleNamespace(
        owner_id=463497506,
        global_mode="approval",
        debounce_seconds=0,
        max_job_attempts=5,
    )


class ReliabilityTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "agent.sqlite"
        self.db = Database("sqlite:///" + str(self.path))
        self.db.migrate()

    def tearDown(self):
        self.tmp.cleanup()

    def test_durable_job_survives_database_reopen_and_aggregates_messages(self):
        client = self.db.upsert_client("100", "Клиент", "", "approval")
        self.db.enqueue_client_message("e1", client["id"], "Здравствуйте", 0)
        self.db.enqueue_client_message("e2", client["id"], "Нужен Peugeot 5008", 0)

        reopened = Database("sqlite:///" + str(self.path))
        reopened.migrate()
        jobs = reopened.claim_reply_jobs()
        self.assertEqual(len(jobs), 1)
        messages = reopened.reply_job_messages(jobs[0]["id"])
        self.assertEqual([m["text"] for m in messages], ["Здравствуйте", "Нужен Peugeot 5008"])

    @patch("metropol_agent.app.is_night", return_value=False)
    def test_reply_worker_creates_one_durable_draft_notification(self, _night):
        client = self.db.upsert_client("101", "Иван", "ivan", "approval")
        self.db.enqueue_client_message("e3", client["id"], "Помогите определиться", 0)
        ai = FakeAI()
        app = AgentApp(settings(), self.db, FakeTelegram(), ai, Catalog(self.db))

        self.assertEqual(app.process_due_jobs(), 1)
        self.assertEqual(self.db.stats()["reply_jobs"], 0)
        outbox = self.db.claim_outbox(10)
        self.assertEqual(len(outbox), 1)
        self.assertIn("Предлагаемый ответ", outbox[0]["text"])
        self.assertEqual(ai.queries[0][0], "Помогите определиться")
        self.assertAlmostEqual(float(self.db.monthly_usage()["cost_usd"]), 0.001)

    def test_outbox_dedupe_prevents_double_answer(self):
        first = self.db.enqueue_outbox("100", "Ответ", dedupe_key="reply-job-7")
        second = self.db.enqueue_outbox("100", "Другой ответ", dedupe_key="reply-job-7")
        self.assertEqual(first, second)
        self.assertEqual(len(self.db.claim_outbox(10)), 1)

    def test_owner_edit_session_and_learning_survive_reopen(self):
        client = self.db.upsert_client("102", "", "", "approval")
        draft_id = self.db.create_draft(client["id"], "Старый ответ", 999)
        self.db.start_owner_edit(463497506, draft_id)

        reopened = Database("sqlite:///" + str(self.path))
        reopened.migrate()
        self.assertEqual(reopened.consume_owner_edit(463497506), draft_id)
        reopened.add_correction(client["id"], "Старый ответ", "Правильный ответ", "463497506")
        matches = reopened.approved_corrections("Старый ответ")
        self.assertEqual(matches[0]["corrected_text"], "Правильный ответ")

    def test_encrypted_personal_fields_are_not_plaintext_on_disk(self):
        key = Fernet.generate_key().decode("ascii")
        encrypted = Database("sqlite:///" + str(self.path), key)
        encrypted.migrate()
        client = encrypted.upsert_client("103", "Секретное Имя", "secret_user", "approval")
        encrypted.add_message("secret-event", client["id"], "in", "Мой телефон 12345")
        conn = sqlite3.connect(self.path)
        name = conn.execute("SELECT name FROM clients WHERE external_id='103'").fetchone()[0]
        text = conn.execute("SELECT text FROM messages WHERE event_id='secret-event'").fetchone()[0]
        conn.close()
        self.assertNotIn("Секретное", name)
        self.assertNotIn("12345", text)
        self.assertEqual(encrypted.client_by_id(client["id"])["name"], "Секретное Имя")

    def test_catalog_parser_uses_confirmed_vehicle_detail_urls(self):
        markup = """
        <div class='vehicle-card'>
          <a href='/vehicles/ford/s-max/s-max-2012-sck27306/'>Ford S-MAX I · Рестайлинг</a>
          <div>39 440 BYN</div><div>2012 г. 216 000 км В наличии ул. Горецкого, 6а</div>
        </div>
        <a href='/vehicles/ford/'>Ford</a>
        """
        cars = Catalog(self.db).parse(markup)
        self.assertEqual(len(cars), 1)
        self.assertEqual(cars[0]["brand"], "Ford")
        self.assertEqual(cars[0]["year"], 2012)
        self.assertEqual(cars[0]["price_byn"], 39440)
        self.assertIn("s-max-2012", cars[0]["url"])

    def test_only_owner_approved_price_matches(self):
        self.assertEqual(self.db.matching_approved_prices("Сколько стоит Geely Monjaro?"), [])
        self.db.save_approved_price("Geely Monjaro", "geely monjaro", "125 000 BYN", "owner")
        self.assertIn("125 000 BYN", self.db.matching_approved_prices("Сколько стоит Geely Monjaro?")[0])
        self.assertEqual(self.db.matching_approved_prices("Сколько стоит Geely Coolray?"), [])

    def test_forget_client_removes_pii_and_history_but_keeps_optout(self):
        client = self.db.upsert_client("104", "Личное Имя", "private_user", "approval")
        self.db.add_message("private-event", client["id"], "in", "Секретный телефон")
        self.db.forget_client(client["id"])
        forgotten = self.db.client_by_id(client["id"])
        self.assertEqual(forgotten["name"], "")
        self.assertEqual(forgotten["username"], "")
        self.assertEqual(forgotten["do_not_contact"], 1)
        self.assertEqual(self.db.recent_messages(client["id"]), [])


if __name__ == "__main__":
    unittest.main()
