import unittest
from types import SimpleNamespace
from unittest.mock import patch
from metropol_agent.catalog_selection import select, matches, words
from metropol_agent.conversation import hours_request, handoff_request, leader_request, add_invitation
from test_v330 import car
import test_v340 as workflows

class Rules350(unittest.TestCase):
    def test_seven_peugeots_and_partial_model(self):
        rows = [car(i, 'Peugeot', '3008 I' if i < 3 else '3008 II') for i in range(7)]
        rows.append(car(20, 'Peugeot', '5008 II'))
        for q in ['Peugeot 3008', 'Пежо 3008', '3008', 'А 3008 есть?']:
            result = select(rows, q)
            self.assertEqual(result[0], 'exact')
            self.assertEqual(len(result[1]), 7)
            self.assertEqual(sum(matches(r, words(q)) for r in rows), 7)
            self.assertTrue(all('3008' in r['model_name'] for r in result[1]))

    def test_generation_and_year(self):
        rows = [car(1,'Peugeot','3008 I'), car(2,'Peugeot','3008 II')]
        for q in ['Пежо 3008 второго поколения', 'Peugeot 3008 II', 'Peugeot 3008 2022']:
            self.assertEqual([r['id'] for r in select(rows,q)[1]], [2])
        self.assertNotEqual(select(rows, 'Пежо 300')[0], 'exact')

    def test_handoffs_typo_and_leader(self):
        for q in ['Давай старшего', 'Соедени с менеджером', 'Позови начальника', 'Можно человека', 'Дайте директора']:
            self.assertTrue(handoff_request(q), q)
        self.assertTrue(leader_request('Давай старшего'))
        self.assertFalse(leader_request('Соедени с менеджером'))
        self.assertFalse(handoff_request('Не хочу менеджера'))

    def test_hours(self):
        for q in ['Со скольки работаете', 'Работаете завтра?', 'А в воскресенье работаете?', 'До скольки', 'Во сколько открываетесь?']:
            self.assertTrue(hours_request(q))
        self.assertTrue(hours_request('Давай по всем филиалам',[{'text':'Со скольки работаете'}]))
        self.assertFalse(hours_request('Как провести понедельник?'))

    def test_invitation_cadence_and_sensitive_context(self):
        history = [{'direction':'out','text':'Ответ'}] * 3
        self.assertEqual(add_invitation('Ответ','Танцы',history[:2]), 'Ответ')
        answer = add_invitation('Ответ','Танцы',history)
        self.assertIn('в другой день',answer)
        self.assertIn('Метрополь Авто',answer)
        self.assertEqual(add_invitation('Ответ','Продолжим',history+[{'direction':'out','text':answer}]), 'Ответ')
        for q in ['Не приглашайте меня', 'Умер родственник', 'Жалоба', 'Не хочу покупать']:
            self.assertEqual(add_invitation('Ответ',q,history),'Ответ')

class Integration350(unittest.TestCase):
    setUp = workflows.Workflows340.setUp
    tearDown = workflows.Workflows340.tearDown
    app = workflows.Workflows340.app
    client = workflows.Workflows340.client
    def test_hours_and_handoff_bypass_ai(self):
        a = self.app()
        for i,q in enumerate(['Со скольки работаете', 'Соедени с менеджером', 'Давай старшего']):
            answer = a._prepare_answer(q,[],i,None,f'350-{i}')
            self.assertTrue(answer[1].startswith('local-'))
        self.assertEqual(a.ai.queries,[])

    def test_real_peugeot_availability_not_hallucinated(self):
        a = self.app()
        rows = [car(i,'Peugeot','3008 II') for i in range(7)]
        for row in rows:
            row['url'] = row['url'].replace(' ', '-')
        self.db.replace_catalog(rows)
        result = a._prepare_answer('Есть Пежо 3008?',[],1,None,'350-catalog')
        self.assertEqual(result[1], 'local-catalog')
        self.assertEqual(result[0].count('https://'),7)
        self.assertNotIn('не вижу',result[0])
        self.assertEqual(a.ai.queries,[])

    @patch('metropol_agent.app.is_night',return_value=False)
    def test_leader_routes_to_owner(self, _):
        a=self.app(); c=self.client()
        a.staff.register(900,'Иван'); a.staff.assign(c['id'],900)
        self.db.enqueue_client_message('350-leader',c['id'],'Давай старшего',0)
        a.process_due_jobs()
        self.assertEqual(a.staff.responsible(c['id']),a.settings.owner_id)
        self.assertEqual(self.db.client_by_id(c['id'])['mode'],'human')

    def test_pagination_scope(self):
        a=self.app()
        html = '<a href="?page=2">2</a><a href="https://evil.test/?page=3">3</a><a href="/vehicles/peugeot/3008/card/">car</a>'
        self.assertEqual(a.catalog.page_links(html,'https://metropol-auto.by/vehicles/'),['https://metropol-auto.by/vehicles/?page=2'])

    def test_sync_reads_second_page_and_retains_snapshot_on_failure(self):
        a=self.app()
        def markup(start, end):
            return ''.join(f'<div><a href="/vehicles/peugeot/3008/car-{i}/">Peugeot 3008 II</a> 2022 г. 60 000 BYN В наличии</div>' for i in range(start,end))
        first = markup(0,4) + '<a href="?page=2">2</a>'
        second = markup(4,7)
        with patch('metropol_agent.catalog.httpx.Client') as factory:
            client = factory.return_value.__enter__.return_value
            client.get.side_effect = [SimpleNamespace(text=first,raise_for_status=lambda:None),SimpleNamespace(text=second,raise_for_status=lambda:None)]
            self.assertEqual(a.catalog.sync(),7)
            self.assertEqual(len(self.db.catalog_rows()),7)
            client.get.side_effect = RuntimeError('network unavailable')
            with self.assertRaises(RuntimeError): a.catalog.sync()
            self.assertEqual(len(self.db.catalog_rows()),7)
            self.assertTrue(self.db.get_setting('catalog_last_error'))

    def test_offtopic_with_word_exists_does_not_trigger_catalog(self):
        a=self.app(); self.db.replace_catalog([car(1)])
        a._prepare_answer('Есть рецепт хорошего ужина?',[],1,None,'recipe')
        self.assertEqual(len(a.ai.queries),1)
