import os
import tempfile
import unittest
from pathlib import Path

from metropol_agent.db import Database
from metropol_agent.knowledge import KnowledgeBase, classify_complexity, deterministic_answer


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database("sqlite:///" + str(Path(self.tmp.name) / "db.sqlite"))
        self.db.migrate()

    def tearDown(self):
        self.tmp.cleanup()

    def test_client_and_duplicate_event(self):
        client = self.db.upsert_client("42", "Иван", "ivan", "approval")
        self.assertEqual(client["mode"], "approval")
        self.assertTrue(self.db.add_message("event-1", client["id"], "in", "Здравствуйте"))
        self.assertFalse(self.db.add_message("event-1", client["id"], "in", "Дубль"))

    def test_modes(self):
        client = self.db.upsert_client("1", "", "", "approval")
        self.db.set_mode(client["id"], "auto")
        self.assertEqual(self.db.clients()[0]["mode"], "auto")

    def test_draft(self):
        client = self.db.upsert_client("2", "", "", "approval")
        draft_id = self.db.create_draft(client["id"], "Ответ")
        self.db.update_draft(draft_id, "sent")
        self.assertEqual(self.db.get_draft(draft_id)["status"], "sent")

    def test_local_rules(self):
        self.assertIn("Горецкого", deterministic_answer("Где вы находитесь?").text)
        self.assertIn("без первоначального взноса", deterministic_answer("Нужен первый взнос?").text)
        self.assertNotIn("цена", deterministic_answer("Можно тест драйв?").text.lower())

    def test_complexity(self):
        self.assertEqual(classify_complexity("У меня жалоба руководителю"), "sol")
        self.assertEqual(classify_complexity("Когда работаете?"), "luna")

    def test_knowledge_search(self):
        path = Path(self.tmp.name) / "kb.md"
        path.write_text("## Кредит\nПервый взнос не нужен.\n## Адрес\nГорецкого 6А", "utf-8")
        kb = KnowledgeBase(path)
        self.assertIn("Кредит", kb.search("кредит взнос")[0])


if __name__ == "__main__":
    unittest.main()

