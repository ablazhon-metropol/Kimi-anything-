import os
import unittest
from unittest.mock import patch
from metropol_agent.catalog_selection import select, reply
from metropol_agent.customer_style import decorate, ICONS
from metropol_agent.config import Settings
from metropol_agent.app import AgentApp
from metropol_agent.knowledge import deterministic_answer
import test_reliability as reliability
from metropol_agent.catalog import Catalog

def car(i, brand='BMW', model='X5', price=60000):
    return dict(id=i, brand=brand, model_name=model, title=f'{brand} {model} {2020+i%5}',
                price_byn=price, year=2020+i%5,
                url=f'https://metropol-auto.by/vehicles/{brand.lower()}/{model.lower()}/{i}/')

class Release330(unittest.TestCase):
    def test_no_delay_and_old_debounce_capped(self):
        self.assertEqual(AgentApp._human_delay_seconds('text'*1000),0)
        with patch.dict(os.environ, {'MESSAGE_DEBOUNCE_SECONDS':'8'}):
            self.assertEqual(Settings.from_env().debounce_seconds,2)
        with patch.dict(os.environ, {'MESSAGE_DEBOUNCE_SECONDS':'1'}):
            self.assertEqual(Settings.from_env().debounce_seconds,1)

    def test_exact_model_and_cyrillic(self):
        s=select([car(1),car(2,model='X7')], 'Есть БМВ Х5?')
        self.assertEqual(s[0],'exact')
        self.assertEqual([r['id'] for r in s[1]],[1])

    def test_missing_model_fifteen_distinct_links(self):
        rows=[car(i) for i in range(15)]
        s=select(rows,'Есть BMW X9?')
        self.assertEqual(s[0],'alternatives')
        self.assertEqual(len(s[1]),15)
        text=reply(s)
        self.assertIn('По этим условиям',text)
        self.assertEqual(text.count('https://'),15)
        self.assertNotIn('60000',text)

    def test_no_foreign_or_invented_links(self):
        a=car(1);a['url']='https://evil.example/vehicles/bmw/x5/1/'
        s=select([a,car(2),car(2)],'Покажите машины')
        self.assertEqual(len(s[1]),1)
        self.assertNotIn('evil',reply(s))

    def test_budget_respected_and_unknown_price_excluded(self):
        s=select([car(1,price=50000),car(2,price=80000),car(3,price=None)],'машины до 60 тысяч BYN')
        self.assertEqual([r['id'] for r in s[1]],[1])

    def test_empty_cache_does_not_assert_absence_and_keeps_price(self):
        text=reply(select([],'Есть Changan X5?'),'От 57000 BYN')
        self.assertIn('57000',text)
        self.assertNotIn('модель по вашему запросу сейчас в каталоге не вижу',text)

    def test_general_finance_no_wall_of_links(self):
        self.assertIsNone(select([car(1)],'Есть кредит?'))
        self.assertIsNone(select([car(1)],'Спасибо'))

    def test_trim_not_exact(self):
        self.assertEqual(select([car(1,brand='Geely',model='Atlas')],'Geely Atlas Pro')[0],'alternatives')

    def test_bounded_telegram_message(self):
        rows=[car(i) for i in range(10)]
        for r in rows:r['url']+='a'*400
        self.assertLess(len(reply(select(rows,'машины'), 'X'*300)),4096)

    def test_variety_and_serious_exclusion(self):
        history=[]; used=[]
        for i in range(1,4):
            text=decorate('Приезжайте','Покажите авто',history,i)
            icons=[x for x in ICONS if x in text]
            self.assertEqual(len(icons),1)
            used.extend(icons)
            history.append({'direction':'out','text':text})
        self.assertEqual(len(set(used)),3)
        self.assertEqual(decorate('Ответ','Есть кредит?',[],1),'Ответ')
        self.assertEqual(decorate('Ответ','Жалоба',[],1),'Ответ')

    def test_marketing_not_superlatives(self):
        text=deterministic_answer('Кредит').text
        self.assertIn('выгодные',text)
        self.assertNotIn('лучшие в стране',text)
        self.assertIn('отбираем', deterministic_answer('Тест-драйв').text)

class Integration330(unittest.TestCase):
    setUp = reliability.ReliabilityTests.setUp
    tearDown = reliability.ReliabilityTests.tearDown

    def test_fifteen_requested_links_ready_immediately_in_real_outbox(self):
        self.db.replace_catalog([car(i) for i in range(15)])
        client = self.db.upsert_client('330', 'Сотрудник', '', 'auto')
        self.db.enqueue_client_message('330-question', client['id'], 'Покажите БМВ Х9', 0)
        ai = reliability.FakeAI()
        app = AgentApp(reliability.settings(), self.db, reliability.FakeTelegram(), ai, Catalog(self.db))
        self.assertEqual(app.process_due_jobs(),1)
        out = self.db.claim_outbox(10)
        self.assertEqual(len(out),1)
        self.assertEqual(out[0]['text'].count('https://'),15)
        self.assertIn('По этим условиям',out[0]['text'])
        self.assertEqual(ai.queries,[])
