import json
import unittest
import test_reliability as r
import test_v390 as v390
from test_v330 import car
from metropol_agent.catalog_filters import explicit_year
response = v390.response


class Release391(unittest.TestCase):
    setUp = r.ReliabilityTests.setUp
    tearDown = r.ReliabilityTests.tearDown
    app = v390.Release390.app
    tools = v390.Release390.tools
    answer = v390.Release390.answer

    def inventory(self):
        rows = []
        for i, y in enumerate([2024, 2023, 2023, 2022, 2022, 2022, None]):
            row = car(i, 'Chevrolet', 'Equinox')
            row.update(year=y, title='Chevrolet Equinox III · Рестайлинг')
            if i == 5:
                row['url'] = 'https://metropol-auto.by/vehicles/chevrolet/equinox/equinox-2022-ps141000/'
            rows.append(row)
        self.db.replace_catalog(rows, coverage='verified')

    def args(self, **changes):
        return dict(brand='Chevrolet', model='Equinox', year_min=None, year_max=None,
                    max_price_byn=None, inherit_selection=False, more=False, **changes)

    def call(self, t, **changes):
        args = self.args(); args.update(changes)
        return t.dispatch('catalog', json.dumps(args))

    def test_exact_year_three_cards_and_original_url(self):
        self.inventory(); t = self.tools(self.app(), 'Эквинокс 22 года?')
        result = self.call(t, year_min=2022, year_max=2022)
        self.assertEqual(result['match'], 'exact')
        self.assertEqual([r['year'] for r in result['cards']], [2022]*3)
        self.assertTrue(any('ps141000' in r['url'] for r in result['cards']))
        self.assertEqual(result['facts'].count('https://'), 3)

    def test_year_refinement_resets_paging_even_if_ai_sets_more(self):
        self.inventory(); a = self.app()
        first = self.tools(a, 'Покажи Эквиноксы')
        self.call(first)
        second = self.tools(a, 'А 22 года?')
        result = self.call(second, brand=None, model=None, year_min=2022, year_max=2022,
                           inherit_selection=True, more=True)
        self.assertEqual(len(result['cards']), 3)
        self.assertEqual({r['year'] for r in result['cards']}, {2022})

    def test_explicit_year_overrides_wrong_ai_fields(self):
        self.inventory(); t = self.tools(self.app(), 'Эквинокс 22 года?')
        result = self.call(t, year_min=2023, year_max=2024)
        self.assertEqual({r['year'] for r in result['cards']}, {2022})

    def test_year_range_and_unknown_year_excluded(self):
        self.inventory(); t = self.tools(self.app(), 'С 2022 по 2023')
        result = self.call(t, year_min=2022, year_max=2023)
        self.assertTrue(all(r['year'] in {2022, 2023} for r in result['cards']))
        self.assertEqual(explicit_year('С 2022 по 2023'), None)

    def test_no_wrong_year_alternatives(self):
        self.inventory(); t = self.tools(self.app(), 'Эквинокс 2020 года')
        result = self.call(t, year_min=2020, year_max=2020)
        self.assertFalse(result['cards'])

    def test_russian_plural_new_request_resets_old_budget(self):
        self.inventory(); a = self.app()
        old = self.tools(a, 'Дешевле 1000 BYN')
        self.call(old, max_price_byn=1000)
        new = self.tools(a, 'Покажи эквиноксы')
        result = self.call(new, brand='Шевроле', model='эквиноксы', inherit_selection=True)
        self.assertEqual(result['match'], 'exact')
        self.assertEqual(len(result['cards']), 7)
        self.assertIsNone(result['filters']['max_price_byn'])

    def test_repeated_search_not_more_returns_same_cars(self):
        self.inventory(); a = self.app()
        one = self.call(self.tools(a, 'Покажи эквиноксы'))
        two = self.call(self.tools(a, 'Покажи эквиноксы'), more=True)
        self.assertEqual(one['cards'], two['cards'])

    def test_actual_more_has_different_cards_and_exhaustion_message(self):
        self.inventory(); a = self.app()
        first = self.call(self.tools(a, 'Эквиноксы 2022 года'), year_min=2022, year_max=2022)
        last = self.call(self.tools(a, 'Покажи ещё'), brand=None, model=None,
                          inherit_selection=True, more=True)
        self.assertEqual(last['match'], 'exhausted')
        self.assertIn('уже показаны', last['facts'])
        self.assertNotIn('не могу', last['facts'])
        self.assertEqual(len(first['cards']), 3)

    def test_same_fact_reuses_token(self):
        t = self.tools(self.app())
        one = t.fact('Проверенные сведения.')
        two = t.fact('Проверенные сведения.')
        self.assertEqual(one['fact_token'], two['fact_token'])
        self.assertEqual(t.render(one['fact_token']*2).count('Проверенные сведения.'), 1)

    def test_copied_block_plus_placeholder_no_duplicates(self):
        t = self.tools(self.app())
        one = t.fact('Полный каталог: https://metropol-auto.by/vehicles/')
        text = t.render(one['facts'] + '\n' + one['fact_token'])
        self.assertEqual(text.count('Полный каталог:'), 1)
        self.assertEqual(text.count('https://'), 1)

    def test_failed_search_superseded_by_success(self):
        self.inventory(); t = self.tools(self.app())
        old = self.call(t, year_min=2020, year_max=2020)
        new = self.call(t, year_min=2022, year_max=2022)
        rendered = t.render(old['fact_token'] + new['fact_token'])
        self.assertNotIn('не могу', rendered)
        self.assertEqual(rendered.count('https://'), 3)

    def test_structured_tool_loop(self):
        self.inventory()
        args = self.args(); args.update(year_min=2022, year_max=2022)
        a = self.app([response(tool='catalog', args=args), response('{{FACT_1}}')])
        text = self.answer(a, 'Эквинокс 22 года?')[0]
        self.assertIn('ps141000', text)
        self.assertEqual(text.count('https://'), 3)
        self.assertNotIn('/2023/', text)

    def test_invalid_range_rejected(self):
        self.inventory(); t = self.tools(self.app())
        self.assertIn('error', self.call(t, year_min=2024, year_max=2022))

    def test_year_detection_not_age_or_money(self):
        self.assertEqual(explicit_year('А 22 года?'), 2022)
        self.assertIsNone(explicit_year('Мне 22 года'))
        self.assertIsNone(explicit_year('2022 BYN'))
