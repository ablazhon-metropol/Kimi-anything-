import unittest
import test_reliability as r
from test_v330 import car
from metropol_agent.app import AgentApp
from metropol_agent.catalog import Catalog
from metropol_agent.conversation import add_invitation

class Release382(unittest.TestCase):
    setUp=r.ReliabilityTests.setUp
    tearDown=r.ReliabilityTests.tearDown
    def app(self):
        self.db.save_approved_price('Changan X5 Plus','чанган x5','От 57000 BYN','owner')
        self.db.save_approved_price('BMW X5','бмв x5','От 150000 BYN','owner')
        return AgentApp(r.settings(),self.db,r.FakeTelegram(),r.FakeAI(),Catalog(self.db))
    def answer(self,a,q):
        return a._prepare_answer(q,[],1,None,'test-'+q)
    def test_brand_then_short_choice(self):
        a=self.app()
        self.db.replace_catalog([car(1,'Changan','X5')])
        self.answer(a,'Покажи чанганы')
        for q in ['давай x5','давайте х5','беру x5','выбираю x5','ну тогда x5']:
            answer=self.answer(a,q)
            self.assertEqual(answer[1],'approved-price',q)
            self.assertIn('57000',answer[0],q)
            self.assertNotIn('150000',answer[0])
        self.assertFalse(a.ai.queries)
    def test_explicit_new_brand_wins(self):
        a=self.app();self.answer(a,'Чанган x5')
        self.assertIn('150000',self.answer(a,'давай БМВ х5')[0])
        self.assertIn('150000',self.answer(a,'беру x5')[0])
    def test_unknown_brand_not_guessed(self):
        a=self.app();answer=self.answer(a,'давай x5')
        self.assertIn('марку',answer[0]);self.assertNotIn('57000',answer[0])
    def test_pronoun_after_one_confirmed_selection(self):
        a=self.app();self.answer(a,'Чанган x5')
        self.assertIn('57000',self.answer(a,'беру этот')[0])
    def test_pronoun_after_several_cards_asks(self):
        a=self.app()
        self.db.replace_catalog([car(i,'Changan','X5') for i in range(3)])
        self.answer(a,'Покажи чанганы')
        answer=self.answer(a,'беру этот')[0]
        self.assertIn('Какой вариант',answer)
        self.assertNotIn('57000',answer)
    def test_comparison_does_not_become_selection(self):
        a=self.app();answer=self.answer(a,'Почему Changan X5 лучше?')
        self.assertNotEqual(answer[1],'approved-price')
    def test_price_to_payment(self):
        a=self.app();self.answer(a,'Changan x5')
        self.answer(a,'давай x5')
        self.assertIn('998',self.answer(a,'Посчитай на него платёж в месяц')[0])
    def test_invitation_no_future_plans_template(self):
        history=[{'direction':'out','text':'Вариант подходит.'}]*4
        for sequence in range(3):
            text=add_invitation('Продолжим подбор.','Давай x5',history,sequence)
            self.assertIn('Метрополь',text)
            self.assertNotIn('когда появятся',text)
            self.assertNotIn('Если надумаете',text)
