import json
import re
import unittest
from datetime import datetime, timezone, timedelta
from unittest.mock import patch
from urllib.parse import urlparse, parse_qs
from metropol_agent.answer_checks import clock_context, clock_answer, map_answer, check_answer
from metropol_agent.interactions import working_seconds
from metropol_agent.app import AgentApp
from metropol_agent.catalog import Catalog
import test_reliability as reliability
from test_v330 import car

class Rules360(unittest.TestCase):
    def test_clock_uses_minsk_date_after_utc_midnight_boundary(self):
        stamp=datetime(2026,12,31,22,30,tzinfo=timezone.utc)
        text=clock_context('через 10 дней',stamp)
        self.assertIn('01.01.2027 01:30',text)
        self.assertIn('пятница',text)
        self.assertIn('08.01.2027',text)
        self.assertIn('11.01.2027',text)

    def test_clock_leap_year_and_other_city(self):
        stamp=datetime(2028,2,28,12,tzinfo=timezone.utc)
        self.assertIn('завтра: 29.02.2028',clock_context('',stamp))
        self.assertIn('12:00',clock_answer('Который час в Лондоне?',stamp))
        self.assertIsNone(clock_answer('Как провести понедельник?',stamp))

    def test_map_search_is_encoded_and_not_a_place_verification(self):
        text=map_answer('Покажи на карте кафе рядом с проспектом Победителей, 27, Минск',[])
        url=re.search(r'https://\S+',text)[0]
        self.assertEqual(urlparse(url).netloc,'www.google.com')
        params=parse_qs(urlparse(url).query)
        self.assertEqual(params['api'],['1'])
        self.assertIn('Победителей',params['query'][0])
        self.assertIn('кафе',params['query'][0])

    def test_map_repeat_and_missing_city(self):
        history=[{'direction':'in','text':'Карта: кафе рядом с проспектом Победителей, 27, Минск'},
                 {'direction':'out','text':'Вот карта:'}]
        self.assertIn('https://',map_answer('Где?',history))
        self.assertIn('Уточните город',map_answer('Покажи карту улицы Ленина, 2',[]))
        self.assertEqual(map_answer('Как доехать к вам?',[]).count('https://'),2)

    def test_final_guard_rejects_empty_promise_and_phantom_action(self):
        answer=check_answer('Вот ссылка на карту: https://evil.example/',set())
        self.assertNotIn('Вот ссылка',answer)
        self.assertNotIn('evil',answer)
        answer=check_answer('Передал менеджеру. Peugeot точно есть в наличии.',set())
        self.assertNotIn('Передал',answer)
        self.assertNotIn('есть в наличии',answer)
        self.assertIn('позови менеджера',answer)

    def test_guard_preserves_allowed_link_and_layout(self):
        url='https://metropol-auto.by/vehicles/peugeot/3008/car/'
        text='Нашёл:\n• Peugeot 3008: '+url+'\n\nПриезжайте.'
        self.assertEqual(check_answer(text,{url},True),text)

    def test_ten_work_minutes_exclude_night(self):
        start=datetime(2026,9,2,17,55,tzinfo=timezone.utc) #20:55 Minsk
        self.assertEqual(working_seconds(start,datetime(2026,9,3,5,5,tzinfo=timezone.utc)),600)
        self.assertEqual(working_seconds(start,datetime(2026,9,3,4,59,tzinfo=timezone.utc)),300)

class Workflows360(unittest.TestCase):
    setUp=reliability.ReliabilityTests.setUp
    tearDown=reliability.ReliabilityTests.tearDown

    def app(self): return AgentApp(reliability.settings(),self.db,reliability.FakeTelegram(),reliability.FakeAI(),Catalog(self.db))

    def cars(self):
        rows=[car(i,'Peugeot','3008',price=40000+i*1000) for i in range(7)]
        self.db.replace_catalog(rows); return rows

    def test_all_results_then_exhausted_and_separate_scope(self):
        a=self.app(); self.cars()
        outputs=[]
        for i,q in enumerate(['Покажите Пежо 3008']+['Покажите другие варианты']*3):
            result=a._prepare_answer(q,[],i,1,f'page-{i}')
            outputs.append(re.findall(r'https://\S+',result[0]))
        self.assertEqual(list(map(len,outputs)),[7,0,0,0])
        self.assertEqual(len(set(sum(outputs,[]))),7)
        other=a._prepare_answer('Покажите Пежо 3008',[],1,2,'other')
        self.assertEqual(len(re.findall(r'https://\S+',other[0])),7)

    def test_preferences_survive_recreation_and_filter_cheaper(self):
        a=self.app(); self.cars()
        a._prepare_answer('Покажите Пежо 3008',[],1,1,'first')
        p=a.preferences.get('client:1'); ceiling=min(p['last_prices'])
        a=self.app()
        answer=a._prepare_answer('Покажи дешевле',[],2,1,'cheap')[0]
        shown=a.preferences.get('client:1')
        self.assertEqual(shown['budget'],ceiling-1)
        self.assertTrue(all(n<ceiling for n in shown['last_prices']))
        self.assertEqual(shown['model'],'3008')

    def test_new_model_replaces_old_even_missing_from_catalog(self):
        a=self.app(); rows=self.cars()
        a.preferences.update('client:1','Хочу Пежо 3008',rows)
        p=a.preferences.update('client:1','Есть Пежо 5008?',rows)
        self.assertEqual(p['model'],'5008')
        self.assertNotIn('3008',a.preferences.query('Есть Пежо 5008?',p))

    def test_finance_and_currency_not_converted(self):
        a=self.app(); rows=self.cars()
        p=a.preferences.update('client:1','Пежо 3008 бюджет до 20 тысяч долларов в кредит, есть обмен',rows)
        self.assertEqual(p['budget'],20000)
        self.assertEqual(p['currency'],'USD')
        self.assertEqual(p['finance'],'кредит')
        self.assertTrue(p['trade_in'])
        self.assertNotIn('20000 BYN',a.preferences.query('Покажи варианты',p))

    def test_clock_and_map_do_not_call_ai(self):
        a=self.app()
        for i,q in enumerate(['Какая сегодня дата?', 'Как доехать к вам?']):
            answer=a._prepare_answer(q,[],i,None,f'local-{i}')
            self.assertTrue(answer[1].startswith('local-'))
        self.assertEqual(a.ai.queries,[])

    def test_selection_callback_bound_to_client(self):
        a=self.app(); self.cars()
        c=self.db.upsert_client('400','Клиент','','auto')
        answer=a._prepare_answer('Покажите Пежо 3008',[],1,c['id'],'c')[0]
        markup=a._response_markup(f"client:{c['id']}",'Покажите Пежо 3008',answer)
        data=markup['inline_keyboard'][0][0]['callback_data']
        a._handle_callback({'id':'bad','from':{'id':401},'data':data})
        self.assertEqual(self.db.stats()['reply_jobs'],0)
        a._handle_callback({'id':'ok','from':{'id':400},'data':data})
        self.assertEqual(self.db.stats()['reply_jobs'],1)
        a._handle_callback({'id':'again','from':{'id':400},'data':data})
        self.assertEqual(self.db.stats()['reply_jobs'],1)

    def test_test_visit_button_never_notifies_staff(self):
        a=self.app(); self.cars(); owner=a.settings.owner_id
        answer=a._prepare_answer('Покажите Пежо 3008',[],1,None,'test-c')[0]
        markup=a._response_markup(f'test:{owner}','Покажите Пежо 3008',answer)
        data=markup['inline_keyboard'][0][1]['callback_data']
        a._handle_callback({'id':'visit','from':{'id':owner},'data':data})
        self.assertEqual(self.db._execute('SELECT * FROM handoff_receipts',(),'all'),[])
        self.assertEqual(self.db.stats()['clients'],0)
        out=self.db.claim_outbox(10)
        self.assertTrue(all(str(r['chat_id'])==str(owner) for r in out))

    def test_feedback_requires_explicit_approval_and_dedupes(self):
        a=self.app(); owner=a.settings.owner_id
        markup=a._response_markup(f'test:{owner}','Как провести понедельник?','Сухой ответ')
        data=markup['inline_keyboard'][-1][0]['callback_data']; token=data.split(':')[2]
        a._handle_callback({'id':'fb','from':{'id':owner},'data':data})
        a._handle_owner({'update_id':1},{},'Слишком сухо')
        a._handle_owner({'update_id':2},{},'Кофе и два важных дела — уже хороший старт понедельника.')
        self.assertEqual(self.db.approved_corrections('понедельник'),[])
        a._handle_callback({'id':'no','from':{'id':400},'data':f'x:approve:{token}'})
        self.assertEqual(self.db.approved_corrections('понедельник'),[])
        for i in range(2): a._handle_callback({'id':f'yes-{i}','from':{'id':owner},'data':f'x:approve:{token}'})
        self.assertEqual(len(self.db.approved_corrections('понедельник')),1)
        self.assertEqual(a.ai.queries,[])

    def test_testreset_clears_preferences_not_real_client(self):
        a=self.app(); self.cars(); owner=a.settings.owner_id
        a.preferences.save(f'test:{owner}',{'model':'3008'})
        a.preferences.save('client:1',{'model':'5008'})
        a._handle_owner({'update_id':3},{},'/testreset')
        self.assertEqual(a.preferences.get(f'test:{owner}'),{})
        self.assertEqual(a.preferences.get('client:1')['model'],'5008')

    def test_forget_removes_preferences_and_buttons(self):
        a=self.app(); c=self.db.upsert_client('400','Клиент','','auto')
        scope=f"client:{c['id']}"
        a.preferences.save(scope,{'model':'3008'})
        token=a.sessions.create(scope,{'query':'test'})
        self.db.forget_client(c['id'])
        self.assertEqual(a.preferences.get(scope),{})
        self.assertIsNone(a.sessions.get(token))

    def receipt(self,a):
        c=self.db.upsert_client('400','Клиент','','human')
        a.staff.register(900,'Иван'); a.staff.assign(c['id'],900)
        row=a.handoffs.ensure(c['id'])
        self.db._execute("UPDATE handoff_receipts SET status='notified',notified_at=%s WHERE client_id=%s",('2026-09-02T09:00:00+00:00',c['id']))
        return c,row

    def test_escalation_once_and_acceptance_cancels_queued_notice(self):
        a=self.app(); c,row=self.receipt(a)
        with patch('metropol_agent.interactions.datetime') as clock:
            clock.now.return_value=datetime(2026,9,2,9,11,tzinfo=timezone.utc)
            clock.fromisoformat.side_effect=datetime.fromisoformat
            self.assertEqual(a.handoffs.check(),1)
            self.assertEqual(a.handoffs.check(),0)
        self.assertFalse(a.handoffs.accept(c['id'],901,row['request_id']))
        self.assertTrue(a.handoffs.accept(c['id'],900,row['request_id']))
        with patch('metropol_agent.app.is_night',return_value=False): a.process_outbox()
        self.assertEqual(a.telegram.sent,[])

    def test_night_no_escalation_and_closed_stale_button_rejected(self):
        a=self.app(); c,row=self.receipt(a)
        with patch('metropol_agent.interactions.datetime') as clock:
            clock.now.return_value=datetime(2026,9,2,20,tzinfo=timezone.utc)
            self.assertEqual(a.handoffs.check(),0)
        a.handoffs.close(c['id'])
        self.assertFalse(a.handoffs.accept(c['id'],900,row['request_id']))
        fresh=a.handoffs.ensure(c['id'])
        self.assertNotEqual(fresh['request_id'],row['request_id'])
        self.assertFalse(a.handoffs.accept(c['id'],900,row['request_id']))

    def test_catalog_diagnostics_owner_only(self):
        a=self.app(); self.cars()
        text=a._catalog_diagnostics('Пежо 3008')
        self.assertIn('7 доступных',text)
        self.assertEqual(text.count('https://'),7)
        a._handle_callback({'id':'bad','from':{'id':400},'data':'owner:catalog'})
        self.assertEqual(self.db.claim_outbox(10),[])

    def test_model_in_ai_discussion_does_not_mark_cards_as_shown(self):
        a=self.app(); self.cars()
        a._prepare_answer('Почему Peugeot 3008 лучше?',[],1,None,'compare')
        self.assertNotIn('shown',a.preferences.get(f'test:{a.settings.owner_id}'))
        result=a._prepare_answer('Покажите другие варианты',[],2,None,'show')[0]
        self.assertEqual(result.count('https://'),7)

    def test_generation_remains_for_followup(self):
        a=self.app(); rows=self.cars()
        p=a.preferences.update('client:1','Пежо 3008 второго поколения',rows)
        self.assertEqual(p['generation'],'ii')
        self.assertIn('ii',a.preferences.query('Покажи варианты',p))

    def test_stale_selection_button_does_not_revert_new_preferences(self):
        a=self.app(); self.cars(); c=self.db.upsert_client('400','Клиент','','auto')
        scope=f"client:{c['id']}"
        answer=a._prepare_answer('Покажите Пежо 3008',[],1,c['id'],'old')[0]
        data=a._response_markup(scope,'Пежо 3008',answer)['inline_keyboard'][0][0]['callback_data']
        a._prepare_answer('Покажите Пежо 5008',[],2,c['id'],'new')
        a._handle_callback({'id':'stale','from':{'id':400},'data':data})
        self.assertEqual(self.db.stats()['reply_jobs'],0)

    @patch('metropol_agent.app.is_night',return_value=False)
    def test_receipt_clock_starts_after_delivery_and_take_button_accepts(self,_):
        a=self.app(); c=self.db.upsert_client('400','Клиент','','auto')
        a.staff.register(900,'Иван'); a.staff.assign(c['id'],900)
        self.db.enqueue_client_message('manager',c['id'],'Позови менеджера',0)
        a.process_due_jobs()
        row=self.db._execute('SELECT * FROM handoff_receipts WHERE client_id=%s',(c['id'],),'one')
        self.assertIsNone(row['notified_at'])
        a.process_outbox()
        row=self.db._execute('SELECT * FROM handoff_receipts WHERE client_id=%s',(c['id'],),'one')
        self.assertIsNotNone(row['notified_at'])
        self.assertEqual(row['status'],'notified')
        a._handle_callback({'id':'take','from':{'id':900},'data':f"take:{c['id']}:{row['request_id']}"})
        self.assertEqual(self.db._execute('SELECT status FROM handoff_receipts WHERE client_id=%s',(c['id'],),'one')['status'],'accepted')

    def test_cancel_feedback_does_not_train(self):
        a=self.app(); owner=a.settings.owner_id
        markup=a._response_markup(f'test:{owner}','Вопрос','Ответ')
        a._handle_callback({'id':'bad','from':{'id':owner},'data':markup['inline_keyboard'][0][0]['callback_data']})
        a._handle_owner({'update_id':1},{},'Неверный ответ')
        a._handle_owner({'update_id':2},{},'/cancel')
        self.assertEqual(self.db.approved_corrections('Вопрос'),[])
        self.assertEqual(self.db.get_setting('feedback-input'),'')

    def test_recipe_request_not_catalog(self):
        a=self.app(); self.cars()
        result=a._prepare_answer('Покажите рецепт пирога',[],1,None,'pie')
        self.assertEqual(result[1],'fake-luna')
