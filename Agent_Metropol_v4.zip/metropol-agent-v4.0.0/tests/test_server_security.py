import importlib
import os
import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient


class AdminSecurityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        os.environ["DATABASE_URL"] = "sqlite:///" + str(Path(cls.tmp.name) / "server.sqlite")
        os.environ["ADMIN_TOKEN"] = "test-admin-secret"
        os.environ["TELEGRAM_BOT_TOKEN"] = ""
        os.environ["OPENAI_API_KEY"] = ""
        os.environ["PUBLIC_BASE_URL"] = ""
        cls.server = importlib.import_module("metropol_agent.server")
        cls.client = TestClient(cls.server.api)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_admin_token_in_url_is_not_accepted(self):
        response = self.client.get("/admin?token=test-admin-secret", follow_redirects=False)
        self.assertEqual(response.status_code, 303)
        self.assertEqual(response.headers["location"], "/admin/login")

    def test_health_reports_version_and_database(self):
        response = self.client.get("/health")
        self.assertEqual(response.status_code, 200)
        payload = response.json()
        self.assertEqual(payload["version"], "4.0.0")
        self.assertTrue(payload["database"]["ok"])

    def test_login_uses_http_only_cookie(self):
        response = self.client.post(
            "/admin/login", data={"token": "test-admin-secret"}, follow_redirects=False
        )
        self.assertEqual(response.status_code, 303)
        self.assertIn("HttpOnly", response.headers["set-cookie"])
        dashboard = self.client.get("/admin")
        self.assertEqual(dashboard.status_code, 200)
        self.assertIn("Агент Метрополь v4.0.0", dashboard.text)

    def test_knowledge_and_price_forms_persist_immediately(self):
        self.client.post("/admin/login", data={"token": "test-admin-secret"})
        knowledge = self.client.post(
            "/admin/knowledge", data={"title": "Тест", "body": "Утверждённое правило"}, follow_redirects=False
        )
        price = self.client.post(
            "/admin/prices",
            data={"label": "Geely Monjaro", "matcher": "geely monjaro", "price_text": "125 000 BYN"},
            follow_redirects=False,
        )
        self.assertEqual(knowledge.status_code, 303)
        self.assertEqual(price.status_code, 303)
        self.assertIn("Утверждённое правило", self.server.db.search_knowledge("тест")[0])
        self.assertIn("125 000 BYN", self.server.db.matching_approved_prices("geely monjaro")[0])


if __name__ == "__main__":
    unittest.main()
