import unittest
from metropol_agent.finance_policy import STATEMENT, DECISION, with_statistic
import test_reliability as reliability
from metropol_agent.app import AgentApp
from metropol_agent.catalog import Catalog

class FinancePolicy(unittest.TestCase):
    def test_attributed_and_no_personal_probability(self):
        for query in ['Есть кредит?', 'Есть лизинг?', 'Одобрят ли мне?']:
            answer=with_statistic('Поможем подобрать условия.',query,[])
            self.assertIn(STATEMENT,answer)
            self.assertIn(DECISION,answer)
            self.assertEqual(answer.count('99%'),1)

    def test_bad_personal_percent_replaced(self):
        text=with_statistic('Вам одобрят с вероятностью 99%.', 'Одобрят ли мне кредит?', [])
        self.assertNotIn('Вам одобрят',text)
        self.assertIn(STATEMENT,text)

    def test_not_added_to_other_topics_or_every_turn(self):
        self.assertEqual(with_statistic('Ответ','Какая сегодня дата?',[]),'Ответ')
        self.assertEqual(with_statistic('Ответ','А срок кредита?', [{'direction':'out','text':STATEMENT}]),'Ответ')
        self.assertIn(STATEMENT,with_statistic('Ответ','Какая статистика одобрений?', [{'direction':'out','text':STATEMENT}]))

class FinanceIntegration(unittest.TestCase):
    setUp=reliability.ReliabilityTests.setUp
    tearDown=reliability.ReliabilityTests.tearDown

    def test_shared_live_and_test_answer_path(self):
        app=AgentApp(reliability.settings(),self.db,reliability.FakeTelegram(),reliability.FakeAI(),Catalog(self.db))
        for i,cid in enumerate([None,1]):
            answer=app._prepare_answer('Какие условия лизинга?',[],i,cid,f'finance-{i}')[0]
            self.assertIn(STATEMENT,answer)
            self.assertIn(DECISION,answer)
