import json
import unittest
from types import SimpleNamespace
from unittest.mock import patch

import test_reliability as r
from test_v330 import car
from metropol_agent.ai import AIEngine
from metropol_agent.app import AgentApp
from metropol_agent.catalog import Catalog
from metropol_agent.agent_tools import AgentTools, TOOLS


def response(text="", tool=None, args=None, index=1):
    output = [{"type": "function_call", "name": tool, "arguments": json.dumps(args), "call_id": "call" + str(index)}] if tool else []
    return SimpleNamespace(output=output, output_text=text,
                           usage=SimpleNamespace(input_tokens=100, output_tokens=50))


class Responses:
    def __init__(self, items):
        self.items, self.calls = list(items), []
        self.responses = self
    def with_options(self, **kwargs):
        return self
    def create(self, **kwargs):
        self.calls.append(kwargs)
        item = self.items.pop(0)
        if isinstance(item, Exception):
            raise item
        return item


class Release390(unittest.TestCase):
    setUp = r.ReliabilityTests.setUp
    tearDown = r.ReliabilityTests.tearDown

    def app(self, responses=()):
        cfg = r.settings()
        cfg.openai_api_key = ""
        cfg.sol_enabled = False
        cfg.monthly_budget_usd = 100
        cfg.luna_model, cfg.sol_model = "gpt-5.6-luna", "gpt-5.6-sol"
        cfg.luna_input_rate, cfg.luna_output_rate = .2, 1.2
        cfg.sol_input_rate, cfg.sol_output_rate = 4., 20.
        ai = AIEngine(cfg, SimpleNamespace(search=lambda *a, **kw: []))
        ai.client = Responses(responses)
        return AgentApp(cfg, self.db, r.FakeTelegram(), ai, Catalog(self.db))

    def tools(self, a, query="", history=(), scope="test:1"):
        return AgentTools(a, scope, query, list(history), lambda _: "Тест: уведомления не отправлены.")

    def answer(self, a, q, history=(), event="test"):
        return a._prepare_answer(q, list(history), 1, None, event)

    def price(self):
        return self.db.save_approved_price("Changan X5 Plus", "чанган x5", "От 57000 BYN", "owner")

    def credit_args(self, **kwargs):
        return {"source": "approved", "reference": str(self.price()), "amount": None, "currency": "BYN", "months": 120, "down": "0", "down_currency": "BYN", "down_percent": None, **kwargs}

    def test_every_plain_question_calls_ai(self):
        for i, q in enumerate(["Привет", "Сколько работаете", "Покажи чанганы", "Давай х5", "Платёж"]):
            a = self.app([response("Давайте уточним.")])
            self.answer(a, q, event=str(i))
            self.assertEqual(len(a.ai.client.calls), 1)
            self.assertEqual(a.ai.client.calls[0]["input"][-1]["content"], q)

    def test_price_tool_then_natural_answer(self):
        self.price()
        a = self.app([response(tool="approved_price", args={"model": "Changan X5"}), response("{{FACT_1}} Можем посмотреть его вместе на площадке.")])
        answer = self.answer(a, "Давай х5", [{"direction": "in", "text": "Хочу Чанган"}])
        self.assertIn("57000 BYN", answer[0])
        self.assertNotIn("FACT", answer[0])
        self.assertEqual(answer[1], "gpt-5.6-luna")
        self.assertEqual(answer[2]["input_tokens"], 200)
        self.assertAlmostEqual(float(self.db.monthly_usage()["cost_usd"]), answer[2]["cost_usd"])
        self.assertEqual(a.ai.client.calls[1]["input"][-1]["type"], "function_call_output")

    def test_price_credit_chain_and_cost(self):
        args = self.credit_args()
        a = self.app([response(tool="approved_price", args={"model": "Changan X5"}),
                      response(tool="credit", args=args, index=2), response("{{FACT_2}}")])
        answer = self.answer(a, "Какой платёж по Changan X5?")
        self.assertIn("998 BYN", answer[0])
        self.assertIn("10 лет", answer[0])
        self.assertNotIn("процентов —", answer[0])
        self.assertEqual(answer[2]["output_tokens"], 150)

    def test_bill_preserved_if_second_request_fails(self):
        self.price()
        a = self.app([response(tool="approved_price", args={"model": "Changan X5"}), RuntimeError("private transport details")])
        answer = self.answer(a, "цена X5")
        self.assertIn("57000", answer[0])
        self.assertIn("api-error", answer[1])
        self.assertGreater(float(self.db.monthly_usage()["cost_usd"]), 0)
        self.assertNotIn("private", a.ai.last_error)

    def test_reasoning_items_round_trip(self):
        a = self.app()
        item = response(tool="information", args={"topic": "hours", "query": ""})
        item.output.insert(0, {"type": "reasoning", "id": "rs_test", "summary": []})
        a.ai.client.items = [item, response("{{FACT_1}}")]
        self.answer(a, "Часы?")
        self.assertIn(item.output[0], a.ai.client.calls[1]["input"])
        self.assertFalse(a.ai.client.calls[0]["store"])
        self.assertFalse(a.ai.client.calls[0]["parallel_tool_calls"])

    def test_latest_message_and_context_bound(self):
        a = self.app([response("Хорошо.")])
        self.answer(a, "Спасибо", [{"direction": "in", "text": "а" * 1000}] * 20)
        history = a.ai.client.calls[0]["input"]
        self.assertLessEqual(len(history), 12)
        self.assertLessEqual(sum(len(m["content"]) for m in history), 3500)
        self.assertEqual(history[-1]["content"], "Спасибо")

    def test_no_key_and_budget_no_fake_thinking(self):
        a = self.app(); a.ai.client = None
        answer = self.answer(a, "Привет")
        self.assertIn("не удалось", answer[0]); self.assertEqual(answer[1], "ai-unavailable-no-key")
        a = self.app(); a.settings.monthly_budget_usd = 0
        answer = self.answer(a, "Привет")
        self.assertEqual(answer[1], "ai-budget-limit"); self.assertFalse(a.ai.client.calls)

    def test_loop_limit(self):
        a = self.app([response(tool="information", args={"topic": "hours", "query": ""}, index=i) for i in range(6)])
        answer = self.answer(a, "Часы")
        self.assertEqual(len(a.ai.client.calls), 6)
        self.assertIn("limited", answer[1])

    def test_schema_and_local_argument_validation(self):
        t = self.tools(self.app())
        for spec in TOOLS:
            self.assertTrue(spec["strict"])
            self.assertFalse(spec["parameters"]["additionalProperties"])
            self.assertEqual(set(spec["parameters"]["required"]), set(spec["parameters"]["properties"]))
        for name, raw in [("delete_all", "{}"), ("handoff", '{"target":"leader","client_id":999}'),
                          ("catalog", '{"query":"Changan","more":1}'), ("map", "[]"), ("rates", "broken")]:
            self.assertIn("error", t.dispatch(name, raw))
        self.assertFalse(t.handoff_text)

    def test_ambiguous_x5_never_selects_price(self):
        self.price(); self.db.save_approved_price("BMW X5", "бмв x5", "150000 BYN", "owner")
        result = self.tools(self.app()).tool_approved_price("X5")
        self.assertEqual(result["status"], "ambiguous")
        self.assertEqual(len(result["choices"]), 2)

    def test_changan_search_never_returns_geely(self):
        self.db.replace_catalog([car(i, "Changan", "X5") for i in range(5)] + [car(99, "Geely", "Coolray")], coverage="verified")
        t = self.tools(self.app())
        first = t.tool_catalog("Changan", False)
        second = t.tool_catalog("Changan", True)
        self.assertEqual(len(first["cards"]), 5)
        self.assertEqual(len(second["cards"]), 0)
        self.assertNotIn("Geely", first["facts"])

    def test_full_catalog_not_three_cars(self):
        a = self.app([response(tool="information", args={"topic": "full_catalog", "query": ""}), response("{{FACT_1}}")])
        result = self.answer(a, "Дай весь каталог")[0]
        self.assertEqual(result.count("https://"), 1)
        self.assertIn("https://metropol-auto.by/vehicles/", result)

    def test_inventory_count_not_page_count(self):
        self.db.replace_catalog([car(i, "Peugeot", "3008") for i in range(7)], coverage="verified")
        t = self.tools(self.app())
        result = t.tool_inventory("Peugeot 3008", "cars")
        self.assertIn("7 автомобилей", result["facts"])
        self.assertIn("Данные на", result["facts"])

    def test_partial_inventory_warning_mandatory(self):
        self.db.replace_catalog([car(1)], coverage="unknown")
        t = self.tools(self.app()); t.tool_inventory("", "cars")
        self.assertIn("полнота загрузки", t.render("{{FACT_1}}"))

    def test_cross_scope_credit_id_not_allowed(self):
        args = self.credit_args(); t = self.tools(self.app())
        self.assertEqual(t.tool_credit(**args)["error"], "lookup_approved_price_first")

    def test_approved_price_reloaded_before_calculation(self):
        args = self.credit_args(); a = self.app(); t = self.tools(a)
        t.tool_approved_price("Changan X5")
        self.db.save_approved_price("Changan X5 Plus", "чанган x5", "От 60000 BYN", "owner", int(args["reference"]))
        result = t.tool_credit(**args)
        self.assertEqual(result["assumptions"]["amount"], "60000")
        self.assertNotIn('57000', t.render(result['fact_token']))

    def test_customer_amount_requires_customer_evidence(self):
        args = self.credit_args(source="customer", amount="60000")
        a = self.app()
        self.assertIn("error", self.tools(a, "Рассчитай", [{"direction": "out", "text": "60000 BYN"}]).tool_credit(**args))
        result = self.tools(a, "Рассчитай 60000 BYN").tool_credit(**args)
        self.assertIn("BYN в месяц", result["facts"])

    def test_last_known_exchange_rate_used(self):
        self.db.set_setting("nbrb-rates", json.dumps({"rates": {"USD": {"rate": "3", "scale": 1, "date": "2025-01-01"}}, "error": "timeout"}))
        t = self.tools(self.app())
        self.assertIn("последнему известному", t.tool_rates("USD")["facts"])

    def test_fabricated_price_and_url_replaced(self):
        self.price(); t = self.tools(self.app()); t.tool_approved_price("Changan X5")
        answer = t.render("Цена 1 BYN: https://evil.example")
        self.assertIn("57000", answer); self.assertNotIn("evil", answer); self.assertNotIn("1 BYN", answer)

    def test_map_has_actual_url(self):
        t = self.tools(self.app()); result = t.tool_map("Минск Горецкого 6А Метрополь")
        self.assertIn("https://www.google.com/maps/search/?", t.render(result["fact_token"]))

    def test_test_handoff_does_not_notify(self):
        a = self.app([response(tool="handoff", args={"target": "leader"})])
        answer = self.answer(a, "Давай старшего")
        self.assertIn("Тест:", answer[0]); self.assertEqual(answer[3], "handoff")
        self.assertFalse(self.db.claim_outbox(20)); self.assertFalse(self.db.pending_notifications())

    @patch("metropol_agent.app.is_night", return_value=False)
    def test_real_handoff_queues_once_without_draft(self, _):
        a = self.app([response(tool="handoff", args={"target": "manager"})])
        client = self.db.upsert_client("100", "Иван", "", "auto")
        self.db.enqueue_client_message("client-event", client["id"], "Хочу живого собеседника", 0)
        self.assertEqual(a.process_due_jobs(), 1)
        self.assertEqual(a.process_due_jobs(), 0)
        self.assertEqual(self.db.client_by_id(client["id"])["mode"], "human")
        outgoing = self.db.claim_outbox(20)
        self.assertEqual(len(outgoing), 2)
        self.assertEqual(sum("Нужен сотрудник" in x["text"] for x in outgoing), 1)
        self.assertGreater(float(self.db.monthly_usage()["cost_usd"]), 0)

    def test_admin_menu_stays_local(self):
        a = self.app()
        a._handle_owner({"update_id": "menu-test"}, {}, "/menu")
        self.assertFalse(a.ai.client.calls)

    def test_percent_deposit_is_calculated_in_code(self):
        args = self.credit_args(down_percent="10")
        t = self.tools(self.app()); t.tool_approved_price("Changan X5")
        result = t.tool_credit(**args)
        self.assertIn("898 BYN", result["facts"])

    def test_wrong_price_response_repaired_through_ai(self):
        self.price()
        a = self.app([response("Цена 1 BYN."), response(tool="approved_price", args={"model": "Changan X5"}), response("{{FACT_1}}")])
        answer = self.answer(a, "Цена Changan X5")
        self.assertIn("57000", answer[0]); self.assertNotIn("1 BYN", answer[0])
        self.assertEqual(len(a.ai.client.calls), 3)

    def test_client_optout_blocks_tools(self):
        a = self.app(); client = self.db.upsert_client("200", "", "", "auto")
        self.db.set_do_not_contact(client['id'], True)
        t = self.tools(a, scope=f"client:{client['id']}")
        self.assertEqual(t.dispatch('handoff', '{"target":"manager"}')["error"], "conversation_disabled")

    def test_catalog_buttons_expire_on_filter_change(self):
        self.db.replace_catalog([car(1, 'Changan', 'X5'), car(2, 'Geely', 'Coolray')])
        a = self.app(); t = self.tools(a)
        t.tool_catalog('Changan', False)
        first = a.preferences.get(t.scope)['signature']
        t.tool_catalog('Geely', False)
        self.assertNotEqual(first, a.preferences.get(t.scope)['signature'])

    def test_multi_tool_answer_bounded(self):
        self.db.replace_catalog([car(i) for i in range(15)])
        t = self.tools(self.app())
        for _ in range(6):
            t.tool_catalog('BMW', True)
        text = t.render('')
        self.assertLessEqual(len(text), 3800)
        self.assertLessEqual(text.count('https://'), 3)

    def test_openai_sdk_tool_serialization_without_network(self):
        import httpx
        from openai import OpenAI
        requests = []
        def handler(request):
            requests.append(json.loads(request.content))
            if len(requests) == 1:
                output = [{"type":"function_call", "id":"fc_1", "call_id":"call_1", "name":"information", "arguments":'{"topic":"hours","query":""}', "status":"completed"}]
            else:
                output = [{"type":"message", "id":"msg_1", "role":"assistant", "status":"completed", "content":[{"type":"output_text", "text":"{{FACT_1}}", "annotations":[]}]}]
            return httpx.Response(200, json={"id":"resp_test", "object":"response", "created_at":1,
                "status":"completed", "model":"gpt-5.6-luna", "output":output,
                "usage":{"input_tokens":100,"output_tokens":50,"total_tokens":150}})
        a = self.app()
        with httpx.Client(transport=httpx.MockTransport(handler)) as http_client:
            a.ai.client = OpenAI(api_key='test-not-a-real-key', http_client=http_client)
            result = self.answer(a, 'Когда открываетесь?')
        self.assertIn('9:00', result[0]); self.assertEqual(len(requests), 2)
        self.assertEqual(requests[1]['input'][-1]['call_id'], 'call_1')
        self.assertEqual(requests[1]['input'][-1]['type'], 'function_call_output')
