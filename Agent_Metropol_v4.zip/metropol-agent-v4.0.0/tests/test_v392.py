import unittest
from unittest.mock import patch
import test_reliability as r
import test_v390 as v390
from metropol_agent.dialogue_policy import apply, extract
from metropol_agent.web_research import cited_answer, public_query


def web_response():
    response = v390.response()
    text = 'В прогнозе ожидается дождь. [источник]'
    response.output = [dict(type='web_search_call', status='completed', action={'type':'search'}),
        dict(type='message', content=[dict(type='output_text', text=text, annotations=[dict(type='url_citation',
             start_index=text.index('[источник]'), end_index=len(text), url='https://example.org/weather', title='Прогноз')])])]
    response.output_text = text
    return response


class Release392(unittest.TestCase):
    setUp = r.ReliabilityTests.setUp
    tearDown = r.ReliabilityTests.tearDown
    app = v390.Release390.app
    answer = v390.Release390.answer
    tools = v390.Release390.tools

    def say(self, a, event, query='Как провести вечер?', topic='offtopic', invitation='', scope='test:1'):
        return apply(a.preferences, scope, query, 'Можно прогуляться.', topic, invitation, event)

    def test_third_offtopic_reply_invites_then_resets(self):
        a = self.app()
        self.assertNotIn('Метрополь', self.say(a, '1'))
        self.assertNotIn('Метрополь', self.say(a, '2'))
        third = self.say(a, '3')
        self.assertIn('Метрополь', third)
        self.assertEqual(a.preferences.get('test:1')['dialogue']['count'], 0)
        self.assertNotIn('Метрополь', self.say(a, '4'))
        self.say(a, '5')
        self.assertNotEqual(third, self.say(a, '6'))

    def test_counter_persists_across_instances(self):
        self.say(self.app(), '1'); self.say(self.app(), '2')
        self.assertIn('Метрополь', self.say(self.app(), '3'))

    def test_counter_scope_and_duplicate_event(self):
        a = self.app(); self.say(a, '1'); self.say(a, '1')
        self.assertEqual(a.preferences.get('test:1')['dialogue']['count'], 1)
        self.say(a, '2', scope='client:2')
        self.assertEqual(a.preferences.get('client:2')['dialogue']['count'], 1)

    def test_sensitive_postpones_invitation(self):
        a = self.app(); self.say(a, '1'); self.say(a, '2')
        self.assertNotIn('Метрополь', self.say(a, '3', query='Умер близкий человек'))
        self.assertNotIn('Метрополь', self.say(a, '4', query='Спасибо'))

    def test_business_resets_count(self):
        a = self.app(); self.say(a, '1'); self.say(a, '2')
        self.say(a, '3', topic='business')
        self.assertEqual(a.preferences.get('test:1')['dialogue']['count'], 0)

    def test_contextual_invitation_used(self):
        a = self.app(); self.say(a, '1'); self.say(a, '2')
        message = 'А машину для поездок на природу посмотрим в Метрополь Авто — заглядывайте!'
        self.assertIn(message, self.say(a, '3', invitation=message))

    def test_alcohol_invites_another_day(self):
        a = self.app(); self.say(a, '1'); self.say(a, '2')
        self.assertIn('в другой день', self.say(a, '3', query='Выпил пиво', invitation='Приезжайте сейчас в Метрополь Авто!'))

    def test_markers_not_visible(self):
        a = self.app([v390.response('[[TOPIC:offtopic]]Хорошего вечера! [[INVITE]]Загляните в Метрополь Авто.[[/INVITE]]')])
        text = self.answer(a, 'Как настроение?')[0]
        self.assertNotIn('[[', text)
        self.assertNotIn('Загляните', text)  # Too early in conversation.

    def test_no_search_for_smalltalk(self):
        a = self.app([v390.response('[[TOPIC:offtopic]]Всё хорошо!')])
        self.answer(a, 'Как настроение?')
        self.assertEqual(len(a.ai.client.calls), 1)

    def test_web_tool_loop_sources_and_cost(self):
        a = self.app([v390.response(tool='internet_search', args={'query':'Погода в Минске сегодня'}),
                      web_response(), v390.response('[[TOPIC:offtopic]]{{FACT_1}}')])
        result = self.answer(a, 'Какая погода сегодня в Минске?')
        self.assertIn('https://example.org/weather', result[0])
        self.assertNotIn('[источник]', result[0])
        search = a.ai.client.calls[1]
        self.assertEqual(search['tool_choice'], 'required')
        self.assertEqual(search['tools'][0]['type'], 'web_search')
        self.assertIsInstance(search['input'], str)
        self.assertGreaterEqual(result[2]['cost_usd'], .01)
        self.assertAlmostEqual(float(self.db.monthly_usage()['cost_usd']), result[2]['cost_usd'])

    def test_citations_required(self):
        response = web_response(); response.output[1]['content'][0]['annotations'] = []
        with self.assertRaises(ValueError): cited_answer(response)

    def test_search_must_really_run(self):
        response = web_response(); response.output = response.output[1:]
        with self.assertRaises(ValueError): cited_answer(response)

    def test_sensitive_query_and_company_price_not_sent_to_search(self):
        for q in ['Пароль secret123', 'Телефон +375 29 1234567', 'Цена в Метрополь Авто', 'user@example.com']:
            with self.assertRaises(ValueError, msg=q): public_query(q)

    def test_search_error_is_honest(self):
        a = self.app([v390.response(tool='internet_search', args={'query':'Погода в Минске'}),
                      RuntimeError('private API information'), v390.response('[[TOPIC:offtopic]]{{FACT_1}}')])
        result = self.answer(a, 'Погода в Минске?')
        self.assertIn('не удалось проверить', result[0])
        self.assertNotIn('private', result[0])

    def test_search_missing_citations_still_recorded(self):
        response = web_response(); response.output[1]['content'][0]['annotations'] = []
        a = self.app([v390.response(tool='internet_search', args={'query':'Погода в Минске'}),
                      response, v390.response('[[TOPIC:offtopic]]{{FACT_1}}')])
        result = self.answer(a, 'Погода в Минске?')
        self.assertIn('не удалось проверить', result[0])
        self.assertGreaterEqual(float(self.db.monthly_usage()['cost_usd']), .01)

    def test_search_sources_keep_inline_repeated_citations(self):
        t = self.tools(self.app()); t.web_urls.add('https://example.org/weather')
        fact = t.fact('Один факт (https://example.org/weather). Другой факт (https://example.org/weather).')
        self.assertEqual(t.render(fact['fact_token']).count('https://'), 2)

    def test_native_web_search_sdk_transport(self):
        import json
        import httpx
        from openai import OpenAI
        requests = []
        def handler(request):
            body = json.loads(request.content); requests.append(body)
            if len(requests) == 1:
                output = [dict(type='function_call', id='fc1', call_id='c1', name='internet_search', arguments='{"query":"Погода в Минске"}', status='completed')]
            elif len(requests) == 2:
                output = web_response().output
                output[0]['id'] = 'ws1'; output[0]['action']['query'] = 'Погода в Минске'
                output[1].update(id='msg2', role='assistant', status='completed')
            else:
                output = [dict(type='message', id='msg3', role='assistant', status='completed', content=[dict(type='output_text', text='[[TOPIC:offtopic]]{{FACT_1}}', annotations=[])])]
            return httpx.Response(200, json=dict(id='resp1', object='response', created_at=1, model='gpt-5.6-luna', status='completed', output=output, usage=dict(input_tokens=100,output_tokens=50,total_tokens=150)))
        a = self.app()
        with httpx.Client(transport=httpx.MockTransport(handler)) as client:
            a.ai.client = OpenAI(api_key='test-not-real', http_client=client)
            answer = self.answer(a, 'Погода в Минске?')
        self.assertIn('https://example.org/weather', answer[0])
        self.assertEqual(len(requests), 3)
        self.assertEqual(requests[1]['tools'][0]['type'], 'web_search')

    @patch('metropol_agent.app.is_night', return_value=False)
    def test_handoff_ack_not_cancelled_by_human_mode(self, _):
        a = self.app([v390.response(tool='handoff', args={'target':'manager'})])
        client = self.db.upsert_client('100', 'Иван', '', 'auto')
        self.db.enqueue_client_message('handoff-real', client['id'], 'Позови человека', 0)
        a.process_due_jobs()
        for _ in range(4): a.process_outbox()
        self.assertTrue(any(chat == '100' and 'Запрос сотруднику сохранён' in text for chat, text, _ in a.telegram.sent))
