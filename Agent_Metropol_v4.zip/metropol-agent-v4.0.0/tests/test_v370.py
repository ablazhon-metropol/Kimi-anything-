import json
import unittest
from datetime import datetime, timedelta
from decimal import Decimal
from unittest.mock import patch, MagicMock
from metropol_agent.app import AgentApp
from metropol_agent.catalog import Catalog
from metropol_agent.credit import monthly, money, calculate
from metropol_agent.exchange import ExchangeRates, MINSK
from metropol_agent.conversation import CATALOG_URL, plain_text
from metropol_agent.commerce import guard_money
import test_reliability as reliability
from test_v330 import car

class Release370(unittest.TestCase):
    setUp = reliability.ReliabilityTests.setUp
    tearDown = reliability.ReliabilityTests.tearDown

    def app(self):
        return AgentApp(reliability.settings(),self.db,reliability.FakeTelegram(),reliability.FakeAI(),Catalog(self.db))

    def price(self,amount='От 63000 белорусских рублей.',price_id=None):
        return self.db.save_approved_price('Geely Coolray','Джили кулрей; кулек',amount,'owner',price_id)

    def answer(self,a,q,history=None,client=None):
        return a._prepare_answer(q,history or [],1,client,'test-'+q)[0]

    def test_owner_aliases_and_variants_no_ai(self):
        self.price(); a=self.app()
        for q in ['По чем кульки','Почём кулёк?','Цена Geely Coolray','Сколько стоит Джили Кулрей?', 'Сколько стоят кульки']:
            with self.subTest(q=q):
                result=self.answer(a,q)
                self.assertIn('63000',result)
                self.assertIn('От ',result)
                self.assertNotIn('налич',result)
        self.assertEqual(a.ai.queries,[])

    def test_single_word_custom_alias(self):
        self.db.save_approved_price('Geely Atlas','атласик','От 70000 BYN','owner')
        self.assertIn('70000',self.answer(self.app(),'Цена атласик'))

    def test_alias_collision_asks_and_brand_alone_no_price(self):
        self.price()
        self.db.save_approved_price('Geely Atlas','кулек','От 70000 BYN','owner')
        a=self.app()
        self.assertIn('Уточните',self.answer(a,'Цена кулёк'))
        self.assertNotIn('63000',self.answer(a,'Цена Geely'))

    def test_short_model_codes(self):
        self.db.save_approved_price('Changan X5 Plus','икспятый','57000 BYN','owner')
        a=self.app()
        self.assertIn('марку',self.answer(a,'Цена X5'))
        self.assertIn('57000',self.answer(a,'Цена Changan X5'))
        for q in ['Цена X5','Цена икспятый']:
            self.assertIn('57000',self.answer(a,q))
        self.assertNotIn('57000',self.answer(a,'Цена BMW X5'))

    def test_approved_change_next_answer(self):
        pid=self.price();a=self.app()
        self.answer(a,'Цена кулька')
        self.price('От 65000 BYN',pid)
        self.assertIn('65000',self.answer(a,'Цена'))

    def test_yes_after_model_clarification(self):
        self.price();a=self.app()
        history=[{'direction':'out','text':'Вы про Geely Coolray?'}]
        self.assertIn('63000',self.answer(a,'да',history))

    def test_deleted_price_not_reused(self):
        pid=self.price(); a=self.app();self.answer(a,'Цена кулек')
        self.db._execute("UPDATE approved_prices SET status='inactive' WHERE id=%s",(pid,))
        self.assertNotIn('63000',self.answer(a,'Цена'))

    def test_monthly_defaults_are_exact_and_no_totals(self):
        a=self.app()
        result=self.answer(a,'Рассчитай платёж на 60 000 BYN')
        expected=str(int(monthly(60000).quantize(Decimal('1'))))
        self.assertIn(f'{int(expected):,}'.replace(',',' '),result)
        self.assertIn('10 лет',result)
        self.assertNotIn('переплат',result)
        self.assertNotIn('сумма выплат',result)
        self.assertEqual(a.ai.queries,[])

    def test_price_then_payment_updates_current_approval(self):
        pid=self.price(); a=self.app()
        self.answer(a,'По чем кульки')
        self.price('От 64000 BYN',pid)
        result=self.answer(a,'платёж')
        self.assertIn(f'{monthly(64000).quantize(Decimal("1")):,}'.replace(',',' '),result)

    def test_payment_missing_amount_then_amount(self):
        a=self.app()
        self.assertIn('Какую стоимость',self.answer(a,'Платёж'))
        self.assertIn('10 лет',self.answer(a,'60 тысяч BYN'))

    def test_payment_new_unknown_car_not_previous_price(self):
        self.price();a=self.app();self.answer(a,'Цена кулек')
        self.assertIn('Какую стоимость',self.answer(a,'Рассчитай платеж на BMW X9'))

    def test_unknown_chinese_price_not_from_catalog(self):
        self.db.replace_catalog([car(1,'Geely','Atlas',90000)])
        self.assertIn('Какую стоимость',self.answer(self.app(),'Платёж за Geely Atlas'))

    def test_catalog_specific_price_and_followup(self):
        self.db.replace_catalog([car(1,'Peugeot','3008',60000)])
        a=self.app();self.answer(a,'Покажи Peugeot 3008')
        self.assertIn('10 лет',self.answer(a,'Платёж'))

    def test_payment_exact_card_url_and_catalog_update(self):
        rows=[car(1,'Peugeot','3008',60000),car(2,'Peugeot','3008',90000)]
        self.db.replace_catalog(rows);a=self.app()
        result=self.answer(a,'Платёж '+rows[0]['url'])
        self.assertIn('1 050 BYN',result)
        rows[0]['price_byn']=50000;self.db.replace_catalog(rows)
        self.assertIn(f'{monthly(50000).quantize(Decimal("1")):,}'.replace(',',' '),self.answer(a,'Платёж'))

    def test_unknown_card_url_does_not_guess(self):
        self.db.replace_catalog([car(1,'Peugeot','3008',60000)])
        self.assertIn('Какую стоимость',self.answer(self.app(),'Платёж https://metropol-auto.by/vehicles/peugeot/3008/999/'))

    def test_test_and_customer_isolation(self):
        self.price();a=self.app();self.answer(a,'Цена кулек',client=1)
        self.assertIn('Какую стоимость',self.answer(a,'Платёж',client=2))
        self.assertIn('Какую стоимость',self.answer(a,'Платёж'))

    def test_explicit_term_and_deposit(self):
        a=self.app()
        result=self.answer(a,'Рассчитай платеж 60000 BYN на 5 лет взнос 10000 BYN')
        self.assertIn('60 мес.',result)
        self.assertIn(f'{monthly(50000,60).quantize(Decimal("1")):,}'.replace(',',' '),result)

    def test_percent_deposit(self):
        a=self.app()
        result=self.answer(a,'Платеж 60000 BYN взнос 20%')
        self.assertIn(f'{monthly(48000).quantize(Decimal("1")):,}'.replace(',',' '),result)

    def test_leasing_not_credit_formula(self):
        result=self.answer(self.app(),'Рассчитай платёж по лизингу 60000 BYN')
        self.assertIn('конкретной программы',result)

    def test_explicit_interest_question_not_hidden(self):
        result=self.answer(self.app(),'Какая переплата 60000 BYN на 10 лет?')
        self.assertIn('сумма процентов',result)
        self.assertIn('17,2%',result)

    def test_full_catalog_has_one_link_and_correct_button(self):
        a=self.app();self.db.replace_catalog([car(i) for i in range(6)])
        self.answer(a,'Покажи BMW X5')
        for q in ['Дай ссылку на полный каталог','Весь каталог','Ссылка на каталог','Где посмотреть все машины']:
            result=self.answer(a,q)
            self.assertEqual(result.count('https://'),1)
            self.assertIn(CATALOG_URL,result)
            menu=a._response_markup('client:1',q,result)
            self.assertEqual(menu['inline_keyboard'][0][0]['url'],CATALOG_URL)
            self.assertNotIn('Другие варианты',str(menu))

    def test_markup_and_price_guard(self):
        self.assertEqual(plain_text(r'**Geely** https://x.test/a_b'), 'Geely https://x.test/a_b')
        self.assertEqual(plain_text(r'\*\*Geely\*\*'),'Geely')
        self.assertNotIn('90000',guard_money('Цена 90000 BYN'))

    def cache(self):
        day=(datetime.now(MINSK)-timedelta(days=1)).date().isoformat()
        rates={c:{'rate':str(r),'scale':s,'date':day} for c,r,s in [('USD',3,1),('EUR',3.5,1),('RUB',3.5,100),('CNY',4.5,10)]}
        self.db.set_setting('nbrb-rates',json.dumps({'rates':rates}))
        return ExchangeRates(self.db)

    def test_currency_scales_and_stale_fallback(self):
        fx=self.cache()
        for c,amount,expected in [('USD',100,300),('EUR',100,350),('RUB',100,3.5),('CNY',100,45)]:
            value,note=fx.convert(amount,c)
            self.assertEqual(value,Decimal(str(expected)))
            self.assertIn('последнему известному',note)

    def test_foreign_loan_payment_only_byn(self):
        self.cache();a=self.app()
        result=self.answer(a,'Платёж на 20000 долларов')
        self.assertIn('BYN',result)
        self.assertNotIn('USD',result)
        self.assertIn('последнему известному',result)
        self.assertIn(f'{monthly(60000).quantize(Decimal("1")):,}'.replace(',',' '),result)

    def test_foreign_deposit(self):
        self.cache();a=self.app()
        result=self.answer(a,'Платёж 60000 BYN взнос 1000 USD')
        self.assertIn(f'{monthly(57000).quantize(Decimal("1")):,}'.replace(',',' '),result)

    def test_rate_absent_does_not_invent(self):
        result=self.answer(self.app(),'Платёж 20000 долларов')
        self.assertNotIn('в месяц',result)

    def test_failed_refresh_preserves_rates(self):
        fx=self.cache();before=fx.state()['rates']
        with patch('metropol_agent.exchange.httpx.Client',side_effect=RuntimeError('offline')):
            self.assertFalse(fx.refresh())
            self.assertFalse(fx.refresh())
        self.assertEqual(fx.state()['rates'],before)
        self.assertEqual(fx.state()['attempts'],1)

    def test_daily_refresh_once_and_scale(self):
        fx=ExchangeRates(self.db);now=datetime.now(MINSK);day=now.date().isoformat()
        response=MagicMock()
        response.json.return_value=[{'Cur_Abbreviation':c,'Cur_OfficialRate':3,'Cur_Scale':1,'Date':day+'T00:00:00'} for c in ['USD','EUR','RUB']]
        with patch('metropol_agent.exchange.httpx.Client') as client:
            client.return_value.__enter__.return_value.get.return_value=response
            self.assertTrue(fx.refresh(now))
            self.assertFalse(fx.refresh(now))
            self.assertEqual(client.return_value.__enter__.return_value.get.call_count,2)
        self.assertEqual(fx.convert(10,'USD',now)[0],30)

    def test_invalid_rate_rejects_batch(self):
        fx=self.cache();before=fx.state()['rates']
        response=MagicMock();response.json.return_value=[{'Cur_Abbreviation':'USD','Cur_OfficialRate':-1,'Cur_Scale':1,'Date':'2026-01-01'}]
        with patch('metropol_agent.exchange.httpx.Client') as client:
            client.return_value.__enter__.return_value.get.return_value=response
            self.assertFalse(fx.refresh())
        self.assertEqual(fx.state()['rates'],before)

    def test_number_parser_grouping(self):
        for text,expected in [('60 000 BYN',60000),('60 тысяч долларов',60000),('63000 белорусских рублей',63000),('1 000 000 RUB',1000000)]:
            self.assertEqual(money(text)[0][0],expected)

    def test_invalid_amount_and_term(self):
        fx=ExchangeRates(self.db)
        for q in ['Платёж 60000 BYN на 0 лет','Платёж 60000 BYN на 15 лет','Платёж 60000 BYN взнос 100%','Платёж -60000 BYN']:
            result,_=calculate(q,{},fx)
            self.assertNotIn('в месяц',result)

    def test_live_auto_payment_and_approved_price_no_ai(self):
        self.price();a=self.app();c=self.db.upsert_client('400','Клиент','','auto')
        self.db.enqueue_client_message('price',c['id'],'По чем кульки',0)
        a.process_due_jobs();a.process_outbox()
        self.assertIn('63000',' '.join(t[1] for t in a.telegram.sent))
        self.db.enqueue_client_message('payment',c['id'],'Платёж',0)
        a.process_due_jobs();a.process_outbox()
        self.assertIn('1 103 BYN',' '.join(t[1] for t in a.telegram.sent))
        self.assertEqual(a.ai.queries,[])

    def test_owner_diagnostics_is_not_in_client_answer(self):
        self.price();a=self.app();a._run_owner_test('Цена кульки','owner-test')
        a.process_outbox()
        self.assertIn('утверждённая запись #',' '.join(t[1] for t in a.telegram.sent))
        self.assertNotIn('запись #',self.answer(a,'Цена кульки',client=1))

    def test_rates_command(self):
        a=self.app();a._handle_owner({'update_id':1},{},'/rates');a.process_outbox()
        self.assertIn('Курсы НБРБ',' '.join(t[1] for t in a.telegram.sent))

    def test_new_amount_does_not_revert_to_old_car(self):
        self.price();a=self.app();self.answer(a,'Цена кульки')
        self.answer(a,'Платёж 50000 BYN')
        result=self.answer(a,'Платёж')
        self.assertIn(f'{monthly(50000).quantize(Decimal("1")):,}'.replace(',',' '),result)
