import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import test_reliability as reliability
from test_v330 import car
from metropol_agent.ai import AIEngine, SYSTEM
from metropol_agent.app import AgentApp
from metropol_agent.catalog import Catalog
from metropol_agent.catalog_selection import select
from metropol_agent.config import Settings
from metropol_agent.knowledge import KnowledgeBase
from metropol_agent.agent_tools import AgentTools


class PlainResponses:
    def __init__(self):
        self.responses = self
        self.calls = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        return SimpleNamespace(output_text="Короткий грамотный ответ.",
                               usage=SimpleNamespace(input_tokens=100, output_tokens=30))


class Quality400(unittest.TestCase):
    def test_maximum_mode_uses_sol_medium_and_expanded_context(self):
        env = {
            "AGENT_QUALITY_MODE": "maximum",
            "OPENAI_REASONING_EFFORT": "medium",
            "AGENT_HISTORY_MESSAGES": "30",
            "AGENT_HISTORY_CHARS": "16000",
            "AGENT_SECOND_PASS_REVIEW": "false",
        }
        with patch.dict(os.environ, env):
            settings = Settings.from_env()
        engine = AIEngine(settings, SimpleNamespace(search=lambda *args, **kwargs: []))
        engine.client = PlainResponses()
        history = [{"direction": "in" if i % 2 == 0 else "out", "text": str(i) + "x" * 500}
                   for i in range(25)]
        result = engine.generate("Последний вопрос", history, 0)
        call = engine.client.calls[0]
        self.assertEqual(result.model, settings.sol_model)
        self.assertEqual(call["reasoning"], {"effort": "medium"})
        self.assertGreater(len(call["input"]), 12)
        self.assertLessEqual(len(call["input"]), 30)
        self.assertLessEqual(sum(len(item["content"]) for item in call["input"]), 16000)
        self.assertEqual(call["input"][-1]["content"], "Последний вопрос")

    def test_hybrid_knowledge_finds_deep_subsection(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "kb.md"
            path.write_text(
                "## Большой раздел\n" + ("общий текст " * 500) +
                "\n\n### Гарантийные исключения\nУникальная расширенная гарантия действует при диагностике.",
                encoding="utf-8",
            )
            found = KnowledgeBase(path).search("условия уникальной гарантии", limit=3, max_chars=4000)
        self.assertTrue(found)
        self.assertIn("Гарантийные исключения", found[0])
        self.assertIn("расширенная гарантия", found[0])

    def test_catalog_returns_all_up_to_fifteen(self):
        rows = [car(i) for i in range(20)]
        self.assertEqual(len(select(rows, "Покажите BMW X5")[1]), 15)


class ClientButtons400(unittest.TestCase):
    setUp = reliability.ReliabilityTests.setUp
    tearDown = reliability.ReliabilityTests.tearDown

    def test_client_has_no_call_manager_button(self):
        app = AgentApp(reliability.settings(), self.db, reliability.FakeTelegram(),
                       reliability.FakeAI(), Catalog(self.db))
        client = self.db.upsert_client("400", "Клиент", "", "auto")
        scope = f"client:{client['id']}"
        url = "https://metropol-auto.by/vehicles/bmw/x5/1/"
        markup = app._response_markup(scope, "Покажите BMW X5", "BMW X5: " + url)
        labels = [button["text"] for row in markup["inline_keyboard"] for button in row]
        self.assertNotIn("Позвать менеджера", labels)
        self.assertIn("Хочу посмотреть", labels)

    def test_ready_customer_requires_automatic_handoff(self):
        app = AgentApp(reliability.settings(), self.db, reliability.FakeTelegram(),
                       reliability.FakeAI(), Catalog(self.db))
        tools = AgentTools(app, "test:1", "Хочу приехать посмотреть эту машину", [], lambda _: "ok")
        feedback = tools.review("Приезжайте, будем рады.")
        self.assertIn("handoff", feedback)
        self.assertIn("manager", feedback)

    def test_catalog_price_is_shown_only_when_customer_asks(self):
        row = car(1, 'Peugeot', '3008', 60000)
        self.db.replace_catalog([row], coverage='verified')
        app = AgentApp(reliability.settings(), self.db, reliability.FakeTelegram(),
                       reliability.FakeAI(), Catalog(self.db))
        common = dict(brand='Peugeot', model='3008', year_min=None, year_max=None,
                      max_price_byn=None, inherit_selection=False, more=False)
        shown = AgentTools(app, 'test:1', 'Покажи Peugeot 3008', [], lambda _: 'ok').tool_catalog(**common)
        priced = AgentTools(app, 'test:2', 'Сколько стоит Peugeot 3008?', [], lambda _: 'ok').tool_catalog(**common)
        self.assertNotIn('60 000 BYN', shown['facts'])
        self.assertIn('60 000 BYN', priced['facts'])
        self.assertIn(row['url'], priced['facts'])

    def test_missing_model_has_no_random_links_or_full_catalog(self):
        self.db.replace_catalog([car(1, 'Geely', 'Coolray')], coverage='verified')
        app = AgentApp(reliability.settings(), self.db, reliability.FakeTelegram(),
                       reliability.FakeAI(), Catalog(self.db))
        result = AgentTools(app, 'test:1', 'Покажи Changan X5', [], lambda _: 'ok').tool_catalog(
            brand='Changan', model='X5', year_min=None, year_max=None,
            max_price_byn=None, inherit_selection=False, more=False)
        self.assertEqual(result['cards'], [])
        self.assertNotIn('https://', result['facts'])
        self.assertIn('не все автомобили успевают попасть на сайт', result['facts'].lower())

    def test_policy_forbids_agent_comparison_and_recommendation(self):
        self.assertIn('Не сравнивай автомобили самостоятельно', SYSTEM)
        self.assertIn('не давай рекомендацию за клиента', SYSTEM)


if __name__ == "__main__":
    unittest.main()
