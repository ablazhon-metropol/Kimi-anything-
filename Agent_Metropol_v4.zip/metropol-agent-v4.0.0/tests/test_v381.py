import unittest
import test_reliability as r
from metropol_agent.app import AgentApp
from metropol_agent.catalog import Catalog
from metropol_agent.credit import monthly
from metropol_agent.conversation import plain_text
from metropol_agent.finance_policy import with_statistic

class Release381(unittest.TestCase):
    setUp=r.ReliabilityTests.setUp
    tearDown=r.ReliabilityTests.tearDown
    def app(self):
        self.db.save_approved_price('Changan x5 plus','чанган x5; changan x5','От 57000 белорусских рублей.','owner')
        return AgentApp(r.settings(),self.db,r.FakeTelegram(),r.FakeAI(),Catalog(self.db))
    def answer(self,app,q,history):
        answer=app._prepare_answer(q,history,1,None,'test-'+str(len(history)))
        history.extend([{'direction':'in','text':q},{'direction':'out','text':answer[0]}])
        return answer
    def test_exact_screenshot_chain(self):
        app=self.app(); h=[]
        for q in ['Чанган x5','Ну сколь стоит чанган x5','Проверь','Сколько стоит чанган x5']:
            self.assertIn('57000',self.answer(app,q,h)[0],q)
        for q in ['Посчитай на него платёж в месяц','57000','Максимальный срок','0','Первый взнос 0']:
            result=self.answer(app,q,h)
            self.assertEqual(result[1],'local-credit',q)
            self.assertIn('10 лет',result[0],q)
            self.assertIn('998',result[0].replace(' ',''),q)
        self.assertFalse(app.ai.queries)
    def test_long_variations(self):
        app=self.app()
        for q in ['Посчитай на него платёж в месяц','А сколько я буду платить в месяц?','Рассчитай мне платеж пожалуйста','Какой будет платеж на нее?']:
            h=[]
            self.answer(app,'Цена чанган x5',h)
            self.assertIn('10 лет',self.answer(app,q,h)[0],q)
    def test_new_model_not_old_price(self):
        app=self.app();h=[]
        self.answer(app,'Цена чанган x5',h)
        self.assertNotIn('998',self.answer(app,'Посчитай платеж за BMW X9',h)[0])
    def test_missing_currency_confirmation(self):
        app=self.app();h=[]
        self.answer(app,'Рассчитай платеж',h)
        self.assertIn('(BYN)?',self.answer(app,'57000',h)[0])
        self.assertIn('10 лет',self.answer(app,'да',h)[0])
    def test_zero_not_reset_explicit_term(self):
        app=self.app();h=[]
        self.answer(app,'Цена чанган x5',h)
        self.answer(app,'Рассчитай платеж на 5 лет',h)
        self.assertIn('60 мес.',self.answer(app,'Первый взнос 0',h)[0])
    def test_bare_numbers_outside_calculation_not_credit(self):
        app=self.app();self.assertNotEqual(self.answer(app,'57000',[])[1],'local-credit')
    def test_markdown_links_clean(self):
        self.assertEqual(plain_text('[Посмотреть](https://metropol-auto.by/vehicles/)'),'Посмотреть: https://metropol-auto.by/vehicles/')
    def test_no_duplicate_bank_decision(self):
        text=with_statistic('Можно. Решение подтверждает банк.','А кредит можно?',[])
        self.assertEqual(text.count('банк'),1)
    def test_brand_needed_is_catalog_not_ai_count(self):
        from test_v330 import car
        app=self.app()
        self.db.replace_catalog([car(i,'Changan','UNI-Z') for i in range(1,8)])
        result=self.answer(app,'Чанган нужен',[])
        self.assertEqual(result[1],'local-catalog')
        self.assertNotIn('не нашёл',result[0])
        self.assertNotIn('вижу три',result[0])
        self.assertEqual(result[0].count('https://'),7)
    def test_scope_isolation(self):
        app=self.app();h=[]
        self.answer(app,'Цена чанган x5',h)
        result=app._prepare_answer('Посчитай на него платёж в месяц',[],1,999,'isolated')
        self.assertNotIn('998',result[0])
    def test_price_reread_after_edit(self):
        app=self.app();h=[]
        self.answer(app,'Цена чанган x5',h)
        row=self.db.approved_prices(100)[0]
        self.db.save_approved_price(row['label'],row['matcher'],'От 60000 BYN','owner',row['id'])
        self.assertIn('1 050',self.answer(app,'Посчитай на него платёж в месяц',h)[0])
