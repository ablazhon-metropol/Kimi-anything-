import unittest
import test_reliability as reliability
from test_reliability import FakeTelegram, FakeAI, settings
import test_server_security as security
from metropol_agent.app import AgentApp
from metropol_agent.catalog import Catalog
from metropol_agent.telegram import owner_keyboard

class Prices320(unittest.TestCase):
    setUp = reliability.ReliabilityTests.setUp
    tearDown = reliability.ReliabilityTests.tearDown
    def test_short_codes_and_legacy_aliases(self):
        self.db.save_approved_price('Changan CS55 Plus', 'Чанган кс55 cs55 55 55ка чанань', 'От 69900 BYN', 'owner')
        self.db.save_approved_price('Changan X5 Plus', 'Чанган x5 плюс чанань changan', 'От 57000 BYN', 'owner')
        self.db.save_approved_price('Li L9', 'ли l9', 'L9 PRICE', 'owner')
        self.db.save_approved_price('Li L7', 'ли l7', 'L7 PRICE', 'owner')
        for query, expected in [('Сколько стоит Чанган X5?', '57000'), ('Цена чанань х5 плюс','57000'), ('Changan CS55 Plus цена','69900'), ('Чанган кс55','69900'), ('Li L9','L9 PRICE'), ('Ли Л7','L7 PRICE')]:
            with self.subTest(query=query):
                result=self.db.matching_approved_prices(query)
                self.assertEqual(len(result),1)
                self.assertIn(expected,result[0])
        for query in ['Changan', 'BMW X5', 'Li L8', 'Цена 55 рублей', 'X50', 'CS550', 'Цена Li L7 и L9']:
            with self.subTest(query=query):self.assertEqual(self.db.matching_approved_prices(query),[])

    def test_ambiguous_trim_not_guessed(self):
        self.db.save_approved_price('Li L9 Pro','li l9 pro','PRO', 'owner')
        self.db.save_approved_price('Li L9 Max','li l9 max','MAX', 'owner')
        self.assertEqual(self.db.matching_approved_prices('Цена Li L9'),[])
        self.assertIn('MAX',self.db.matching_approved_prices('Цена Li L9 Max')[0])

    def test_price_update_replaces_same_row_and_rejects_stale_edit(self):
        pid=self.db.save_approved_price('Changan X5 Plus','x5','57000', 'owner')
        stamp=self.db.approved_prices()[0]['updated_at']
        self.assertTrue(self.db.update_price_checked(pid,'Changan X5 Plus','x5','58000',stamp))
        self.assertFalse(self.db.update_price_checked(pid,'Changan X5 Plus','x5','59000',stamp))
        self.assertEqual(len(self.db.approved_prices()),1)
        self.assertIn('58000',self.db.matching_approved_prices('Цена Changan X5')[0])

    def test_direct_price_reaches_auto_outbox_without_ai(self):
        self.db.save_approved_price('Changan X5 Plus','Чанган x5 плюс чанань changan','От 57000 BYN', 'owner')
        c=self.db.upsert_client('555','Employee','','auto')
        self.db.enqueue_client_message('price-question',c['id'],'Сколько стоит Чанган X5?',0)
        ai=FakeAI();app=AgentApp(settings(),self.db,FakeTelegram(),ai,Catalog(self.db))
        self.assertEqual(app.process_due_jobs(),1)
        self.assertEqual(ai.queries,[])
        with self.db.connect() as conn:
            rows=self.db._fetchall(conn,'SELECT text FROM outbox WHERE chat_id=%s',('555',))
        self.assertIn('57000',rows[0]['text'])

    def test_menu_links_and_edit_url(self):
        st=settings();st.public_base_url='https://example.test'
        app=AgentApp(st,self.db,FakeTelegram(),FakeAI(),Catalog(self.db))
        self.assertEqual(app._panel_keyboard()['inline_keyboard'][0][0]['url'],'https://example.test/admin/prices')
        self.assertEqual(owner_keyboard(1,2,st.public_base_url)['inline_keyboard'][0][1]['url'],'https://example.test/admin/drafts/2')

class Web320(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import sys
        sys.modules.pop('metropol_agent.server', None)
        security.AdminSecurityTests.setUpClass.__func__(cls)
    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_price_page_redirect_returns_to_prices_after_login(self):
        self.client.cookies.clear()
        r=self.client.get('/admin/prices',follow_redirects=False)
        self.assertEqual(r.headers['location'],'/admin/login?next=/admin/prices')
        r=self.client.post('/admin/login',data={'token':'test-admin-secret','next':'/admin/prices'},follow_redirects=False)
        self.assertEqual(r.headers['location'],'/admin/prices')
        self.assertEqual(self.client.get('/admin/prices').status_code,200)

    def test_populated_draft_send_and_double_submit(self):
        self.client.post('/admin/login',data={'token':'test-admin-secret'})
        c=self.server.db.upsert_client('web-client','Получатель','','approval')
        did=self.server.db.create_draft(c['id'],'Исходный ответ <пример>')
        r=self.client.get(f'/admin/drafts/{did}')
        self.assertIn('Исходный ответ &lt;пример&gt;',r.text)
        self.assertIn('Получатель',r.text)
        self.assertEqual(self.client.post(f'/admin/drafts/{did}',data={'text':'Исправленный ответ'}).status_code,200)
        self.assertEqual(self.client.post(f'/admin/drafts/{did}',data={'text':'Дубликат'}).status_code,409)

    def test_editor_denies_anonymous(self):
        self.client.cookies.clear()
        self.assertEqual(self.client.post('/admin/drafts/1',data={'text':'x'}).status_code,403)
        self.assertEqual(self.client.post('/admin/prices',data={'label':'x'}).status_code,403)
