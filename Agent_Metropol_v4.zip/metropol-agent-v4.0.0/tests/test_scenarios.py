import unittest

from metropol_agent.knowledge import deterministic_answer


class ApprovedScenarioTests(unittest.TestCase):
    def test_one_hundred_safe_local_scenarios(self):
        seeds = [
            "Где вы находитесь", "Какой адрес", "Дайте номер телефона", "Как вам позвонить",
            "Какой график", "До скольки работаете", "Нужен первый взнос", "Можно без взноса",
            "Расскажите про кредит", "Есть лизинг", "Можно в рассрочку", "Можно тест драйв",
            "Разрешена диагностика", "Есть гарантия", "Хочу trade in", "Выкупаете автомобили",
            "У меня жалоба", "Передайте руководителю", "Хочу продать машину", "Как проехать",
        ]
        suffixes = ["?", " пожалуйста", " сегодня?", " в Минске", " срочно"]
        scenarios = [seed + suffix for seed in seeds for suffix in suffixes]
        self.assertEqual(len(scenarios), 100)
        for phrase in scenarios:
            with self.subTest(phrase=phrase):
                result = deterministic_answer(phrase)
                self.assertIsNotNone(result)
                self.assertTrue(result.text.strip())
                self.assertNotIn("ответили в директ", result.text.lower())
                self.assertNotIn("гарантируем одобрение", result.text.lower())


if __name__ == "__main__":
    unittest.main()
