import unittest
import json
from unittest.mock import patch
from types import SimpleNamespace
import test_reliability as reliability
from test_v330 import car
from metropol_agent.app import AgentApp
from metropol_agent.catalog import Catalog
from metropol_agent.conversation import handoff_request, simple_fact, explicit_catalog_request, bound_links
from metropol_agent.followups import Followups
from metropol_agent.ai import AIEngine, SYSTEM
from metropol_agent.config import Settings
from metropol_agent.knowledge import KnowledgeBase

class Workflows340(unittest.TestCase):
    setUp = reliability.ReliabilityTests.setUp
    tearDown = reliability.ReliabilityTests.tearDown

    def app(self):
        return AgentApp(reliability.settings(),self.db,reliability.FakeTelegram(),reliability.FakeAI(),Catalog(self.db))

    def owner(self, app, text, event):
        app._handle_owner({'update_id':event},{},text)

    def client(self, mode='auto'):
        return self.db.upsert_client('400','Клиент','',mode)

    def test_comparison_and_joke_go_to_ai_not_catalog(self):
        a=self.app();self.db.replace_catalog([car(1)])
        for i,q in enumerate(['Почему эта машина дороже другой?', 'Машина зверь, кормить мясом?','Что приготовить на ужин?','А какой лучше для семьи?']):
            a._prepare_answer(q,[{'direction':'in','text':q}],i,None,f'test-{i}')
        self.assertEqual(len(a.ai.queries),4)

    def test_address_still_free(self):
        a=self.app();a._prepare_answer('Где вы находитесь?',[],1,None,'address')
        self.assertEqual(a.ai.queries,[])

    def test_test_mode_private_counted_and_persistent(self):
        a=self.app();self.owner(a,'/test',1);self.owner(a,'Как настроение?',2)
        self.assertEqual(self.db.stats()['clients'],0)
        self.assertGreater(self.db.monthly_usage()['input_tokens'],0)
        for r in self.db.claim_outbox(20):self.assertEqual(str(r['chat_id']),str(a.settings.owner_id))
        a2=self.app();self.owner(a2,'А почему?',3)
        self.assertGreater(len(a2.ai.queries[0][1]),1)
        self.owner(a2,'/testoff',4)
        self.assertEqual(self.db.get_setting(f'owner-test-enabled-{a.settings.owner_id}'),'0')

    def test_test_handoff_and_sales_never_schedule(self):
        a=self.app();self.owner(a,'/test',1)
        self.owner(a,'Позовите Андрея',2)
        self.owner(a,'Хочу купить машину',3)
        self.assertEqual(self.db._execute('SELECT * FROM sales_followups',(),'all'),[])
        self.assertEqual(self.db.pending_notifications(),[])

    @patch('metropol_agent.app.is_night',return_value=False)
    def test_real_handoff_has_notice_and_blocks_old_auto(self,_):
        a=self.app();c=self.client()
        self.db.enqueue_outbox('400','Старый автоответ',metadata={'direction':'out','client_id':c['id'],'model':'fake-luna'})
        self.db.enqueue_client_message('handoff',c['id'],'Позовите менеджера',0)
        a.process_due_jobs()
        self.assertEqual(self.db.client_by_id(c['id'])['mode'],'human')
        for _ in range(5):a.process_outbox()
        self.assertFalse(any(x[1]=='Старый автоответ' for x in a.telegram.sent))
        self.assertTrue(any('Нужен сотрудник' in x[1] for x in a.telegram.sent))

    @patch('metropol_agent.app.is_night',return_value=True)
    def test_night_handoff_queued(self,_):
        a=self.app();c=self.client();self.db.enqueue_client_message('night',c['id'],'Свяжите с сотрудником',0)
        a.process_due_jobs()
        self.assertEqual(len(self.db.pending_notifications()),1)
        self.assertEqual(self.db.client_by_id(c['id'])['mode'],'human')

    def test_staff_permissions_and_revocation(self):
        a=self.app();c=self.client('human');a.staff.register(900,'Иван');a.staff.register(901,'Ольга')
        a.staff.assign(c['id'],900)
        self.assertTrue(a.staff.can_reply(900,c['id']))
        self.assertFalse(a.staff.can_reply(901,c['id']))
        a._handle_callback({'id':'bad','from':{'id':901},'data':f"humanreply:{c['id']}:0"})
        self.assertEqual(self.db.get_setting('owner-reply-target-901'),'')
        a._handle_callback({'id':'yes','from':{'id':900},'data':f"humanreply:{c['id']}:0"})
        a._handle_staff(900,'Здравствуйте','reply')
        a.staff.remove(900)
        for _ in range(5):a.process_outbox()
        self.assertFalse(any(x[0]=='400' and x[1]=='Здравствуйте' for x in a.telegram.sent))
        self.assertEqual(a.staff.responsible(c['id']),a.settings.owner_id)

    def test_nonowner_cannot_register_staff_or_open_test(self):
        a=self.app();a.staff.register(900,'Иван')
        for data in ['staff:primary:900','owner:test','owner:staff','staff:confirm:901']:
            a._handle_callback({'id':data,'from':{'id':900},'data':data})
        self.assertIsNone(a.staff.active(901))
        self.assertEqual(self.db.get_setting('primary_staff'),'')

    def test_staff_candidate_needs_owner_confirmation(self):
        a=self.app();self.db.upsert_client('900','Иван','','auto')
        a.telegram.call=lambda *args: {'result':{'id':900,'type':'private','first_name':'Иван','username':'ivan'}}
        a._staff_candidate(900)
        self.assertIsNone(a.staff.active(900))
        a._handle_callback({'id':'confirm','from':{'id':a.settings.owner_id},'data':'staff:confirm:900'})
        self.assertIsNotNone(a.staff.active(900))

    @patch('metropol_agent.followups.daytime',return_value=True)
    def test_followup_one_only_and_cancel_on_new_message(self,_):
        a=self.app();c=self.client()
        self.db.add_message('q',c['id'],'in','Хочу купить автомобиль')
        sid=self.db.recent_messages(c['id'])[-1]['id']
        self.db.add_message('a',c['id'],'out','Помогу выбрать','fake-luna')
        a.followups.consider(c,'Хочу купить автомобиль',sid)
        self.db._execute("UPDATE sales_followups SET due_at='2000-01-01'")
        self.assertEqual(a.followups.enqueue_due(),1)
        self.assertEqual(a.followups.enqueue_due(),0)
        self.db.add_message('new',c['id'],'in','Спасибо, не нужно')
        a.process_outbox()
        self.assertEqual(a.telegram.sent,[])

    @patch('metropol_agent.followups.daytime',return_value=False)
    def test_followup_night_disabled(self,_):
        self.assertEqual(self.app().followups.enqueue_due(),0)

    def test_no_followup_for_banter_or_goodbye(self):
        a=self.app();c=self.client()
        for q in ['Как приготовить суп?', 'Спасибо, до свидания', 'Кредит не нужен']:
            a.followups.consider(c,q,1)
        self.assertEqual(self.db._execute("SELECT * FROM sales_followups WHERE status='pending'",(),'all'),[])

class Routing340(unittest.TestCase):
    def test_handoff_positive_negative(self):
        for q in ['Хочу поговорить с менеджером','Позовите Андрея','Свяжите с сотрудником','Перезвоните мне']:
            self.assertTrue(handoff_request(q),q)
        for q in ['Не надо звать менеджера','Ваш менеджер хороший','Не хочу говорить с менеджером']:
            self.assertFalse(handoff_request(q),q)

    def test_no_blanket_keyword_routes(self):
        self.assertFalse(simple_fact('Ваш адрес далеко, почему мне стоит ехать?'))
        self.assertFalse(explicit_catalog_request('Какая машина лучше?'))

    def test_max_fifteen_whitelisted_links(self):
        urls={f'https://metropol-auto.by/vehicles/bmw/x5/{i}/' for i in range(20)}
        text=bound_links(' '.join(sorted(urls))+' https://evil.example',urls)
        self.assertEqual(text.count('https://'),15)
        self.assertNotIn('evil',text)

    def test_ai_prompt_and_maximum_quality_model(self):
        with patch.dict('os.environ', {'AGENT_QUALITY_MODE':'maximum'}):
            s=Settings.from_env()
        engine=AIEngine(s,KnowledgeBase('knowledge/metropol.md'))
        calls=[]
        def create(**kwargs):
            calls.append(kwargs)
            return SimpleNamespace(output_text='Главное — не кормить после полуночи!',usage=SimpleNamespace(input_tokens=10,output_tokens=10))
        engine.client=SimpleNamespace(responses=SimpleNamespace(create=create))
        result=engine.generate('Машина зверь!', [{'direction':'in','text':'Машина зверь!'}],0)
        self.assertEqual(len(calls),1)
        self.assertEqual(calls[0]['model'],s.sol_model)
        self.assertIn('вне автомобильной темы',calls[0]['instructions'])
        self.assertIn('на шутку',calls[0]['instructions'])
        self.assertTrue(result.text)

    def test_budget_prevents_call(self):
        s=Settings.from_env();engine=AIEngine(s,KnowledgeBase('knowledge/metropol.md'))
        engine.client=object()
        self.assertEqual(engine.generate('Привет',[],s.monthly_budget_usd).model,'local-budget-limit')
