import unittest

import test_reliability as reliability
import test_v401 as v401
from test_v330 import car
from metropol_agent.catalog_selection import direct_catalog_args, fuzzy_words


class Release404(unittest.TestCase):
    setUp = reliability.ReliabilityTests.setUp
    tearDown = reliability.ReliabilityTests.tearDown

    def app(self, responses=()):
        return v401.Adaptive401.app(self, responses)

    def answer(self, app, query, event):
        return app._prepare_answer(query, [], 1, None, event)

    def test_screenshot_volvo_v50_and_v60_are_local_catalog(self):
        self.db.replace_catalog([
            car(1, 'Volvo', 'V50'), car(2, 'Volvo', 'V60'), car(3, 'Volvo', 'XC60'),
        ], coverage='verified')
        app = self.app()
        first = self.answer(app, 'Вольво в50', 'volvo-v50')
        second = self.answer(app, 'А в60?', 'volvo-v60')
        self.assertEqual(first[1], 'local-catalog')
        self.assertEqual(second[1], 'local-catalog')
        self.assertIn('Volvo V50', first[0])
        self.assertIn('Volvo V60', second[0])
        self.assertEqual(app.ai.client.calls, [])

    def test_model_code_separators_are_generated_from_catalog(self):
        rows = [car(1, 'Volvo', 'V50'), car(2, 'Mazda', 'CX-5')]
        for query, expected in (
            ('Volvo V 50', 'V50'), ('Вольво в-50', 'V50'), ('Мазда сх 5', 'CX-5'),
        ):
            args = direct_catalog_args(rows, query, {})
            self.assertIsNotNone(args, query)
            self.assertEqual(args['model'], expected, query)

    def test_catalog_driven_cyrillic_names_across_makes(self):
        rows = [
            car(1, 'Nissan', 'Qashqai'), car(2, 'Toyota', 'Camry'),
            car(3, 'Hyundai', 'Tucson'), car(4, 'Honda', 'CR-V'),
            car(5, 'Jeep', 'Compass'), car(6, 'Exeed', 'LX'),
            car(7, 'Volkswagen', 'Tiguan'),
        ]
        cases = {
            'Ниссан кашкай': ('Nissan', 'Qashqai'),
            'Тойота камри': ('Toyota', 'Camry'),
            'Хендай туксон': ('Hyundai', 'Tucson'),
            'Хонда срв': ('Honda', 'CR-V'),
            'Джип компас': ('Jeep', 'Compass'),
            'Эксид лх': ('Exeed', 'LX'),
            'Фольксваген тигуан': ('Volkswagen', 'Tiguan'),
        }
        for query, expected in cases.items():
            args = direct_catalog_args(rows, query, {})
            self.assertIsNotNone(args, query)
            self.assertEqual((args['brand'], args['model']), expected, query)

    def test_small_typo_is_resolved_only_to_unique_catalog_model(self):
        rows = [car(1, 'Geely', 'Coolray'), car(2, 'Geely', 'Monjaro')]
        self.assertIn('coolray', fuzzy_words(rows, 'Geely Colray'))
        args = direct_catalog_args(rows, 'Geely Colray', {})
        self.assertEqual(args['model'], 'Coolray')

    def test_missing_model_stays_missing_instead_of_showing_whole_brand(self):
        self.db.replace_catalog([car(1, 'Volvo', 'V50'), car(2, 'Volvo', 'V60')], coverage='verified')
        app = self.app()
        answer = self.answer(app, 'Volvo V70', 'volvo-missing')
        self.assertEqual(answer[1], 'local-catalog')
        self.assertIn('найдено автомобилей: 0', answer[0].lower())
        self.assertNotIn('https://', answer[0])

    def test_similar_keeps_brand_and_clears_model(self):
        rows = [car(1, 'Volvo', 'V50'), car(2, 'Volvo', 'V60')]
        previous = {'agent_filters': {'brand': 'Volvo', 'model': 'V50'}}
        args = direct_catalog_args(rows, 'Давай похожий', previous)
        self.assertEqual(args['brand'], 'Volvo')
        self.assertIsNone(args['model'])

    def test_same_model_code_across_brands_is_not_guessed(self):
        rows = [car(1, 'BMW', 'X5'), car(2, 'Changan', 'X5')]
        self.assertIsNone(direct_catalog_args(rows, 'X5?', {}))
        args = direct_catalog_args(rows, 'А X5?', {'agent_filters': {'brand': 'Changan', 'model': 'CS55 Plus'}})
        self.assertEqual((args['brand'], args['model']), ('Changan', 'X5'))


if __name__ == '__main__':
    unittest.main()
