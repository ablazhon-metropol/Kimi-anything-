import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import test_reliability as reliability
from test_v330 import car
from metropol_agent.catalog_selection import select
from metropol_agent.knowledge import KnowledgeBase, company_context
from metropol_agent.semantic_knowledge import SemanticKnowledge
from metropol_agent.web_research import cited_answer


class Embeddings:
    def __init__(self, fail=False): self.fail, self.calls = fail, []
    def create(self, model, input):
        if self.fail: raise RuntimeError('offline')
        self.calls.append(input)
        value = [1.0, 0.0] if 'резерв' in input.lower() else [0.0, 1.0]
        return SimpleNamespace(data=[SimpleNamespace(embedding=value)], usage=SimpleNamespace(total_tokens=4))


class Client:
    def __init__(self, fail=False): self.embeddings = Embeddings(fail)


class Release402(unittest.TestCase):
    setUp = reliability.ReliabilityTests.setUp
    tearDown = reliability.ReliabilityTests.tearDown

    def cfg(self):
        cfg = reliability.settings()
        cfg.embedding_enabled=True; cfg.embedding_model='text-embedding-3-small'; cfg.embedding_rate=.02
        cfg.monthly_budget_usd=100
        return cfg

    def test_cs55_aliases_find_only_cs55_plus(self):
        rows=[car(1,'Changan','CS55 Plus'), car(2,'Changan','X5')]
        for query in ('55ка', 'ЦС55', 'cs55plus', 'Чанган 55'):
            result=select(rows,query)
            self.assertEqual([r['model_name'] for r in result[1]], ['CS55 Plus'], query)
        self.assertTrue(company_context('55ка есть?'))

    def test_typo_search_and_numeric_models_do_not_mix(self):
        rows=[car(1,'Peugeot','3008'),car(2,'Peugeot','5008')]
        self.assertEqual(select(rows,'пежо 30008')[1][0]['model_name'],'3008')
        self.assertEqual([r['model_name'] for r in select(rows,'5008')[1]],['5008'])

    def test_semantic_backfill_search_and_cost(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'kb.md'; path.write_text('## Бронь\nРезерв бесплатный на 3–5 дней.\n\n## Адрес\nГорецкого 6А.',encoding='utf-8')
            service=SemanticKnowledge(self.cfg(),self.db,KnowledgeBase(path),Client())
            self.assertGreater(service.backfill(),0)
            result=service.search('резерв',3,5000)
            self.assertIn('3–5 дней','\n'.join(result))
            self.assertGreaterEqual(len(self.db.knowledge_vectors()),2)
            self.assertGreater(float(self.db.monthly_usage()['cost_usd']),0)

    def test_semantic_failure_falls_back_to_keywords(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'kb.md'; path.write_text('## Гарантия\nПлатная гарантия до года.',encoding='utf-8')
            service=SemanticKnowledge(self.cfg(),self.db,KnowledgeBase(path),Client(True))
            self.assertIn('гарантия',' '.join(service.search('гарантия',3,5000)).lower())
            self.assertEqual(service.state,'fallback')

    def test_web_annotations_with_unusable_offsets_keep_source(self):
        response=SimpleNamespace(output=[{'type':'web_search_call','status':'completed'},
            {'type':'message','content':[{'type':'output_text','text':'Факт ✅','annotations':[
                {'type':'url_citation','url_citation':{'url':'https://example.org/source','title':'Источник','start_index':99,'end_index':120}}]}]}])
        text,urls=cited_answer(response)
        self.assertIn('https://example.org/source',text)
        self.assertEqual(urls,{'https://example.org/source'})

    def test_funnel_events_are_idempotent(self):
        self.db.record_funnel('one',1,'interest'); self.db.record_funnel('one',1,'interest')
        row=self.db._execute('SELECT COUNT(*) AS n FROM funnel_events',fetch='one')
        self.assertEqual(row['n'],1)


if __name__ == '__main__': unittest.main()
