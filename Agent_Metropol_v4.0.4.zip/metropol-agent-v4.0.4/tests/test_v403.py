import unittest
from types import SimpleNamespace

import test_reliability as reliability
import test_v390 as v390
import test_v392 as v392
import test_v401 as v401
from test_v330 import car
from metropol_agent.agent_tools import AgentTools
from metropol_agent.web_research import cited_answer


class Release403(unittest.TestCase):
    setUp = reliability.ReliabilityTests.setUp
    tearDown = reliability.ReliabilityTests.tearDown

    def app(self, responses=()):
        return v401.Adaptive401.app(self, responses)

    def answer(self, app, query, event):
        return app._prepare_answer(query, [], 1, None, event)

    def test_bare_brand_typos_are_direct_catalog_not_leasing(self):
        self.db.replace_catalog([car(1, 'Volvo', 'XC60')], coverage='verified')
        app = self.app()
        answer = self.answer(app, 'Вольва?', 'volvo')
        self.assertEqual(answer[1], 'local-catalog')
        self.assertIn('Volvo XC60', answer[0])
        self.assertNotIn('лизинг', answer[0].lower())
        self.assertEqual(app.ai.client.calls, [])

    def test_all_resolves_against_previous_brand(self):
        self.db.replace_catalog([car(1, 'Volvo', 'XC60'), car(2, 'Volvo', 'XC90')], coverage='verified')
        app = self.app()
        self.answer(app, 'Вольва?', 'volvo-first')
        answer = self.answer(app, 'Все', 'volvo-all')
        self.assertEqual(answer[1], 'local-catalog')
        self.assertIn('Найдено автомобилей: 2.', answer[0])
        self.assertEqual(app.ai.client.calls, [])

    def test_uni_z_and_show_them_keep_catalog_context(self):
        self.db.replace_catalog([car(i, 'Changan', 'UNI-Z') for i in range(1, 4)], coverage='verified')
        app = self.app()
        first = self.answer(app, 'Юни 3', 'uni-z')
        second = self.answer(app, 'Покажи их', 'show-them')
        self.assertEqual(first[1], 'local-catalog')
        self.assertEqual(second[1], 'local-catalog')
        self.assertIn('Changan UNI-Z', second[0])
        self.assertEqual(second[0].count('https://'), 3)
        self.assertEqual(app.ai.client.calls, [])

    def test_yunik_means_uni_k(self):
        self.db.replace_catalog([car(1, 'Changan', 'UNI-K'), car(2, 'Changan', 'UNI-Z')], coverage='verified')
        app = self.app()
        answer = self.answer(app, 'А юник?', 'uni-k')
        self.assertEqual(answer[1], 'local-catalog')
        self.assertIn('Changan UNI-K', answer[0])
        self.assertNotIn('Changan UNI-Z', answer[0])

    def test_next_page_uses_saved_catalog_and_never_web(self):
        rows = [car(i, 'Changan', 'CS55 Plus') for i in range(1, 19)]
        for row in rows:
            row['url'] = row['url'].replace('cs55 plus', 'cs55-plus')
        self.db.replace_catalog(rows, coverage='verified')
        app = self.app()
        first = self.answer(app, '55ка есть?', 'cs55-first')
        second = self.answer(app, 'Покажите другие варианты', 'cs55-next')
        self.assertEqual(first[0].count('https://'), 15)
        self.assertEqual(second[0].count('https://'), 3)
        self.assertEqual(second[1], 'local-catalog')
        self.assertEqual(app.ai.client.calls, [])

    def test_honda_zero_is_exact_catalog_count_not_search_failure(self):
        self.db.replace_catalog([car(1, 'Peugeot', '3008')], coverage='verified')
        app = self.app()
        answer = self.answer(app, 'Хонды?', 'honda')
        self.assertEqual(answer[1], 'local-catalog')
        self.assertIn('найдено автомобилей: 0', answer[0].lower())
        self.assertNotIn('интернет', answer[0].lower())

    def test_square_fact_marker_never_leaks(self):
        app = self.app()
        tools = AgentTools(app, 'test:1', '55ка есть?', [], lambda _: 'ok')
        fact = tools.fact('Проверенный ответ')
        self.assertEqual(tools.render('[[FACT_1]]'), 'Проверенный ответ')
        self.assertNotIn('FACT', tools.render('[[FACT_99]]'))

    def test_consulted_sources_are_valid_fallback_for_missing_annotations(self):
        response = SimpleNamespace(output=[
            {'type': 'web_search_call', 'status': 'completed', 'action': {
                'type': 'search', 'sources': [{'type': 'url', 'url': 'https://example.org/news'}]}},
            {'type': 'message', 'content': [{'type': 'output_text', 'text': 'Проверенная новость.', 'annotations': []}]},
        ])
        text, urls = cited_answer(response)
        self.assertIn('https://example.org/news', text)
        self.assertEqual(urls, {'https://example.org/news'})

    def test_web_search_retries_once_then_succeeds(self):
        app = self.app([
            v390.response(tool='internet_search', args={'query': 'Новости мира сегодня'}),
            RuntimeError('temporary'),
            v392.web_response(),
            v390.response('[[TOPIC:offtopic]][[FACT_1]]'),
        ])
        answer = self.answer(app, 'Какие новости в мире?', 'retry')
        self.assertIn('https://example.org/weather', answer[0])
        native = [call for call in app.ai.client.calls
                  if call.get('tools') and call['tools'][0].get('type') == 'web_search']
        self.assertEqual(len(native), 2)
        self.assertEqual(self.db.get_setting('web_search_consecutive_failures'), '0')


if __name__ == '__main__':
    unittest.main()
