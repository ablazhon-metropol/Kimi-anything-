import os
import unittest
from types import SimpleNamespace
from unittest.mock import patch

import test_reliability as reliability
import test_v390 as v390
import test_v392 as v392
from test_v330 import car
from metropol_agent.ai import AIEngine
from metropol_agent.app import AgentApp
from metropol_agent.catalog import Catalog
from metropol_agent.config import Settings
from metropol_agent.knowledge import KnowledgeBase, company_context, contextual_followup
from metropol_agent.agent_tools import AgentTools


class Adaptive401(unittest.TestCase):
    setUp = reliability.ReliabilityTests.setUp
    tearDown = reliability.ReliabilityTests.tearDown

    def app(self, responses=(), quality='adaptive'):
        cfg = reliability.settings()
        cfg.openai_api_key = ''
        cfg.sol_enabled = True
        cfg.quality_mode = quality
        cfg.reasoning_effort = 'medium'
        cfg.monthly_budget_usd = 100
        cfg.luna_model, cfg.sol_model = 'gpt-5.6-luna', 'gpt-5.6-sol'
        cfg.web_model = 'gpt-5.6-luna'
        cfg.fallback_models = ('gpt-5.6-terra', 'gpt-5.6-luna')
        cfg.luna_input_rate, cfg.luna_output_rate = .2, 1.2
        cfg.sol_input_rate, cfg.sol_output_rate = 4., 20.
        cfg.history_messages, cfg.history_chars = 30, 16000
        cfg.knowledge_chunks, cfg.knowledge_chars = 6, 10000
        cfg.max_output_tokens = 1800
        cfg.agent_max_rounds, cfg.agent_max_tool_calls = 8, 12
        cfg.web_search_context_size = 'low'
        cfg.web_search_reasoning_effort = 'none'
        cfg.web_search_max_output_tokens = 650
        cfg.web_search_cache_seconds = 900
        cfg.second_pass_review = False
        ai = AIEngine(cfg, KnowledgeBase('knowledge/metropol.md'))
        ai.client = v390.Responses(responses)
        return AgentApp(cfg, self.db, reliability.FakeTelegram(), ai, Catalog(self.db))

    def answer(self, app, query, history=(), event='v401'):
        return app._prepare_answer(query, list(history), 1, None, event)

    def test_settings_default_to_adaptive_and_economical_search(self):
        with patch.dict(os.environ, {}, clear=True):
            settings = Settings.from_env()
        self.assertEqual(settings.quality_mode, 'adaptive')
        self.assertEqual(settings.web_model, settings.luna_model)
        self.assertEqual(settings.web_search_context_size, 'low')
        self.assertEqual(settings.web_search_reasoning_effort, 'none')
        self.assertEqual(settings.web_search_max_output_tokens, 650)
        self.assertFalse(settings.second_pass_review)

    def test_router_keeps_simple_sales_cheap_and_uses_sol_for_judgment(self):
        app = self.app()
        self.assertEqual(app.ai._tier('Покажи Peugeot 3008'), 'luna')
        self.assertEqual(app.ai._tier('Какие сегодня новости в мире?'), 'luna')
        self.assertEqual(app.ai._tier('Почему у вас автомобиль так дорого стоит, сделайте скидку'), 'sol')
        self.assertEqual(app.ai._tier('У меня жалоба и претензия к договору'), 'sol')
        self.assertEqual(self.app(quality='maximum').ai._tier('Привет'), 'sol')

    def test_general_news_uses_only_luna_small_prompt_and_small_toolset(self):
        app = self.app([
            v390.response(tool='internet_search', args={'query':'Новости мира сегодня'}),
            v392.web_response(),
            v390.response('[[TOPIC:offtopic]]{{FACT_1}}'),
        ])
        result = self.answer(app, 'Какие сегодня новости в мире?')
        calls = app.ai.client.calls
        self.assertEqual([call['model'] for call in calls], ['gpt-5.6-luna'] * 3)
        self.assertEqual([tool['name'] for tool in calls[0]['tools']], ['internet_search'])
        self.assertNotIn('Утверждённые справочные данные', calls[0]['instructions'])
        self.assertEqual(calls[1]['tools'][0]['type'], 'web_search')
        self.assertEqual(calls[1]['tools'][0]['search_context_size'], 'low')
        self.assertEqual(calls[1]['reasoning'], {'effort':'none'})
        self.assertEqual(calls[1]['max_output_tokens'], 650)
        self.assertLess(result[2]['cost_usd'], .012)

    def test_sol_sales_turn_still_uses_luna_for_web_research(self):
        app = self.app([
            v390.response(tool='internet_search', args={'query':'Общие правила ценообразования автомобилей'}),
            v392.web_response(),
            v390.response('[[TOPIC:business]]{{FACT_1}}'),
        ])
        self.answer(app, 'Почему автомобиль так дорого стоит? Найди в интернете общие правила ценообразования автомобилей.')
        self.assertEqual([call['model'] for call in app.ai.client.calls],
                         ['gpt-5.6-sol', 'gpt-5.6-luna', 'gpt-5.6-sol'])

    def test_identical_search_is_cached_for_fifteen_minutes(self):
        app = self.app([
            v390.response(tool='internet_search', args={'query':'Новости мира сегодня'}),
            v392.web_response(),
            v390.response('[[TOPIC:offtopic]]{{FACT_1}}'),
            v390.response(tool='internet_search', args={'query':'Новости мира сегодня'}),
            v390.response('[[TOPIC:offtopic]]{{FACT_1}}'),
        ])
        self.answer(app, 'Какие сегодня новости в мире?', event='first')
        self.answer(app, 'Какие сегодня новости в мире?', event='second')
        native = [call for call in app.ai.client.calls
                  if call.get('tools') and call['tools'][0].get('type') == 'web_search']
        self.assertEqual(len(native), 1)

    def test_failed_search_returns_only_honest_short_notice(self):
        app = self.app([
            v390.response(tool='internet_search', args={'query':'Новости мира сегодня'}),
            RuntimeError('transport detail must stay private'),
            RuntimeError('temporary retry failure'),
            v390.response('[[TOPIC:offtopic]]Могу ещё написать вам Telegram-бота на Python.'),
        ])
        result = self.answer(app, 'Какие новости в мире?')[0]
        self.assertIn('не удалось проверить сведения', result)
        self.assertNotIn('Telegram', result)
        self.assertNotIn('private', result)

    def test_explicit_general_topic_does_not_inherit_old_car_domain(self):
        history = [{'direction':'in', 'text':'Покажи Peugeot 3008'}]
        app = self.app([v390.response('[[TOPIC:offtopic]]Сейчас проверю по запросу.')])
        self.answer(app, 'Какие сегодня новости в мире?', history)
        call = app.ai.client.calls[0]
        self.assertEqual(call['model'], 'gpt-5.6-luna')
        self.assertEqual([tool['name'] for tool in call['tools']], ['internet_search'])

    def test_short_followup_keeps_car_domain(self):
        self.assertTrue(company_context('Peugeot 3008'))
        self.assertTrue(contextual_followup('А сколько стоит?'))
        history = [{'direction':'in', 'text':'Покажи Peugeot 3008'}]
        app = self.app([v390.response('[[TOPIC:business]]Уточню цену по карточке.')])
        self.answer(app, 'А сколько стоит?', history)
        self.assertGreater(len(app.ai.client.calls[0]['tools']), 1)

    def test_catalog_reports_total_and_caps_links_at_fifteen(self):
        self.db.replace_catalog([car(i, 'Peugeot', '3008') for i in range(20)], coverage='verified')
        app = self.app()
        tools = AgentTools(app, 'test:1', 'Покажи все Peugeot 3008', [], lambda _: 'ok')
        result = tools.tool_catalog(brand='Peugeot', model='3008', year_min=None, year_max=None,
                                    max_price_byn=None, inherit_selection=False, more=False)
        self.assertEqual(result['total_count'], 20)
        self.assertIn('Найдено автомобилей: 20.', result['facts'])
        self.assertEqual(result['facts'].count('https://'), 15)


if __name__ == '__main__':
    unittest.main()
