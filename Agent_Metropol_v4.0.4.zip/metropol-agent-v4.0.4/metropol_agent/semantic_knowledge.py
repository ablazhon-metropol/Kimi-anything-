from __future__ import annotations

import hashlib
import json
import math
import time


def _hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _cosine(left: list[float], right: list[float]) -> float:
    if not left or len(left) != len(right):
        return 0.0
    denom = math.sqrt(sum(x * x for x in left)) * math.sqrt(sum(x * x for x in right))
    return sum(x * y for x, y in zip(left, right)) / denom if denom else 0.0


class SemanticKnowledge:
    """Hybrid knowledge retrieval. Any API/database problem falls back to keyword search."""

    def __init__(self, settings, db, knowledge, client):
        self.settings, self.db, self.knowledge, self.client = settings, db, knowledge, client
        self.cache: dict[str, tuple[float, list[float]]] = {}
        self.state = "pending" if self.enabled else "disabled"
        self.last_error = ""

    @property
    def enabled(self):
        return bool(getattr(self.settings, "embedding_enabled", True) and self.client)

    def _embed(self, text: str, event: str) -> list[float] | None:
        if not self.enabled:
            return None
        key = _hash(text)
        cached = self.cache.get(key)
        if cached and time.monotonic() - cached[0] < 900:
            return cached[1]
        if float(self.db.monthly_usage()["cost_usd"]) >= float(self.settings.monthly_budget_usd):
            self.state = "budget_limit"
            return None
        try:
            response = self.client.embeddings.create(model=self.settings.embedding_model, input=text[:8000])
            vector = list(response.data[0].embedding)
            usage = getattr(response, "usage", None)
            tokens = int(getattr(usage, "total_tokens", 0) or getattr(usage, "prompt_tokens", 0) or 0)
            self.db.record_usage(event, None, "embedding:" + self.settings.embedding_model,
                {"input_tokens": tokens, "output_tokens": 0, "cost_usd": tokens * float(self.settings.embedding_rate) / 1_000_000})
            self.cache[key] = (time.monotonic(), vector)
            self.state, self.last_error = "ok", ""
            return vector
        except Exception as exc:
            self.state, self.last_error = "fallback", f"{type(exc).__name__}: {exc}"[:300]
            return None

    def _sources(self):
        self.knowledge.reload_if_changed()
        file_rows = [("file", _hash(title + "\n" + body), title, body) for title, body in self.knowledge.sections]
        admin_rows = [("admin", str(row["id"]), row["title"], row["body"]) for row in self.db.knowledge_entries(1000)]
        return file_rows + admin_rows

    def backfill(self) -> int:
        if not self.enabled:
            return 0
        indexed = {(r["ref_type"], r["ref_key"]): r for r in self.db.knowledge_vectors()}
        sources = self._sources()
        valid = {"file": set(), "admin": set()}
        added = 0
        for kind, key, title, body in sources:
            valid[kind].add(key)
            text = title + "\n" + body
            digest = _hash(text)
            if indexed.get((kind, key), {}).get("text_hash") == digest:
                continue
            vector = self._embed(text, f"embedding-index-{kind}-{key}-{digest[:12]}")
            if vector is None:
                break
            self.db.upsert_knowledge_vector(kind, key, digest, vector)
            added += 1
            time.sleep(0.05)
        self.db.prune_knowledge_vectors("file", valid["file"])
        self.db.prune_knowledge_vectors("admin", valid["admin"])
        if self.enabled and self.state != "fallback":
            self.state = "ok"
        return added

    def search(self, query: str, limit: int, max_chars: int) -> list[str]:
        fallback = self.knowledge.search(query, limit=limit, max_chars=max_chars)
        admin_fallback = self.db.search_knowledge(query, limit=limit)
        if not self.enabled:
            return (fallback + admin_fallback)[:limit]
        vector = self._embed(query, "embedding-query-" + _hash(query)[:24] + "-" + str(int(time.time() // 900)))
        if vector is None:
            return (fallback + admin_fallback)[:limit]
        sources = {(kind, key): (title, body) for kind, key, title, body in self._sources()}
        keyword = fallback + admin_fallback
        ranked = []
        for row in self.db.knowledge_vectors():
            source = sources.get((row["ref_type"], row["ref_key"]))
            if not source:
                continue
            score = _cosine(vector, json.loads(row["vector"]))
            if score >= 0.20:
                piece = f"## {source[0]}\n{source[1]}"
                ranked.append((score, piece))
        ranked.sort(reverse=True)
        merged = [piece for _, piece in ranked] + keyword
        result, seen, total = [], set(), 0
        for piece in merged:
            digest = _hash(piece)
            if digest in seen:
                continue
            seen.add(digest)
            clipped = piece[:max(0, max_chars - total)]
            if not clipped:
                break
            result.append(clipped); total += len(clipped)
            if len(result) >= limit:
                break
        return result

    def status(self):
        return {"enabled": self.enabled, "state": self.state, "model": getattr(self.settings, "embedding_model", ""),
                "vectors": len(self.db.knowledge_vectors()), "last_error": self.last_error}
