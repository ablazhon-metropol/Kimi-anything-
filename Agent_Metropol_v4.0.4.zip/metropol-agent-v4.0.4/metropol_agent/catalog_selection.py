"""Deterministic, bounded links from stored official catalogue cards only."""
import re
from difflib import SequenceMatcher
from urllib.parse import urlparse
from .prices import tokens

BRANDS = {'бмв':'bmw', 'мерседес':'mercedes benz', 'мерседес бенц':'mercedes benz',
          'ауди':'audi', 'тойота':'toyota', 'фольксваген':'volkswagen',
          'киа':'kia', 'хендай':'hyundai', 'хёндэ':'hyundai', 'рено':'renault',
          'пежо':'peugeot', 'шкода':'skoda', 'ниссан':'nissan', 'хавал':'haval'}
BRANDS.update({'чанган':'changan','чанганы':'changan','чанганов':'changan','чангана':'changan',
               'чанань':'changan','джили':'geely','джилей':'geely','шкоды':'skoda','тойоты':'toyota'})
BRANDS.update({'шевроле': 'chevrolet', 'шевролет': 'chevrolet'})
BRANDS.update({
    'хонда': 'honda', 'хонды': 'honda', 'хонду': 'honda', 'хондой': 'honda',
    'вольво': 'volvo', 'вольва': 'volvo', 'вольвы': 'volvo',
    'форд': 'ford', 'форды': 'ford', 'мазда': 'mazda', 'мазды': 'mazda',
    'ситроен': 'citroen', 'ситроены': 'citroen', 'опель': 'opel', 'опели': 'opel',
    'субару': 'subaru', 'лексус': 'lexus', 'лексусы': 'lexus',
    'митсубиси': 'mitsubishi', 'мицубиси': 'mitsubishi',
})
MODEL_ALIASES = {'эквинокс':'equinox', 'эквиноксы':'equinox', 'эквиноксов':'equinox',
                 'эквинокса':'equinox', 'эквиноксе':'equinox', 'эквиноксом':'equinox',
                 '55ка':'cs55 plus', '55-ка':'cs55 plus', 'цс55':'cs55 plus',
                 'сс55':'cs55 plus', 'кс55':'cs55 plus', 'cs55plus':'cs55 plus',
                 'чанган 55':'changan cs55 plus',
                 'юник':'uni k', 'юни к':'uni k', 'уни к':'uni k', 'uniк':'uni k',
                 'юни з':'uni z', 'уни з':'uni z', 'юни 3':'uni z', 'уни 3':'uni z',
                 'uni з':'uni z', 'uni 3':'uni z', 'uniz':'uni z', 'uniк':'uni k'}

CANONICAL_BRANDS = {
    'bmw': 'BMW', 'mercedes': 'Mercedes-Benz', 'benz': 'Mercedes-Benz',
    'audi': 'Audi', 'toyota': 'Toyota', 'volkswagen': 'Volkswagen', 'kia': 'Kia',
    'hyundai': 'Hyundai', 'renault': 'Renault', 'peugeot': 'Peugeot',
    'skoda': 'Skoda', 'nissan': 'Nissan', 'haval': 'Haval', 'changan': 'Changan',
    'geely': 'Geely', 'chevrolet': 'Chevrolet', 'honda': 'Honda', 'volvo': 'Volvo',
    'ford': 'Ford', 'mazda': 'Mazda', 'citroen': 'Citroen', 'opel': 'Opel',
    'subaru': 'Subaru', 'lexus': 'Lexus', 'mitsubishi': 'Mitsubishi',
    'li': 'Li', 'byd': 'BYD', 'chery': 'Chery', 'exeed': 'Exeed',
    'zeekr': 'Zeekr', 'voyah': 'Voyah', 'belgee': 'Belgee',
}

REQUEST_WORDS=set('покажи покажите покажитека подбери подберите пришли пришлите скинь скиньте дай дайте ссылку ссылки на пожалуйста мне нам все весь ваши у вас в наличии есть сколько количество машин машины машину автомобилей автомобили авто моделей модели марок всего сейчас каталог каталоге из какие какие-то а и хочу посмотреть другие варианты следующие еще по марке марки бренд бренда только'.split())
REQUEST_WORDS.update({'нужен','нужна','нужны','интересует','интересуют'})

def mentioned_brands(rows, query):
    q=words(query)
    known=set(CANONICAL_BRANDS)
    catalogue_brands = set()
    for r in rows:
        row_brand = words(r['brand'])
        known |= row_brand
        catalogue_brands |= row_brand
    exact = q & known
    if exact:
        return exact
    # Catalogue-driven fallback for Russian inflections and phonetic spelling.
    # Accept only one clearly best brand; ambiguity is left for clarification.
    candidates = []
    raw_words = re.findall(r'[a-zа-я]{4,}', query.lower().replace('ё', 'е'))
    for raw in raw_words:
        if words(raw) & REQUEST_WORDS:
            continue
        variants = _phonetic_variants(raw, limit=24)
        for brand in catalogue_brands:
            score = max(_phonetic_score(variant, brand) for variant in variants)
            if score >= .70:
                candidates.append((score, brand))
    candidates.sort(reverse=True)
    if candidates and (len(candidates) == 1 or candidates[0][0] - candidates[1][0] >= .07):
        return {candidates[0][1]}
    return set()

def brand_only(rows, query):
    brands=mentioned_brands(rows,query)
    residual=words(query)-brands-REQUEST_WORDS
    residual={w for w in residual if not re.fullmatch(r'(19|20)\d{2}',w)}
    return bool(brands) and not residual

def words(text):
    text = text.lower()
    for alias, canonical in MODEL_ALIASES.items():
        text = re.sub(r'(?<!\w)' + re.escape(alias) + r'(?!\w)', canonical, text)
    for alias in sorted(BRANDS, key=len, reverse=True):
        text = re.sub(r'(?<!\w)' + re.escape(alias) + r'(?!\w)', BRANDS[alias], text)
    # Join only known model letters: never turn «а 3008» into a3008.
    text = re.sub(r'\b(cs|x|q|l|х|л|кс)[ -]+(\d+)\b', r'\1\2', text)
    text = re.sub(r'\b(первого|первое|1)\s+поколени[ея]\b', ' i ', text)
    text = re.sub(r'\b(второго|второе|2)\s+поколени[ея]\b', ' ii ', text)
    text = re.sub(r'\b(третьего|третье|3)\s+поколени[ея]\b', ' iii ', text)
    return set().union(*(tokens(w) for w in re.findall(r'[a-zа-я0-9]+', text.replace('ё','е'))))


_PHONETIC_PREFIXES = {
    'икс': 'x', 'ку': 'q', 'кей': 'k', 'ви': 'v', 'даблю': 'w',
    'экс': 'ex', 'дж': 'j', 'цс': 'cs', 'сиэс': 'cs', 'эс': 's',
}
_PHONETIC_CHARS = {
    'а': ('a',), 'б': ('b',), 'в': ('v', 'w'), 'г': ('g',), 'д': ('d',),
    'е': ('e',), 'ж': ('zh', 'g', 'j'), 'з': ('z',), 'и': ('i',), 'й': ('y',), 'к': ('k', 'c'),
    'л': ('l',), 'м': ('m',), 'н': ('n', 'h'), 'о': ('o',), 'п': ('p',),
    'р': ('r',), 'с': ('s', 'c'), 'т': ('t',), 'у': ('u', 'y'), 'ф': ('f',),
    'х': ('x', 'h'), 'ц': ('c',), 'ч': ('ch',), 'ш': ('sh',), 'ы': ('y',),
    'щ': ('sch', 'sh'), 'ь': ('',), 'ъ': ('',), 'э': ('e',),
    'ю': ('u', 'yu'), 'я': ('ya',),
}


def _phonetic_variants(raw, limit=64):
    value = raw.lower().replace('ё', 'е')
    for source, target in sorted(_PHONETIC_PREFIXES.items(), key=lambda item: len(item[0]), reverse=True):
        if value.startswith(source):
            value = target + value[len(source):]
            break
    variants = ['']
    for char in value:
        options = _PHONETIC_CHARS.get(char, (char,))
        variants = [prefix + option for prefix in variants for option in options][:limit]
    return set(variants)


def _phonetic_skeleton(value):
    value = value.lower().replace('sch', 'sh').replace('ch', 'c').replace('zh', 'j')
    value = value.translate(str.maketrans({'q': 'k', 'c': 'k', 'w': 'v', 'y': 'i', 'x': 'k'}))
    value = re.sub(r'[aeiou]', '', value)
    return re.sub(r'(.)\1+', r'\1', value)


def _phonetic_score(left, right):
    direct = SequenceMatcher(None, left, right).ratio()
    a, b = _phonetic_skeleton(left), _phonetic_skeleton(right)
    skeleton = SequenceMatcher(None, a, b).ratio() if len(a) >= 2 and len(b) >= 2 else 0
    return max(direct, skeleton)

def fuzzy_words(rows, query):
    """Resolve a token only to one unique catalogue token.

    Model codes are generated from the current catalogue, so В60/V60, Х5/X5,
    С4/C4 and similar spellings work without a per-model alias list.
    """
    q = words(query)
    known = set().union(*(words(r.get('brand','') + ' ' + r.get('model_name','')) for r in rows)) if rows else set()
    known_codes = {item for item in known if re.search(r'[a-z]', item) and re.search(r'\d', item)}
    source = query.lower().replace('ё', 'е')
    raw_codes = set(re.findall(r'[a-zа-я]+\d+[a-zа-я0-9]*', source))
    # Also accept separators in codes (V 50, CX-5, CS 55 Plus). A separated
    # phrase is joined only when it uniquely resolves to a code that exists in
    # the currently loaded catalogue.
    raw_codes |= {
        re.sub(r'[\s-]+', '', value)
        for value in re.findall(r'(?<![a-zа-я])[a-zа-я]{1,4}(?:[\s-]+[a-zа-я]{1,4})?[\s-]+\d+[a-zа-я0-9]*', source)
    }
    for raw in raw_codes:
        variants = _phonetic_variants(raw)
        hits = sorted(variants & known_codes)
        current = words(raw)
        if len(hits) == 1:
            q -= current
            for part in re.findall(r'[a-zа-я]+|\d+', raw):
                q -= words(part)
            q.add(hits[0])
    for raw in list(q):
        if raw in known or raw in REQUEST_WORDS or raw.isdigit() or len(raw) < 2:
            continue
        variants = _phonetic_variants(raw) if re.search(r'[а-я]', raw) else {raw}
        scores = sorted((
            (max(_phonetic_score(variant, item) for variant in variants), item)
            for item in known if len(item) >= 2
        ), reverse=True)
        threshold = .70 if re.search(r'[а-я]', raw) else .84
        if scores and scores[0][0] >= threshold and (len(scores) == 1 or scores[0][0] - scores[1][0] >= .08):
            q.discard(raw)
            q.add(scores[0][1])
    for raw in list(q):
        if raw.isdigit() and len(raw) >= 5:
            scores = sorted(((SequenceMatcher(None, raw, item).ratio(), item) for item in known if item.isdigit()), reverse=True)
            if scores and scores[0][0] >= .84 and (len(scores) == 1 or scores[0][0] - scores[1][0] >= .08):
                q.discard(raw)
                q.add(scores[0][1])
    return q

def model_core(row):
    model = words(row['model_name'])
    variants = {'i','ii','iii','iv','v','vi','рестайлинг','restyling','рест','plus','pro','max','ultra','плюс'}
    return model - variants - words(row['brand'])

def matches(row, q):
    core = model_core(row)
    # Significant model tokens, not arbitrary substrings (3008 is not 5008).
    if not core or not core <= q:
        return False
    all_words = words(row['model_name'] + ' ' + row['title'])
    variants = q & {'plus','pro','max','ultra','i','ii','iii','iv','рестайлинг','restyling'}
    if not variants <= all_words:
        return False
    years = {int(w) for w in q if re.fullmatch(r'(19|20)\d{2}', w)}
    if years and row.get('year') not in years:
        return False
    return True

def select(rows, query, limit=15, exclude_urls=None):
    q = fuzzy_words(rows, query)
    brands = set().union(*(words(r['brand']) for r in rows)) if rows else set()
    brands |= set('bmw audi toyota volkswagen kia hyundai renault peugeot skoda nissan haval changan geely li'.split())
    requested_brands = mentioned_brands(rows,query)
    brand_request = brand_only(rows,query)
    numeric_models = set().union(*(model_core(r) for r in rows)) if rows else set()
    # Keep unknown explicit codes too: «Volvo V70» must return zero V70 cards,
    # not silently turn into a list of every Volvo in the catalogue.
    codes = {w for w in q if re.search(r'[a-zа-я]', w) and re.search(r'\d', w)}
    codes |= {w for w in q if re.fullmatch(r'\d{3,5}', w) and not re.fullmatch(r'(19|20)\d{2}',w)}
    model_hit = any(matches(r, q) for r in rows)
    requested = bool(requested_brands or codes or model_hit or any(w in query.lower() for w in
        ('автомобил', 'машин', 'каталог', 'модел', 'налич', 'вариант', 'подберите', 'покажите', 'ссылк', 'есть')))
    if not requested:
        return None
    # Financial questions without a specific car do not trigger an unsolicited wall of links.
    if not (requested_brands or codes or model_hit) and any(w in query.lower() for w in ('кредит', 'лизинг', 'жалоб', 'претенз')):
        return None
    budget = re.search(r'до\s+(\d[\d\s]*)(?:\s*)(тыс(?:яч)?\.?)?\s*(byn|белорусских рублей|руб(?:лей)?\b)', query.lower())
    ceiling = int(re.sub(r'\s', '', budget[1])) * (1000 if budget[2] else 1) if budget else None
    valid = []
    seen = set()
    for row in rows:
        url = row['url']
        parsed = urlparse(url)
        if parsed.scheme != 'https' or parsed.netloc not in {'metropol-auto.by', 'www.metropol-auto.by'}:
            continue
        if len(parsed.path.strip('/').split('/')) < 4 or not parsed.path.startswith('/vehicles/'):
            continue
        if url in seen or len(url) > 500:
            continue
        seen.add(url)
        if not row.get('available',True):
            continue
        if requested_brands and not requested_brands <= words(row['brand']):
            continue
        if ceiling is not None and (not row.get('price_byn') or int(row['price_byn']) > ceiling):
            continue
        valid.append(row)
    exact = []
    for r in valid:
        model = words(r['model_name'])
        brand = words(r['brand'])
        qualifiers = q & {'plus', 'pro', 'max', 'ultra'}
        years={int(w) for w in q if re.fullmatch(r'(19|20)\d{2}',w)}
        brand_match=brand_request and (not years or r.get('year') in years)
        if (brand_match or matches(r, q)) and qualifiers <= words(r['model_name'] + ' ' + r['title']) and (not requested_brands or requested_brands <= brand) and (not codes or codes <= model):
            exact.append(r)
    pool = exact or valid
    pool.sort(key=lambda r: (
        len(words(r.get('title', '')) & q),
        len(words(r['model_name']) & q),
        len(words(r['brand']) & q),
        int(r.get('year') or 0),
    ), reverse=True)
    pool = [r for r in pool if r['url'] not in (exclude_urls or set())]
    return ('exact' if exact else 'alternatives', pool if limit is None else pool[:max(0, min(15, limit))], bool(requested_brands or codes or model_hit))

def _price(value):
    return f"{int(value):,}".replace(',', ' ') + ' BYN'


def reply(selection, prefix='', show_price=False, show_location=False, current=True, total_count=None):
    mode, rows, specific = selection
    if not rows:
        count_line = f"В текущем каталоге найдено автомобилей: {int(total_count)}. " if total_count is not None else ''
        text = ('Сейчас подходящей модели на сайте не вижу. Не все автомобили успевают попасть на сайт: '
                'лучшие варианты нередко продаются сразу после поступления. Приезжайте на площадку — '
                'вживую посмотрим все автомобили и постараемся подобрать подходящий вариант.') if specific else (
                'Сейчас не вижу подходящих карточек по этим условиям. Приезжайте на площадку — '
                'вживую посмотрим автомобили и постараемся подобрать подходящий вариант.')
        return (prefix + '\n\n' if prefix else '') + count_line + text
    if mode == 'exact':
        heading = 'Сейчас в продаже:' if current else 'В последней сохранённой версии каталога:'
    elif specific:
        heading = 'По этим условиям машину в сохранённом каталоге пока не нашёл. Вот другие варианты:'
    else:
        heading = 'Посмотрите автомобили из нашего каталога:'
    count_line = f"Найдено автомобилей: {int(total_count)}.\n" if total_count is not None else ''
    result = (prefix + '\n\n' if prefix else '') + count_line + heading
    for row in rows[:15]:
        title = ' '.join(row['title'].split())[:100]
        details = []
        if show_price and row.get('price_byn'):
            details.append(_price(row['price_byn']))
        if show_location and row.get('location'):
            details.append(row['location'])
        suffix = (' — ' + ', '.join(details)) if details else ''
        line = f"\n• {title}{suffix}: {row['url']}"
        if len(result) + len(line) > 3750:
            break
        result += line
    return result + '\n\nПриезжайте посмотреть автомобили вживую в Метрополь Авто.'


_CATALOG_FOLLOWUPS = {
    'покажи', 'покажите', 'покажи их', 'покажите их', 'покажи все', 'покажите все',
    'все', 'их', 'давай', 'давай все', 'какие есть', 'что есть', 'покажи варианты',
    'покажите варианты', 'пришли их', 'пришлите их', 'скинь их', 'скиньте их',
}
_SIMILAR_FOLLOWUP = re.compile(r'^(?:давай(?:те)?\s+)?(?:покажи(?:те)?\s+)?похож(?:ий|ую|ие|ее|ие варианты?)$', re.I)
_NON_CATALOG_TOPICS = re.compile(
    r'сравн|лучше|почему|дорог|скидк|торг|стоит ли|кредит|лизинг|плат[её]ж|взнос|'
    r'жалоб|претенз|гарант|диагност|характерист|расход|мощност|разгон|над[её]жн|боляч|ломается',
    re.I,
)


def direct_catalog_args(rows, query, preferences):
    """Return deterministic catalogue arguments for an unambiguous latest turn.

    This prevents a short vehicle name or a catalogue follow-up from being
    reinterpreted as financing, web search, or an unrelated older topic.
    """
    normalized = ' '.join(re.sub(r'[^a-zа-я0-9]+', ' ', query.lower().replace('ё', 'е')).split())
    previous = preferences.get('agent_filters') or {}
    has_previous = bool(previous.get('brand') or previous.get('model'))

    if has_previous and re.search(r'ещ[её]|другие\s+вариант|следующ|продолжи|дальше', normalized, re.I):
        return dict(brand=None, model=None, year_min=None, year_max=None,
                    max_price_byn=None, inherit_selection=True, more=True)
    if has_previous and normalized in _CATALOG_FOLLOWUPS:
        return dict(brand=None, model=None, year_min=None, year_max=None,
                    max_price_byn=None, inherit_selection=True, more=False)
    if has_previous and _SIMILAR_FOLLOWUP.fullmatch(normalized):
        return dict(brand=previous.get('brand'), model=None, year_min=None, year_max=None,
                    max_price_byn=None, inherit_selection=False, more=False)
    if _NON_CATALOG_TOPICS.search(normalized):
        return None

    selection = select(rows, query, limit=None)
    if selection is None or not selection[2]:
        return None
    status, picked, _ = selection
    requested_brands = mentioned_brands(rows, query)
    picked_brands = {r['brand'] for r in picked}
    picked_models = {r['model_name'] for r in picked}

    # A model code shared by several makes is genuinely ambiguous. Reuse an
    # explicit previous make when it has that model; otherwise let the agent ask.
    if len(picked_brands) > 1 and not requested_brands:
        previous_brand = previous.get('brand') if has_previous else None
        previous_rows = [r for r in picked if r['brand'].lower() == str(previous_brand or '').lower()]
        if previous_rows:
            picked = previous_rows
            picked_brands = {r['brand'] for r in picked}
            picked_models = {r['model_name'] for r in picked}
        else:
            return None

    brand = next(iter(picked_brands)) if len(picked_brands) == 1 else None
    if brand is None and len(requested_brands) == 1:
        brand = CANONICAL_BRANDS.get(next(iter(requested_brands)))
    model = None
    if not brand_only(rows, query) and len(picked_models) == 1:
        model = next(iter(picked_models))

    resolved = fuzzy_words(rows, query)
    years = {word for word in resolved if re.fullmatch(r'(19|20)\d{2}', word)}
    brand_tokens = set().union(*(words(r['brand']) for r in picked)) if picked else requested_brands
    query_model = resolved - brand_tokens - REQUEST_WORDS - years
    # When an explicit, simple model is absent from the catalogue, keep it as
    # the filter so the result is honestly zero instead of every car of a make.
    if model is None and brand and status != 'exact' and 0 < len(query_model) <= 3:
        model = ' '.join(re.findall(r'[a-zа-я0-9]+', query.lower().replace('ё', 'е'))[-len(query_model):])

    # A bare model/brand, availability question, or request to show cards is
    # unambiguously a catalogue action. Other substantive questions stay with AI.
    name_words = words(' '.join(filter(None, (brand, model))))
    residual = resolved - name_words - requested_brands - REQUEST_WORDS
    residual = {word for word in residual if not re.fullmatch(r'(19|20)\d{2}', word)}
    if residual:
        return None
    return dict(brand=brand, model=model, year_min=None, year_max=None,
                max_price_byn=None, inherit_selection=False, more=False)
