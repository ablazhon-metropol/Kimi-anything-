"""Owner-only, on-demand aggregates. No message bodies or personal data."""
from collections import Counter
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from .inventory import snapshot, model_count, stamp

MINSK=ZoneInfo('Europe/Minsk')

def menu():
    return {'inline_keyboard':[
        [{'text':'💱 Курсы НБРБ','callback_data':'owner:stats:rates'}, {'text':'🚗 Наличие','callback_data':'owner:stats:cars'}],
        [{'text':'Все сохранённые валюты','callback_data':'owner:stats:allrates'}],
        [{'text':'👥 Обращения','callback_data':'owner:stats:clients'}, {'text':'💰 Расход ИИ','callback_data':'owner:stats:costs'}],
        [{'text':'📊 Обновить сводку','callback_data':'owner:stats:overview'}]]}

class OwnerStats:
    def __init__(self,db,catalog,exchange,version):
        self.db,self.catalog,self.exchange,self.version=db,catalog,exchange,version

    def rates(self,now,all_rates=False):
        state=self.exchange.state(); lines=['💱 Курсы НБРБ — официальные']
        day=now.date().isoformat()
        for currency in (sorted(state.get('rates',{})) if all_rates else ('USD','EUR','RUB','CNY')):
            row=state.get('rates',{}).get(currency)
            if not row:
                lines.append(currency+': ещё не загружен'); continue
            status='актуальный' if row['date']==day else 'последний известный'
            lines.append(f"{row['scale']} {currency} = {row['rate']} BYN · {row['date']} · {status}")
        if state.get('error'): lines.append('Обновление не удалось; сохранённые курсы не удалены.')
        lines.append('Последнее успешное обновление: '+state.get('updated_day','нет')+'.')
        lines.append('Источник: НБРБ. Автообновление раз в сутки; при сбое — повторные попытки.')
        return '\n'.join(lines)

    def cars(self):
        rows,status=snapshot(self.db,self.catalog)
        if not status.get('last_success'): return '🚗 Каталог ещё не загружен. Количество не подтверждено.'
        coverage={'verified':'сверена с общим счётчиком сайта','traversed':'страницы обойдены, общего счётчика для сверки нет','unknown':'не подтверждена'}
        lines=['🚗 Загруженный каталог',f'В наличии: {len(rows)} автомобилей; разных моделей: {model_count(rows)}.',
               'По маркам:\n'+('\n'.join(f'{brand}: {n}' for brand,n in sorted(Counter(r['brand'].title() for r in rows).items())) or 'нет'),
               'Обновлён: '+stamp(status.get('last_success')), 'Полнота: '+coverage.get(status.get('coverage'),'не подтверждена')+'.',
               'Страниц: '+str(status.get('pages','0'))+'.',
               'Поколения и комплектации одной базовой модели не считаются отдельными моделями.']
        if status.get('coverage')!='verified': lines.append('Общее наличие на сайте может быть больше: показан только загруженный объём.')
        if status.get('last_error'): lines.append('Последняя синхронизация завершилась ошибкой; сохранена предыдущая загрузка. /catalog — диагностика.')
        return '\n'.join(lines)

    def periods(self,now):
        today=now.replace(hour=0,minute=0,second=0,microsecond=0)
        return [('Сегодня',today),('7 дней',today-timedelta(days=6)),('Этот месяц',today.replace(day=1))]

    def activity(self,now,costs=False):
        lines=['💰 Расчётный расход ИИ' if costs else '👥 Клиентские обращения']
        end=now.astimezone(timezone.utc).isoformat()
        for label,start in self.periods(now):
            args=(start.astimezone(timezone.utc).isoformat(),end)
            if costs:
                rows=self.db._execute('SELECT model, CASE WHEN client_id IS NULL THEN 1 ELSE 0 END AS is_test, COUNT(*) AS calls, COALESCE(SUM(cost_usd),0) AS cost FROM usage_events WHERE created_at>=%s AND created_at<=%s GROUP BY model, CASE WHEN client_id IS NULL THEN 1 ELSE 0 END ORDER BY model',args,'all')
                tests=sum(float(r['cost']) for r in rows if r['is_test']); clients=sum(float(r['cost']) for r in rows if not r['is_test'])
                lines.append(f'{label}: клиенты ${clients:.5f}; тесты ${tests:.5f}.')
                for r in rows:
                    lines.append(f"  {r['model'][:60]} · {'тесты' if r['is_test'] else 'клиенты'}: ${float(r['cost']):.5f}, вызовов {r['calls']}")
            else:
                row=self.db._execute("SELECT COUNT(*) AS messages, COUNT(DISTINCT m.client_id) AS clients FROM messages m JOIN clients c ON c.id=m.client_id WHERE m.direction='in' AND m.created_at>=%s AND m.created_at<=%s",args,'one')
                lines.append(f"{label}: клиентов {row['clients']}, входящих сообщений {row['messages']}.")
                funnel=self.db._execute("SELECT stage,COUNT(*) AS n FROM funnel_events WHERE created_at>=%s AND created_at<=%s GROUP BY stage",args,'all')
                values={r['stage']:int(r['n']) for r in funnel}
                lines.append("  Воронка: приглашений {invitation}; интересов {interest}; передач {handoff}; принято сотрудниками {accepted}.".format(
                    invitation=values.get('invitation',0), interest=values.get('interest',0),
                    handoff=values.get('handoff',0), accepted=values.get('accepted',0)))
        if not costs:
            rows=self.db._execute("SELECT h.status,COUNT(*) AS n FROM handoff_receipts h JOIN clients c ON c.id=h.client_id WHERE h.status!='closed' GROUP BY h.status",fetch='all')
            labels={'waiting':'ожидают уведомления','notified':'сотрудник уведомлён','accepted':'приняты сотрудником','escalated':'эскалация'}
            lines.append('Открытые передачи сейчас: '+(', '.join(f"{labels.get(r['status'],r['status'])}: {r['n']}" for r in rows) or '0')+'.')
            row=self.db._execute("SELECT COUNT(*) AS n FROM notification_queue WHERE status='pending'",fetch='one')
            lines.append(f"Уведомлений в очереди (включая ночные): {row['n']}.")
        lines.append('Периоды — по Минску. По сохранённым данным; это не статистика продаж.' if not costs else 'Это оценка приложения, не счёт провайдера. Периоды — по Минску; по сохранённым данным.')
        return '\n'.join(lines)

    def render(self,section='overview',now=None):
        now=(now or datetime.now(MINSK)).astimezone(MINSK)
        if section=='rates': return self.rates(now)
        if section=='allrates': return self.rates(now,True)
        if section=='cars': return self.cars()
        if section=='clients': return self.activity(now)
        if section=='costs': return self.activity(now,True)
        return f'📊 Агент Метрополь · {self.version}\n'+self.rates(now)+'\n\n'+self.cars()+'\n\nОбращения и расходы — кнопками ниже. Сводка запрашивается вручную.'
