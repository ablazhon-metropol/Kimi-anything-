"""Deterministic, bounded links from stored official catalogue cards only."""
import re
from difflib import SequenceMatcher
from urllib.parse import urlparse
from .prices import tokens

BRANDS = {'бмв':'bmw', 'мерседес':'mercedes benz', 'мерседес бенц':'mercedes benz',
          'ауди':'audi', 'тойота':'toyota', 'фольксваген':'volkswagen',
          'киа':'kia', 'хендай':'hyundai', 'хёндэ':'hyundai', 'рено':'renault',
          'пежо':'peugeot', 'шкода':'skoda', 'ниссан':'nissan', 'хавал':'haval'}
BRANDS.update({'чанган':'changan','чанганы':'changan','чанганов':'changan','чангана':'changan',
               'чанань':'changan','джили':'geely','джилей':'geely','шкоды':'skoda','тойоты':'toyota'})
BRANDS.update({'шевроле': 'chevrolet', 'шевролет': 'chevrolet'})
MODEL_ALIASES = {'эквинокс':'equinox', 'эквиноксы':'equinox', 'эквиноксов':'equinox',
                 'эквинокса':'equinox', 'эквиноксе':'equinox', 'эквиноксом':'equinox',
                 '55ка':'cs55 plus', '55-ка':'cs55 plus', 'цс55':'cs55 plus',
                 'сс55':'cs55 plus', 'кс55':'cs55 plus', 'cs55plus':'cs55 plus',
                 'чанган 55':'changan cs55 plus'}

REQUEST_WORDS=set('покажи покажите покажитека подбери подберите пришли пришлите скинь скиньте дай дайте ссылку ссылки на пожалуйста мне нам все весь ваши у вас в наличии есть сколько количество машин машины машину автомобилей автомобили авто моделей модели марок всего сейчас каталог каталоге из какие какие-то а и хочу посмотреть другие варианты следующие еще по марке марки бренд бренда только'.split())
REQUEST_WORDS.update({'нужен','нужна','нужны','интересует','интересуют'})

def mentioned_brands(rows, query):
    q=words(query)
    known=set('bmw audi toyota volkswagen kia hyundai renault peugeot skoda nissan haval changan geely li byd chery exeed zeekr voyah belgee mercedes benz'.split())
    for r in rows: known |= words(r['brand'])
    return q & known

def brand_only(rows, query):
    brands=mentioned_brands(rows,query)
    residual=words(query)-brands-REQUEST_WORDS
    residual={w for w in residual if not re.fullmatch(r'(19|20)\d{2}',w)}
    return bool(brands) and not residual

def words(text):
    text = text.lower()
    for alias, canonical in MODEL_ALIASES.items():
        text = re.sub(r'(?<!\w)' + re.escape(alias) + r'(?!\w)', canonical, text)
    for alias in sorted(BRANDS, key=len, reverse=True):
        text = re.sub(r'(?<!\w)' + re.escape(alias) + r'(?!\w)', BRANDS[alias], text)
    # Join only known model letters: never turn «а 3008» into a3008.
    text = re.sub(r'\b(cs|x|q|l|х|л|кс)[ -]+(\d+)\b', r'\1\2', text)
    text = re.sub(r'\b(первого|первое|1)\s+поколени[ея]\b', ' i ', text)
    text = re.sub(r'\b(второго|второе|2)\s+поколени[ея]\b', ' ii ', text)
    text = re.sub(r'\b(третьего|третье|3)\s+поколени[ея]\b', ' iii ', text)
    return set().union(*(tokens(w) for w in re.findall(r'[a-zа-я0-9]+', text.replace('ё','е'))))

def fuzzy_words(rows, query):
    """Add only a unique close catalogue token; never confuse 3008 with 5008."""
    q = words(query)
    known = set().union(*(words(r.get('brand','') + ' ' + r.get('model_name','')) for r in rows)) if rows else set()
    for raw in list(q):
        if raw in known or len(raw) < 4 or raw.isdigit():
            continue
        scores = sorted(((SequenceMatcher(None, raw, item).ratio(), item) for item in known if len(item) >= 4), reverse=True)
        if scores and scores[0][0] >= .84 and (len(scores) == 1 or scores[0][0] - scores[1][0] >= .08):
            q.add(scores[0][1])
    for raw in list(q):
        if raw.isdigit() and len(raw) >= 5:
            scores = sorted(((SequenceMatcher(None, raw, item).ratio(), item) for item in known if item.isdigit()), reverse=True)
            if scores and scores[0][0] >= .84 and (len(scores) == 1 or scores[0][0] - scores[1][0] >= .08):
                q.add(scores[0][1])
    return q

def model_core(row):
    model = words(row['model_name'])
    variants = {'i','ii','iii','iv','v','vi','рестайлинг','restyling','рест','plus','pro','max','ultra','плюс'}
    return model - variants - words(row['brand'])

def matches(row, q):
    core = model_core(row)
    # Significant model tokens, not arbitrary substrings (3008 is not 5008).
    if not core or not core <= q:
        return False
    all_words = words(row['model_name'] + ' ' + row['title'])
    variants = q & {'plus','pro','max','ultra','i','ii','iii','iv','рестайлинг','restyling'}
    if not variants <= all_words:
        return False
    years = {int(w) for w in q if re.fullmatch(r'(19|20)\d{2}', w)}
    if years and row.get('year') not in years:
        return False
    return True

def select(rows, query, limit=15, exclude_urls=None):
    q = fuzzy_words(rows, query)
    brands = set().union(*(words(r['brand']) for r in rows)) if rows else set()
    brands |= set('bmw audi toyota volkswagen kia hyundai renault peugeot skoda nissan haval changan geely li'.split())
    requested_brands = mentioned_brands(rows,query)
    brand_request = brand_only(rows,query)
    codes = {w for w in q if re.search(r'[a-zа-я]', w) and re.search(r'\d', w)}
    numeric_models = set().union(*(model_core(r) for r in rows)) if rows else set()
    codes |= {w for w in q if re.fullmatch(r'\d{3,4}',w) and not re.fullmatch(r'(19|20)\d{2}',w)}
    model_hit = any(matches(r, q) for r in rows)
    requested = bool(requested_brands or codes or model_hit or any(w in query.lower() for w in
        ('автомобил', 'машин', 'каталог', 'модел', 'налич', 'вариант', 'подберите', 'покажите', 'ссылк', 'есть')))
    if not requested:
        return None
    # Financial questions without a specific car do not trigger an unsolicited wall of links.
    if not (requested_brands or codes or model_hit) and any(w in query.lower() for w in ('кредит', 'лизинг', 'жалоб', 'претенз')):
        return None
    budget = re.search(r'до\s+(\d[\d\s]*)(?:\s*)(тыс(?:яч)?\.?)?\s*(byn|белорусских рублей|руб(?:лей)?\b)', query.lower())
    ceiling = int(re.sub(r'\s', '', budget[1])) * (1000 if budget[2] else 1) if budget else None
    valid = []
    seen = set()
    for row in rows:
        url = row['url']
        parsed = urlparse(url)
        if parsed.scheme != 'https' or parsed.netloc not in {'metropol-auto.by', 'www.metropol-auto.by'}:
            continue
        if len(parsed.path.strip('/').split('/')) < 4 or not parsed.path.startswith('/vehicles/'):
            continue
        if url in seen or len(url) > 500:
            continue
        seen.add(url)
        if not row.get('available',True):
            continue
        if requested_brands and not requested_brands <= words(row['brand']):
            continue
        if ceiling is not None and (not row.get('price_byn') or int(row['price_byn']) > ceiling):
            continue
        valid.append(row)
    exact = []
    for r in valid:
        model = words(r['model_name'])
        brand = words(r['brand'])
        qualifiers = q & {'plus', 'pro', 'max', 'ultra'}
        years={int(w) for w in q if re.fullmatch(r'(19|20)\d{2}',w)}
        brand_match=brand_request and (not years or r.get('year') in years)
        if (brand_match or matches(r, q)) and qualifiers <= words(r['model_name'] + ' ' + r['title']) and (not requested_brands or requested_brands <= brand) and (not codes or codes <= model):
            exact.append(r)
    pool = exact or valid
    pool.sort(key=lambda r: (
        len(words(r.get('title', '')) & q),
        len(words(r['model_name']) & q),
        len(words(r['brand']) & q),
        int(r.get('year') or 0),
    ), reverse=True)
    pool = [r for r in pool if r['url'] not in (exclude_urls or set())]
    return ('exact' if exact else 'alternatives', pool if limit is None else pool[:max(0, min(15, limit))], bool(requested_brands or codes or model_hit))

def _price(value):
    return f"{int(value):,}".replace(',', ' ') + ' BYN'


def reply(selection, prefix='', show_price=False, show_location=False, current=True, total_count=None):
    mode, rows, specific = selection
    if not rows:
        text = ('Сейчас подходящей модели на сайте не вижу. Не все автомобили успевают попасть на сайт: '
                'лучшие варианты нередко продаются сразу после поступления. Приезжайте на площадку — '
                'вживую посмотрим все автомобили и постараемся подобрать подходящий вариант.') if specific else (
                'Сейчас не вижу подходящих карточек по этим условиям. Приезжайте на площадку — '
                'вживую посмотрим автомобили и постараемся подобрать подходящий вариант.')
        return (prefix + '\n\n' if prefix else '') + text
    if mode == 'exact':
        heading = 'Сейчас в продаже:' if current else 'В последней сохранённой версии каталога:'
    elif specific:
        heading = 'По этим условиям машину в сохранённом каталоге пока не нашёл. Вот другие варианты:'
    else:
        heading = 'Посмотрите автомобили из нашего каталога:'
    count_line = f"Найдено автомобилей: {int(total_count)}.\n" if total_count is not None else ''
    result = (prefix + '\n\n' if prefix else '') + count_line + heading
    for row in rows[:15]:
        title = ' '.join(row['title'].split())[:100]
        details = []
        if show_price and row.get('price_byn'):
            details.append(_price(row['price_byn']))
        if show_location and row.get('location'):
            details.append(row['location'])
        suffix = (' — ' + ', '.join(details)) if details else ''
        line = f"\n• {title}{suffix}: {row['url']}"
        if len(result) + len(line) > 3750:
            break
        result += line
    return result + '\n\nПриезжайте посмотреть автомобили вживую в Метрополь Авто.'
