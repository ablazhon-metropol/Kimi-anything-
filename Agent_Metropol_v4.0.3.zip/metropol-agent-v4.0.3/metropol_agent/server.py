from __future__ import annotations

import hashlib
import hmac
import html
import logging
import re
import threading
import time
from contextlib import asynccontextmanager
from urllib.parse import parse_qs

import uvicorn
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from .admin_ui import page, price_form, prices_page, draft_page
from .ai import AIEngine
from .app import AgentApp, VERSION, panel_html
from .catalog import Catalog
from .config import Settings
from .db import Database
from .knowledge import KnowledgeBase
from .telegram import TelegramAPI
from .semantic_knowledge import SemanticKnowledge

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
log = logging.getLogger(__name__)
settings = Settings.from_env()
db = Database(settings.database_url, settings.data_encryption_key)
for boot_attempt in range(1, 11):
    try:
        db.migrate()
        break
    except Exception:
        if boot_attempt >= 10:
            raise
        log.warning("Database is not ready (attempt %s/10); retrying", boot_attempt, exc_info=True)
        time.sleep(min(10, boot_attempt))
telegram = TelegramAPI(settings.telegram_token)
knowledge = KnowledgeBase("knowledge/metropol.md")
catalog = Catalog(db, settings.catalog_url)
ai = AIEngine(settings, knowledge)
agent = AgentApp(settings, db, telegram, ai, catalog)
semantic = SemanticKnowledge(settings, db, knowledge, ai.client)
ai.semantic = semantic
agent.semantic = semantic
_login_lock = threading.Lock()
_login_failures: dict[str, list[float]] = {}


def _login_key(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for", "").split(",", 1)[0].strip()
    host = forwarded or (request.client.host if request.client else "unknown")
    return hashlib.sha256((host + "|" + request.headers.get("user-agent", "")[:120]).encode()).hexdigest()


def _login_blocked(key: str) -> bool:
    cutoff = time.time() - 900
    with _login_lock:
        _login_failures[key] = [stamp for stamp in _login_failures.get(key, []) if stamp >= cutoff]
        return len(_login_failures[key]) >= 5


def _login_failed(key: str) -> None:
    with _login_lock:
        _login_failures.setdefault(key, []).append(time.time())


def _login_clear(key: str) -> None:
    with _login_lock:
        _login_failures.pop(key, None)


def _startup() -> None:
    if not db.cipher.enabled:
        log.error("DATA_ENCRYPTION_KEY is not configured: sensitive database fields are not encrypted")
        if settings.owner_id:
            db.enqueue_outbox(settings.owner_id,
                "⚠️ Агент Метрополь: DATA_ENCRYPTION_KEY не настроен. Чувствительные поля базы не шифруются. Исправьте переменную Railway.",
                dedupe_key="security-no-encryption-v4.0.3")
    try:
        if settings.telegram_token and settings.public_base_url:
            telegram.set_webhook(f"{settings.public_base_url}/telegram/webhook", settings.webhook_secret)
            telegram.set_commands(settings.owner_id)
            log.info("Telegram webhook and command scopes configured")
        else:
            log.warning("Telegram webhook not configured: token or PUBLIC_BASE_URL missing")
    except Exception:
        log.exception("Telegram bootstrap failed; service will keep running and retry outbound delivery")

    for target, name in (
        (_reply_loop, "reply-worker"),
        (_outbox_loop, "outbox-worker"),
        (_maintenance_loop, "maintenance"),
        (_embedding_loop, "knowledge-index"),
    ):
        threading.Thread(target=target, name=name, daemon=True).start()


def _embedding_loop() -> None:
    while True:
        try:
            semantic.backfill()
        except Exception:
            log.exception("Knowledge embedding backfill failed; keyword search remains active")
        time.sleep(900)


@asynccontextmanager
async def lifespan(_: FastAPI):
    _startup()
    yield


api = FastAPI(title="Агент Метрополь", version=VERSION, lifespan=lifespan)


def _reply_loop() -> None:
    while True:
        try:
            processed = agent.process_due_jobs()
        except Exception:
            processed = 0
            log.exception("reply worker iteration failed")
        time.sleep(0.15 if processed else 0.75)


def _outbox_loop() -> None:
    while True:
        try:
            processed = agent.process_outbox()
        except Exception:
            processed = 0
            log.exception("outbox worker iteration failed")
        time.sleep(0.1 if processed else 0.6)


def _maintenance_loop() -> None:
    last_catalog = 0.0
    last_cleanup = 0.0
    last_model_check = 0.0
    while True:
        stamp = time.time()
        try:
            agent.exchange.refresh()
        except Exception:
            log.exception('NBRB cache refresh failed')
        if stamp - last_model_check >= 3600:
            try:
                log.info("OpenAI model validation: %s", ai.validate_models())
            except Exception:
                log.exception("OpenAI model validation failed")
            last_model_check = stamp
        if stamp - last_catalog >= 900:
            try:
                count = catalog.sync()
                log.info("Catalog synchronized: %s cars", count)
            except Exception:
                log.exception("Catalog synchronization failed; last known good snapshot retained")
            last_catalog = stamp
        try:
            flushed = agent.flush_morning_queue()
            agent.followups.enqueue_due()
            agent.handoffs.check()
            if flushed:
                log.info("Morning queue flushed: %s", flushed)
        except Exception:
            log.exception("Morning queue flush failed")
        if stamp - last_cleanup >= 86400:
            try:
                removed = db.cleanup(settings.message_retention_days, settings.audit_retention_days)
                log.info("Retention cleanup completed: %s", removed)
            except Exception:
                log.exception("Retention cleanup failed")
            last_cleanup = stamp
        try:
            _check_system_alerts()
        except Exception:
            log.exception("System alert check failed")
        time.sleep(30)


def _check_system_alerts() -> None:
    if not settings.owner_id:
        return
    stats = db.stats()
    failed_outbox = db._execute("SELECT COUNT(*) AS n FROM outbox WHERE status='failed'", fetch="one")["n"]
    problems = []
    if int(stats.get("failed_jobs", 0)) >= 5:
        problems.append(f"ошибок ответов: {stats['failed_jobs']}")
    if int(failed_outbox) >= 5:
        problems.append(f"ошибок Telegram-отправки: {failed_outbox}")
    if ai.validation_state in {"fallback_required", "unverified"}:
        problems.append("модели OpenAI: " + ai.validation_state)
    if catalog.status().get("last_error"):
        problems.append("обновление каталога завершилось ошибкой")
    web_failures = int(db.get_setting('web_search_consecutive_failures') or 0)
    if web_failures >= 3:
        problems.append(f"ошибок веб-поиска подряд: {web_failures}")
    if not problems:
        return
    bucket = int(time.time() // 21600)
    db.enqueue_outbox(settings.owner_id, "⚠️ Агент Метрополь: " + "; ".join(problems) + ". Проверьте /status и /catalog.",
        dedupe_key=f"system-alert-{bucket}")


@api.get("/health")
def health() -> JSONResponse:
    try:
        db_ok = db.ping()
        payload = {
            "status": "ok" if db_ok else "degraded",
            "service": "metropol-agent",
            "version": VERSION,
        }
        return JSONResponse(payload, status_code=200 if db_ok else 503)
    except Exception as exc:
        return JSONResponse(
            {"status": "error", "service": "metropol-agent", "version": VERSION, "error": type(exc).__name__},
            status_code=503,
        )


@api.get("/admin/health")
def admin_health(request: Request) -> JSONResponse:
    if not _admin_authorized(request):
        raise HTTPException(403, "not authorized")
    stats = db.stats()
    return JSONResponse({"status": "ok" if db.ping() else "degraded", "service": "metropol-agent", "version": VERSION,
        "database": {"backend": db.backend, "ok": db.ping(), "encryption": db.cipher.enabled},
        "models": ai.status(), "catalog": catalog.status(),
        "queues": {key: stats[key] for key in ("reply_jobs", "outbox", "failed_jobs")}})


@api.post("/telegram/webhook")
async def webhook(request: Request, x_telegram_bot_api_secret_token: str | None = Header(default=None)) -> dict:
    if settings.webhook_secret and not hmac.compare_digest(
        x_telegram_bot_api_secret_token or "", settings.webhook_secret
    ):
        raise HTTPException(403, "invalid webhook secret")
    update = await request.json()
    agent.handle_update(update)
    return {"ok": True}


def _admin_cookie_value() -> str:
    return hmac.new(settings.admin_token.encode(), b"metropol-admin-v3.1", hashlib.sha256).hexdigest()


def _admin_authorized(request: Request) -> bool:
    if not settings.admin_token:
        return False
    cookie = request.cookies.get("metropol_admin", "")
    if cookie and hmac.compare_digest(cookie, _admin_cookie_value()):
        return True
    authorization = request.headers.get("authorization", "")
    if authorization.startswith("Bearer "):
        return hmac.compare_digest(authorization[7:], settings.admin_token)
    return False


def _login_html(error: str = "", next_path: str = "/admin") -> str:
    message = f"<p style='color:#ff9b9b'>{html.escape(error)}</p>" if error else ""
    return f"""<!doctype html><html lang='ru'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>Вход — Агент Метрополь</title><style>body{{font-family:system-ui;background:#071a2d;color:#fff;padding:30px;max-width:480px;margin:auto}}form{{background:#102b47;border:1px solid #b99a52;border-radius:18px;padding:22px}}h1{{color:#e3c274}}input{{box-sizing:border-box;width:100%;padding:13px;margin:8px 0 16px;border-radius:10px;border:0}}button{{background:#e3c274;color:#071a2d;border:0;border-radius:10px;padding:12px 18px;font-weight:700}}</style>
<h1>Агент Метрополь</h1>{message}<form method='post'><input type='hidden' name='next' value='{html.escape(next_path, quote=True)}'><label>Пароль администратора</label><input type='password' name='token' required autocomplete='current-password'><button type='submit'>Войти</button></form></html>"""


@api.get("/admin/login", response_class=HTMLResponse)
def admin_login_page(request: Request) -> str:
    return _login_html(next_path=_safe_next(request.query_params.get("next", "")))


@api.post("/admin/login")
async def admin_login(request: Request):
    key = _login_key(request)
    if _login_blocked(key):
        return HTMLResponse(_login_html("Слишком много попыток. Повторите через 15 минут."), status_code=429)
    form = parse_qs((await request.body()).decode("utf-8", "replace"))
    token = (form.get("token") or [""])[0]
    if not settings.admin_token or not hmac.compare_digest(token, settings.admin_token):
        _login_failed(key)
        return HTMLResponse(_login_html("Неверный пароль", _safe_next((form.get("next") or [""])[0])), status_code=403)
    _login_clear(key)
    response = RedirectResponse(_safe_next((form.get("next") or [""])[0]), status_code=303)
    response.set_cookie(
        "metropol_admin", _admin_cookie_value(), httponly=True,
        secure=settings.public_base_url.startswith("https://"), samesite="strict", max_age=86400,
    )
    return response


@api.get("/admin/logout")
def admin_logout():
    response = RedirectResponse("/admin/login", status_code=303)
    response.delete_cookie("metropol_admin")
    return response


@api.get("/admin", response_class=HTMLResponse)
def admin(request: Request):
    if not _admin_authorized(request):
        return RedirectResponse("/admin/login", status_code=303)
    return panel_html(
        db.stats(), db.clients(50), catalog.status(), ai.status(),
        db.knowledge_entries(100), db.approved_prices(100),
    )


@api.post("/admin/knowledge")
async def admin_knowledge(request: Request):
    if not _admin_authorized(request):
        raise HTTPException(403, "not authorized")
    form = parse_qs((await request.body()).decode("utf-8", "replace"))
    title = (form.get("title") or [""])[0].strip()
    body = (form.get("body") or [""])[0].strip()
    if not title or not body or len(title) > 150 or len(body) > 20000:
        raise HTTPException(422, "invalid knowledge entry")
    entry_id = db.save_knowledge_entry(title, body, "admin-panel")
    db.audit("admin-panel", "knowledge_saved", {"entry_id": entry_id, "title": title})
    threading.Thread(target=semantic.backfill, name="knowledge-entry-index", daemon=True).start()
    return RedirectResponse("/admin", status_code=303)


@api.post("/admin/prices")
async def admin_prices(request: Request):
    if not _admin_authorized(request):
        raise HTTPException(403, "not authorized")
    form = parse_qs((await request.body()).decode("utf-8", "replace"))
    label = (form.get("label") or [""])[0].strip()
    matcher = (form.get("matcher") or [""])[0].strip() or label
    price_text = (form.get("price_text") or [""])[0].strip()
    if not label or not matcher or not price_text or max(len(label), len(matcher)) > 150 or len(price_text) > 300:
        raise HTTPException(422, "invalid approved price")
    raw_id = (form.get("price_id") or [""])[0]
    if raw_id:
        if not raw_id.isdigit():
            raise HTTPException(422, "invalid price id")
        price_id = int(raw_id)
        expected = (form.get("expected") or [""])[0]
        if not db.update_price_checked(price_id, label, matcher, price_text, expected):
            return HTMLResponse(page("Цена уже изменена", "<p>Обновите карточку, чтобы не затереть более свежие изменения.</p><a href='/admin/prices'>Вернуться к ценам</a>"), status_code=409)
    else:
        price_id = db.save_approved_price(label, matcher, price_text, "admin-panel")
    db.audit("admin-panel", "price_approved", {"price_id": price_id, "label": label})
    return RedirectResponse("/admin/prices", status_code=303)


def _safe_next(path):
    return path if re.fullmatch(r"/admin(?:/prices(?:/\d+)?|/drafts/\d+)?", path) else "/admin"


def _require_page_login(request):
    if not _admin_authorized(request):
        return RedirectResponse("/admin/login?next=" + _safe_next(request.url.path), status_code=303)
    return None


@api.get("/admin/prices", response_class=HTMLResponse)
def price_list(request: Request):
    return _require_page_login(request) or prices_page(db.approved_prices(10000))


@api.get("/admin/prices/{price_id}", response_class=HTMLResponse)
def price_edit(price_id: int, request: Request):
    login = _require_page_login(request)
    if login:
        return login
    row = next((r for r in db.approved_prices(10000) if r["id"] == price_id), None)
    if not row:
        raise HTTPException(404, "price not found")
    return page("Изменить цену", '<section class="card">' + price_form(row) + '</section>')


@api.get("/admin/drafts/{draft_id}", response_class=HTMLResponse)
def draft_edit(draft_id: int, request: Request):
    login = _require_page_login(request)
    if login:
        return login
    draft = db.get_draft(draft_id)
    if not draft or draft["status"] not in {"pending", "editing"}:
        return HTMLResponse(page("Ответ уже обработан", "<p>Этот черновик больше нельзя отправить.</p>"), status_code=409)
    client = db.client_by_id(int(draft["client_id"]))
    if not client or client["mode"] == "human":
        raise HTTPException(409, "client already transferred")
    return draft_page(draft, client)


@api.post("/admin/drafts/{draft_id}", response_class=HTMLResponse)
async def draft_send(draft_id: int, request: Request):
    if not _admin_authorized(request):
        raise HTTPException(403, "not authorized")
    form = parse_qs((await request.body()).decode("utf-8", "replace"))
    text = (form.get("text") or [""])[0].strip()
    if not text or len(text) > 4000:
        raise HTTPException(422, "invalid answer")
    with db.lock:
        draft = db.get_draft(draft_id)
        if not draft or draft["status"] not in {"pending", "editing"}:
            raise HTTPException(409, "draft already processed")
        client = db.client_by_id(int(draft["client_id"]))
        if not client or client["mode"] == "human":
            raise HTTPException(409, "client already transferred")
        agent._accept_owner_correction(settings.owner_id, draft_id, text)
    return page("Ответ в очереди отправки", "<p>Исправленный ответ сохранён и поставлен в очередь клиенту. Повторно нажимать отправку не нужно.</p><a href='/admin'>Вернуться в панель</a>")



def run() -> None:
    uvicorn.run(api, host="0.0.0.0", port=settings.port)
