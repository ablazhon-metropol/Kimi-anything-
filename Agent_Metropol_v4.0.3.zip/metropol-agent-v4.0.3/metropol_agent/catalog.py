from __future__ import annotations

import logging
import re
import threading
from dataclasses import dataclass
from difflib import SequenceMatcher
from urllib.parse import urljoin, urlparse, parse_qs, urldefrag

import httpx
from bs4 import BeautifulSoup

from .db import Database

log = logging.getLogger(__name__)


@dataclass
class Car:
    title: str
    url: str
    brand: str = ""
    model_name: str = ""
    year: int | None = None
    price_byn: int | None = None
    location: str = ""


def _normalize(text: str) -> str:
    text = text.lower().replace("ё", "е")
    text = re.sub(r"[^a-zа-я0-9]+", " ", text)
    return " ".join(text.split())


def _words(text: str) -> set[str]:
    return {word for word in _normalize(text).split() if len(word) >= 2}


class Catalog:
    """Verified `/vehicles/` parser with a last-known-good snapshot in the database."""

    def __init__(self, db: Database, base_url: str = "https://metropol-auto.by/vehicles/"):
        self.db = db
        self.base_url = base_url.rstrip("/") + "/"
        self.lock = threading.RLock()

    @staticmethod
    def _details_path(url: str) -> tuple[bool, list[str]]:
        parts = [part for part in urlparse(url).path.split("/") if part]
        # Confirmed structure: /vehicles/{brand}/{model}/{vehicle-slug}/
        return len(parts) >= 4 and parts[0].lower() == "vehicles", parts

    @staticmethod
    def _card_text(anchor: object) -> str:
        node = anchor
        best = ""
        for _ in range(6):
            node = getattr(node, "parent", None)
            if node is None:
                break
            text = " ".join(node.get_text(" ", strip=True).split())
            detail_paths={urlparse(a.get('href','')).path for a in node.select('a[href]') if Catalog._details_path(a.get('href',''))[0]}
            if len(detail_paths)>1:
                break
            if 20 <= len(text) <= 900:
                best = text
            if "В наличии" in text and re.search(r"\d[\d\s]{2,}\s*BYN", text):
                return text
        return best

    def parse(self, html: str) -> list[dict]:
        soup = BeautifulSoup(html, "html.parser")
        expected_host = urlparse(self.base_url).netloc
        found: dict[str, dict] = {}
        for anchor in soup.select("a[href]"):
            url = urljoin(self.base_url, anchor.get("href", ""))
            if urlparse(url).netloc != expected_host:
                continue
            is_details, parts = self._details_path(url)
            if not is_details:
                continue
            parsed=urlparse(url)
            url=parsed._replace(query='',fragment='',path=parsed.path.rstrip('/')+'/').geturl()
            title = " ".join(anchor.get_text(" ", strip=True).split())
            if len(title) < 4 or title.lower() in {"подробно о модели", "смотреть", "перейти"}:
                continue
            card = self._card_text(anchor)
            year_match = re.search(r"\b(19\d{2}|20\d{2})\s*г?\.?", card)
            price_match = re.search(r"(\d[\d\s]{2,})\s*BYN", card, re.IGNORECASE)
            location = ""
            if "Горецкого" in card:
                location = "Горецкого, 6А"
            if "Мазурова" in card:
                location = (location + "; " if location else "") + "Мазурова, 1"
            found[url] = {
                "title": title[:220],
                "url": url,
                "brand": parts[1].replace("-", " ").title(),
                "model_name": parts[2].replace("-", " "),
                "year": int(year_match.group(1)) if year_match else None,
                "price_byn": int(re.sub(r"\s", "", price_match.group(1))) if price_match else None,
                "location": location,
                "available": "в наличии" in card.lower() and "нет в наличии" not in card.lower(),
            }
        return list(found.values())

    def sync(self) -> int:
        headers = {
            "User-Agent": "Mozilla/5.0 (compatible; MetropolAgent/4.0.3; +https://metropol-auto.by)",
            "Accept": "text/html,application/xhtml+xml",
        }
        try:
            with httpx.Client(follow_redirects=True, timeout=30, headers=headers, trust_env=False) as client:
                pending, visited, collected = [self.base_url], set(), {}
                expected=None
                hidden_more=False
                while pending:
                    page = pending.pop(0)
                    if page in visited:
                        continue
                    if len(visited) >= 100:
                        raise RuntimeError('catalog pagination exceeds safe limit; keeping previous snapshot')
                    response = client.get(page)
                    response.raise_for_status()
                    visited.add(page)
                    if page==self.base_url:
                        expected=self.expected_total(response.text)
                    hidden_more = hidden_more or self.has_hidden_paging(response.text)
                    for car in self.parse(response.text):
                        collected[car['url']] = car
                    for next_url in self.page_links(response.text, page):
                        if next_url not in visited and next_url not in pending:
                            pending.append(next_url)
                cars = list(collected.values())
            if expected is not None and len(cars)!=expected:
                raise RuntimeError(f'catalog incomplete: expected {expected}, parsed {len(cars)}; keeping previous snapshot')
            if not cars and expected!=0:
                raise RuntimeError('empty catalogue not confirmed by site; keeping previous snapshot')
            coverage='verified' if expected is not None else 'traversed'
            if hidden_more and expected is None:
                raise RuntimeError('dynamic pagination not verified; keeping previous snapshot')
            if self.db.get_setting('catalog_coverage')=='verified' and coverage!='verified':
                raise RuntimeError('catalog completeness proof missing; keeping last verified snapshot')
            with self.lock:
                self.db.replace_catalog(cars,coverage,len(visited))
            return len(cars)
        except Exception as exc:
            self.db.catalog_failed(str(exc))
            raise

    @staticmethod
    def expected_total(html):
        soup=BeautifulSoup(html,'html.parser')
        totals=set()
        for node in soup.select('[data-total-vehicles], .woocommerce-result-count'):
            value=node.get('data-total-vehicles')
            if value and str(value).isdigit(): totals.add(int(value))
            else:
                m=re.search(r'(?:из|всего)\s+(\d+)',node.get_text(' ',strip=True),re.I)
                if m: totals.add(int(m[1]))
        # Generic ItemList.numberOfItems may describe only one page, not the catalogue.
        # It is deliberately not accepted as proof of total inventory.
        text=soup.get_text(' ',strip=True)
        for m in re.finditer(r'Всего\s*:?\s*(\d+)\s+(?:автомобил\w*|машин\w*)',text,re.I): totals.add(int(m[1]))
        if len(totals)>1: raise RuntimeError('conflicting catalogue totals')
        return next(iter(totals)) if totals else None

    @staticmethod
    def has_hidden_paging(html):
        soup=BeautifulSoup(html,'html.parser')
        return any(re.search(r'показать ещ[её]|загрузить ещ[её]|load more',n.get_text(' ',strip=True),re.I)
                   for n in soup.select('button, a:not([href]), a[href="#"]'))

    def page_links(self, html, current_url):
        result = []
        base = urlparse(self.base_url)
        for a in BeautifulSoup(html, 'html.parser').select('a[href]'):
            url = urldefrag(urljoin(current_url, a['href']))[0]
            parsed = urlparse(url)
            params = parse_qs(parsed.query)
            pagination = any(k.lower() in {'page', 'paged', 'pagen_1', 'pagen_2'} for k in params)
            path_page = bool(re.fullmatch(re.escape(base.path) + r'page/\d+/?', parsed.path))
            if parsed.scheme == 'https' and parsed.netloc == base.netloc and ((parsed.path == base.path and pagination) or path_page):
                result.append(url)
        return result

    def search(self, query: str, limit: int = 3) -> list[Car]:
        normalized_query = _normalize(query)
        query_words = _words(query)
        if not normalized_query:
            return []
        ranked: list[tuple[float, int, Car]] = []
        with self.lock:
            rows = self.db.catalog_rows()
        for row in rows:
            candidate = _normalize(f"{row['brand']} {row['model_name']} {row['title']} {row.get('year') or ''}")
            candidate_words = _words(candidate)
            overlap = len(query_words & candidate_words)
            fuzzy = SequenceMatcher(None, normalized_query, candidate).ratio()
            substring = 1.0 if normalized_query in candidate else 0.0
            score = overlap * 3.0 + fuzzy + substring * 3.0
            if overlap or fuzzy >= 0.42:
                ranked.append(
                    (
                        score,
                        int(row["id"]),
                        Car(
                            title=row["title"],
                            url=row["url"],
                            brand=row["brand"],
                            model_name=row["model_name"],
                            year=row.get("year"),
                            price_byn=row.get("price_byn"),
                            location=row.get("location", ""),
                        ),
                    )
                )
        ranked.sort(key=lambda item: (item[0], item[1]), reverse=True)
        return [car for _, _, car in ranked[:limit]]

    def status(self) -> dict:
        return {
            "count": len(self.db.catalog_rows()),
            "last_success": self.db.get_setting("catalog_last_success"),
            "last_error": self.db.get_setting("catalog_last_error"),
            "coverage": self.db.get_setting('catalog_coverage','unknown'),
            "pages": self.db.get_setting('catalog_pages','0'),
        }
