import json
import unittest
from datetime import datetime, timezone
from unittest.mock import patch, MagicMock
import test_reliability as reliability
from test_v330 import car
from metropol_agent.app import AgentApp
from metropol_agent.catalog import Catalog
from metropol_agent.catalog_selection import select
from metropol_agent.inventory import count_answer, model_count
from metropol_agent.preferences import Preferences
from metropol_agent.owner_stats import OwnerStats
from metropol_agent.exchange import ExchangeRates

class Update380(unittest.TestCase):
    setUp=reliability.ReliabilityTests.setUp
    tearDown=reliability.ReliabilityTests.tearDown

    def cars(self):
        return [car(i,'Changan','UNI Z') for i in range(1,8)]+[car(10,'Geely','Coolray')]

    def app(self):
        return AgentApp(reliability.settings(),self.db,reliability.FakeTelegram(),reliability.FakeAI(),Catalog(self.db))

    def test_plural_brand_returns_changan_only(self):
        for query in ('Покажи чанганы','Покажите Changan','Есть чанганы','Сколько чанганов'):
            result=select(self.cars(),query)
            self.assertEqual(result[0],'exact',query)
            self.assertEqual(len(result[1]),7)
            self.assertTrue(all(r['brand']=='Changan' for r in result[1]))

    def test_brand_absent_does_not_fall_back_to_geely(self):
        self.assertEqual(select([car(1,'Geely','Coolray')],'Покажи чанганы')[1],[])

    def test_missing_model_alternatives_still_same_brand(self):
        result=select(self.cars(),'Changan CS55')
        self.assertEqual(result[0],'alternatives')
        self.assertTrue(all(r['brand']=='Changan' for r in result[1]))

    def test_brand_resets_previous_model(self):
        p=Preferences(self.db)
        p.update('test','Хочу Geely Coolray 2026',self.cars())
        updated=p.update('test','Покажи чанганы',self.cars())
        self.assertEqual(updated['brand'],'Changan')
        self.assertNotIn('model',updated)
        self.assertNotIn('year',updated)

    def test_next_page_is_empty_after_all_brand_cards_were_shown(self):
        p=Preferences(self.db)
        effective,prefs,first=p.pick('test','Покажи чанганы',self.cars())
        p.shown('test',prefs,first[1])
        effective,prefs,nextpage=p.pick('test','Покажите другие варианты',self.cars())
        self.assertFalse(nextpage[1])
        self.assertFalse({r['url'] for r in first[1]} & {r['url'] for r in nextpage[1]})

    def test_counts_all_not_three(self):
        self.db.replace_catalog(self.cars(),'verified',2)
        text=count_answer(self.db,Catalog(self.db),'Сколько машин у вас в наличии?')
        self.assertIn('8 автомобилей',text)
        self.assertIn('https://metropol-auto.by/vehicles/',text)
        text=count_answer(self.db,Catalog(self.db),'Сколько чанганов?')
        self.assertIn('7 автомобилей',text)

    def test_count_models_separate_from_cars(self):
        self.db.replace_catalog(self.cars(),'verified',2)
        self.assertIn('2 разных моделей',count_answer(self.db,Catalog(self.db),'Сколько моделей у вас?'))

    def test_unknown_numeric_model_not_brand_total(self):
        self.db.replace_catalog([car(i,'Peugeot','3008') for i in range(1,8)],'verified',2)
        self.assertIn('0 автомобилей',count_answer(self.db,Catalog(self.db),'Сколько Peugeot 5008 в наличии?'))
        self.assertIn('7 автомобилей',count_answer(self.db,Catalog(self.db),'Сколько Peugeot 3008 в наличии?'))

    def test_unavailable_not_counted(self):
        rows=self.cars(); rows[0]['available']=False
        self.db.replace_catalog(rows,'verified',2)
        self.assertIn('7 автомобилей',count_answer(self.db,Catalog(self.db),'Сколько машин?'))

    def test_no_snapshot_is_not_zero(self):
        text=count_answer(self.db,Catalog(self.db),'Сколько машин?')
        self.assertIn('не подтверждено',text)
        self.assertNotIn('0 автомобилей',text)

    def test_partial_and_failed_sync_honest(self):
        self.db.replace_catalog(self.cars(),'traversed',1)
        self.db.catalog_failed('failure')
        text=count_answer(self.db,Catalog(self.db),'Сколько машин?')
        self.assertIn('полнота загрузки пока не подтверждена',text)
        self.assertIn('обновление не удалось',text)

    def test_credit_query_not_count(self):
        self.assertIsNone(count_answer(self.db,Catalog(self.db),'Сколько платить за Changan?'))

    def test_app_count_bypasses_ai(self):
        self.db.replace_catalog(self.cars(),'verified',2)
        app=self.app()
        answer=app._prepare_answer('Сколько машин у вас в наличии?',[],None,None,'test-count')
        self.assertEqual(answer[1],'local-inventory')
        self.assertEqual(app.ai.queries,[])

    def test_owner_menu_has_stats(self):
        self.assertIn('owner:stats:overview',str(self.app()._panel_keyboard()))

    def test_non_owner_callback_denied(self):
        app=self.app()
        app._handle_callback({'id':'x','from':{'id':123},'data':'owner:stats:costs'})
        self.assertEqual(app.telegram.callbacks[-1][1],'Недостаточно прав')
        self.assertFalse(self.db.claim_outbox(10))

    def test_owner_callback_works_without_ai(self):
        app=self.app()
        app._handle_callback({'id':'x','from':{'id':app.settings.owner_id},'data':'owner:stats:overview'})
        messages=self.db.claim_outbox(10)
        self.assertTrue(messages)
        self.assertIn('4.0.1',messages[0]['text'])
        self.assertEqual(app.ai.queries,[])

    def test_rates_scale_dates_and_stale(self):
        self.db.set_setting('nbrb-rates',json.dumps({'rates':{'RUB':{'scale':100,'rate':'3.5','date':'2026-09-02'},'USD':{'scale':1,'rate':'3','date':'2026-09-03'}}}))
        stats=OwnerStats(self.db,Catalog(self.db),ExchangeRates(self.db),'3.8.0')
        text=stats.render('rates',datetime(2026,9,3,7,tzinfo=timezone.utc))
        self.assertIn('100 RUB = 3.5 BYN',text)
        self.assertIn('последний известный',text)
        self.assertIn('1 USD = 3 BYN',text)

    def test_costs_separate_tests_and_clients(self):
        client=self.db.upsert_client('123','name','','auto')
        self.db.record_usage('a',None,'luna',{'cost_usd':.2})
        self.db.record_usage('b',client['id'],'sol',{'cost_usd':.3})
        stats=OwnerStats(self.db,Catalog(self.db),ExchangeRates(self.db),'3.8.0')
        text=stats.render('costs')
        self.assertIn('клиенты $0.30000; тесты $0.20000',text)
        self.assertIn('luna · тесты',text)
        self.assertIn('sol · клиенты',text)

    def test_min_sk_boundary(self):
        stats=OwnerStats(self.db,Catalog(self.db),ExchangeRates(self.db),'3.8.0')
        from metropol_agent.owner_stats import MINSK
        starts=stats.periods(datetime(2026,9,3,0,30,tzinfo=MINSK))
        self.assertEqual(starts[0][1].astimezone(timezone.utc).isoformat(),'2026-09-02T21:00:00+00:00')

    def test_parser_deduplicates_tracking_links(self):
        html='<div>Changan UNI Z 2026 г. 60000 BYN В наличии <a href="/vehicles/changan/uni-z/one/?x=1">Changan UNI Z</a><a href="/vehicles/changan/uni-z/one/#photo">Changan UNI Z</a></div>'
        self.assertEqual(len(Catalog(self.db).parse(html)),1)

    def test_adjacent_sold_car_not_made_available(self):
        html='<main><div>Changan UNI Z В наличии 60000 BYN <a href="/vehicles/changan/uni-z/one/">Changan UNI Z</a></div><div>Geely Coolray Продан <a href="/vehicles/geely/coolray/two/">Geely Coolray</a></div></main>'
        rows=Catalog(self.db).parse(html)
        self.assertTrue(rows[0]['available'])
        self.assertFalse(rows[1]['available'])

    def test_site_total_and_dynamic_pages(self):
        self.assertEqual(Catalog.expected_total('<div data-total-vehicles="7"></div>'),7)
        self.assertIsNone(Catalog.expected_total('<p>Все автомобили</p>'))
        self.assertTrue(Catalog.has_hidden_paging('<button>Показать ещё</button>'))

    def test_bad_total_keeps_last_snapshot(self):
        self.db.replace_catalog(self.cars(),'verified',2)
        response=MagicMock(); response.text='<div data-total-vehicles="25"></div>'
        with patch('metropol_agent.catalog.httpx.Client') as cls:
            cls.return_value.__enter__.return_value.get.return_value=response
            with self.assertRaises(RuntimeError): Catalog(self.db).sync()
        self.assertEqual(len(self.db.catalog_rows()),8)
        self.assertEqual(Catalog(self.db).status()['coverage'],'verified')

    def test_confirmed_zero_catalog(self):
        response=MagicMock(); response.text='<div data-total-vehicles="0"></div>'
        with patch('metropol_agent.catalog.httpx.Client') as cls:
            cls.return_value.__enter__.return_value.get.return_value=response
            self.assertEqual(Catalog(self.db).sync(),0)
        self.assertIn('0 автомобилей',count_answer(self.db,Catalog(self.db),'Сколько машин?'))
        self.assertEqual(Catalog(self.db).status()['coverage'],'verified')

    def test_page_itemlist_not_proof_of_total(self):
        self.assertIsNone(Catalog.expected_total('<script type="application/ld+json">{"@type":"ItemList","numberOfItems":3}</script>'))

    def test_model_and_year_count_filter(self):
        self.db.replace_catalog([car(i,'Peugeot','3008') for i in range(1,8)],'verified',2)
        self.assertIn('2 автомобилей',count_answer(self.db,Catalog(self.db),'Сколько Peugeot 3008 2021?'))

    def test_test_and_customer_count_same(self):
        self.db.replace_catalog(self.cars(),'verified',2)
        app=self.app()
        client=self.db.upsert_client('123','','','auto')
        q='Сколько машин у вас?'
        self.assertEqual(app._prepare_answer(q,[],0,None,'test')[0],app._prepare_answer(q,[],0,client['id'],'client')[0])

    def test_general_count_does_not_use_preferences(self):
        self.db.replace_catalog(self.cars(),'verified',2)
        app=self.app()
        app.preferences.update(f'test:{app.settings.owner_id}','Покажи Geely Coolray',self.cars())
        self.assertIn('8 автомобилей',app._prepare_answer('Сколько машин?',[],0,None,'test')[0])

    def test_unrelated_no_count_response(self):
        self.assertIsNone(count_answer(self.db,Catalog(self.db),'Сколько часов в сутках?'))

    def test_messages_and_distinct_clients(self):
        client=self.db.upsert_client('123','','','auto')
        self.db.add_message('one',client['id'],'in','message')
        self.db.add_message('two',client['id'],'in','message2')
        self.db.add_message('three',client['id'],'out','reply')
        self.db.record_usage('test',None,'luna',{'cost_usd':1})
        text=self.app().owner_stats.render('clients')
        self.assertIn('Сегодня: клиентов 1, входящих сообщений 2',text)

    def test_owner_stats_all_currencies(self):
        self.db.set_setting('nbrb-rates',json.dumps({'rates':{'GBP':{'scale':1,'rate':'4','date':'2026-09-03'}}}))
        self.assertIn('1 GBP = 4 BYN',self.app().owner_stats.render('allrates'))

    def test_stats_today_filters_midnight_min_sk(self):
        self.db.record_usage('old',None,'luna',{'cost_usd':1})
        self.db.record_usage('today',None,'luna',{'cost_usd':2})
        self.db._execute('UPDATE usage_events SET created_at=%s WHERE event_id=%s',('2026-09-02T20:59:59+00:00','old'))
        self.db._execute('UPDATE usage_events SET created_at=%s WHERE event_id=%s',('2026-09-02T21:00:01+00:00','today'))
        text=self.app().owner_stats.render('costs',datetime(2026,9,2,21,30,tzinfo=timezone.utc))
        self.assertIn('Сегодня: клиенты $0.00000; тесты $2.00000',text)
        self.assertIn('7 дней: клиенты $0.00000; тесты $3.00000',text)

    def test_missing_model_invites_visit_without_random_substitutes(self):
        self.db.replace_catalog([car(1,'Geely','Coolray')])
        app=self.app()
        first=app._prepare_answer('Покажи чанганы',[],0,None,'first')[0]
        self.assertNotIn('/vehicles/geely/',first)
        self.assertIn('не все автомобили успевают попасть на сайт', first.lower())
        self.assertIn('Приезжайте на площадку', first)
        second=app._prepare_answer('покажи другие марки',[{'direction':'out','text':first}],1,None,'second')[0]
        self.assertIn('/vehicles/geely/',second)
