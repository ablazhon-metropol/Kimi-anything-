from __future__ import annotations

import html
import json
import logging
import re
import threading
from datetime import datetime, timedelta, timezone
from typing import Any
from zoneinfo import ZoneInfo

from .ai import AIEngine
from .catalog import Catalog
from .config import Settings
from .db import Database
from .knowledge import deterministic_answer
from .telegram import TelegramAPI, owner_keyboard
from .catalog_selection import select as select_catalog, reply as catalog_reply, direct_catalog_args
from .customer_style import decorate
from .conversation import simple_fact, simple_price, explicit_catalog_request, previous_links, bound_links, smalltalk
from .followups import Followups
from .conversation import handoff_request, leader_request, hours_request, invitation_due, add_invitation
from .staff import Staff
from .preferences import Preferences
from .interactions import Sessions, Handoffs
from .interaction_menu import InteractionMenu
from .answer_checks import clock_answer, map_answer, check_answer
from .finance_policy import with_statistic
from .conversation import full_catalog_request, CATALOG_URL, plain_text
from .exchange import ExchangeRates
from .commerce import Commerce, guard_money
from .inventory import count_answer
from .owner_stats import OwnerStats, menu as stats_menu
from .fallbacks import BUSINESS_FALLBACK, needs_business_fallback, is_fallback
from .memory import ConversationMemory

log = logging.getLogger(__name__)
MINSK = ZoneInfo("Europe/Minsk")
VERSION = "4.0.5"


def is_night() -> bool:
    hour = datetime.now(MINSK).hour
    return hour >= 21 or hour < 8


class AgentApp(InteractionMenu):
    """Telegram orchestration with durable inbound, reply and outbound queues."""

    def __init__(self, settings: Settings, db: Database, telegram: TelegramAPI, ai: AIEngine, catalog: Catalog):
        self.settings = settings
        self.db = db
        self.telegram = telegram
        self.ai = ai
        self.catalog = catalog
        self._test_lock = threading.Lock()
        self.followups = Followups(db)
        self.staff = Staff(db, settings.owner_id)
        self.preferences = Preferences(db)
        self.memory = ConversationMemory(settings, db, ai, self.preferences)
        self.exchange = ExchangeRates(db)
        self.owner_stats = OwnerStats(db,catalog,self.exchange,VERSION)
        self.commerce = Commerce(db,self.preferences,self.exchange)
        self.sessions = Sessions(db)
        self.handoffs = Handoffs(db,self.staff,settings.owner_id)

    def handle_update(self, update: dict[str, Any]) -> None:
        if update.get("callback_query"):
            self._handle_callback(update["callback_query"])
            return
        message = update.get("message") or {}
        chat = message.get("chat") or {}
        sender = message.get("from") or {}
        chat_id = int(chat.get("id") or 0)
        text = str(message.get("text") or "").strip()
        if not chat_id or not text:
            return
        if chat_id == self.settings.owner_id:
            self._handle_owner(update, message, text)
        elif chat_id == int(sender.get('id') or 0) and self.staff.active(chat_id):
            self._handle_staff(chat_id, text, str(update.get('update_id', message.get('message_id'))))
        else:
            self._handle_client(update, message, sender, chat_id, text)

    def _handle_owner(self, update: dict, message: dict, text: str) -> None:
        chat_id = self.settings.owner_id
        event_id = f"tg-{update.get('update_id', message.get('message_id'))}"

        if not text.startswith("/"):
            if self._feedback_text(text):
                return
            if self.db.get_setting('staff-await-id') == '1':
                if text.isdigit():
                    self.db.set_setting('staff-await-id','0')
                    self._staff_candidate(int(text))
                else:
                    self._send(chat_id,'Нужен числовой Telegram ID. /menu — отменить.')
                return
            if self.db.get_setting(f"owner-test-enabled-{chat_id}") == "1":
                self._run_owner_test(text, event_id)
                return
            target = self.db.get_setting(f"owner-reply-target-{chat_id}")
            if target:
                client = self.db.client_by_id(int(target))
                self.db.set_setting(f"owner-reply-target-{chat_id}", "")
                if client and client['mode'] == 'human' and not client.get('do_not_contact'):
                    self.db.enqueue_outbox(client['external_id'], text[:4000],
                        metadata={'direction':'out','client_id':client['id'],'event_id':f'human-{event_id}','model':'human'},
                        dedupe_key=f'human-{event_id}')
                    self._send(chat_id, "Ваш ответ поставлен в очередь выбранному клиенту. Автоответ остаётся выключенным.")
                else:
                    self._send(chat_id, "Диалог уже изменён или клиент запретил сообщения. Ответ не отправлен.")
                return
            draft_id = self.db.consume_owner_edit(chat_id)
            if draft_id is not None:
                self._accept_owner_correction(chat_id, draft_id, text)
                return

        command = text.split()[0].lower()
        response = ""
        markup = None
        if command in {'/start','/menu','/test','/testreset','/testoff','/cancel','/staff','/catalog','/prices','/panel'}:
            self.db.set_setting('feedback-input','')
        if command in {"/start", "/menu"}:
            self.db.set_setting('staff-await-id','0')
            self.db.set_setting(f"owner-reply-target-{chat_id}", "")
            self.db.set_setting(f"owner-test-enabled-{chat_id}", "0")
            response = self._owner_menu()
            markup = self._panel_keyboard()
        elif command == "/test":
            self.db.set_setting('staff-await-id','0')
            self.db.set_setting(f"owner-reply-target-{chat_id}", "")
            self.db.consume_owner_edit(chat_id)
            self.db.set_setting(f"owner-test-enabled-{chat_id}", "1")
            response = "🧪 Тест агента включён. Пишите как клиент — ответ придёт только вам. Цены и каталог настоящие; обращения сотрудникам и обучение отключены. Вызовы ИИ учитываются в расходах.\n/testreset — начать заново\n/testoff — выйти"
        elif command == "/testreset":
            self.preferences.clear(f'test:{chat_id}')
            self.db._execute('DELETE FROM interaction_sessions WHERE scope=%s AND status=%s',(f'test:{chat_id}','open'))
            self.db.set_setting('staff-await-id','0')
            self.db.set_setting(f"owner-reply-target-{chat_id}", "")
            self.db.consume_owner_edit(chat_id)
            self.db.set_setting(f"owner-test-state-{chat_id}", "")
            self.db.set_setting(f"owner-test-enabled-{chat_id}", "1")
            response = "Тестовый разговор очищен. Напишите новый вопрос клиента. /testoff — выйти."
        elif command == "/testoff":
            self.db.set_setting(f"owner-test-enabled-{chat_id}", "0")
            response = "Тест завершён. /menu — меню владельца."
        elif command in {"/prices", "/panel"}:
            self.db.set_setting('staff-await-id','0')
            self.db.set_setting(f"owner-reply-target-{chat_id}", "")
            self.db.set_setting(f"owner-test-enabled-{chat_id}", "0")
            response = "Изменение цен китайских авто и панель управления. Вход — по вашему паролю администратора."
            markup = self._panel_keyboard()
        elif command == '/staff':
            self.db.set_setting(f'owner-test-enabled-{chat_id}','0')
            self.db.set_setting(f'owner-reply-target-{chat_id}','')
            self.db.consume_owner_edit(chat_id)
            self.db.set_setting('staff-await-id','0')
            response = 'Сотрудники. Нажмите имя, чтобы назначить ответственным за НОВЫЕ обращения. Уже переданные диалоги остаются у назначенного сотрудника.'
            markup = self.staff.menu()
        elif command == "/id":
            response = f"Ваш Telegram ID: {chat_id}"
        elif command == "/status":
            response = self._status_text()
        elif command == '/cancel':
            self.db.set_setting('staff-await-id','0')
            self.db.set_setting(f'owner-reply-target-{chat_id}','')
            response='Ввод отменён. /menu — меню.'
        elif command == '/catalog':
            response=self._catalog_diagnostics(text.partition(' ')[2].strip())
        elif command == '/rates':
            response=self.owner_stats.render('rates')
            markup=stats_menu()
        elif command == '/stats':
            response=self.owner_stats.render(text.partition(' ')[2].strip() or 'overview')
            markup=stats_menu()
        elif command == '/preferences':
            response=self.preferences.context(self.preferences.get(f'test:{chat_id}'))
        elif command == '/feedback':
            rows=self.db._execute("SELECT id,body,status FROM interaction_sessions WHERE scope=%s AND status!='open' ORDER BY created_at DESC LIMIT 10",(f'test:{chat_id}',),'all')
            lines=[]
            for row in rows:
                body=json.loads(self.db.cipher.decrypt(row['body']))
                lines.append(f"• {row['status']}: {body.get('query','')[:100]}\nЗамечание: {body.get('note','ещё не введено')[:160]}")
            response='Последние замечания теста:\n'+ ('\n\n'.join(lines) if lines else 'Пока нет замечаний.')
        elif command == "/clients":
            clients = self.db.clients(15)
            lines = [f"{c['id']}. {c['name'] or c['username'] or c['external_id']} — {c['mode']}" for c in clients]
            response = "Последние клиенты:\n" + ("\n".join(lines) or "Пока нет клиентов.")
        elif command == "/queue":
            rows = self.db.pending_notifications(20)
            suffix = "\n" + "\n".join(f"• {r['kind']} · клиент {r['client_id']}" for r in rows) if rows else ""
            response = f"Отложено до утра: {len(rows)}{suffix}"
        elif command == "/costs":
            usage = self.db.monthly_usage()
            response = (
                "Текущий месяц:\n"
                f"Вход: {usage['input_tokens']} токенов\n"
                f"Выход: {usage['output_tokens']} токенов\n"
                f"Учтённый расход: ${float(usage['cost_usd']):.2f}"
            )
        else:
            response = "Команды: /menu /status /clients /queue /costs /id"
        if command in {'/stats','/rates'}:
            # Reports can contain many currencies/brands; never silently cut rows at Telegram's limit.
            chunks=[]; current=''
            for line in response.splitlines():
                if len(current)+len(line)+1>3500:
                    chunks.append(current); current=''
                current+=(('\n' if current else '')+line)
            if current: chunks.append(current)
            for i,chunk in enumerate(chunks):
                self._send(chat_id,chunk,markup if i==len(chunks)-1 else None,dedupe_key=f'owner-command-{event_id}-{i}')
        else:
            self._send(chat_id, response, markup, dedupe_key=f"owner-command-{event_id}")
        self.db.audit(str(chat_id), "owner_command", {"command": command, "event_id": event_id})

    def _run_owner_test(self, text, event_id):
        owner = self.settings.owner_id
        key = f"owner-test-state-{owner}"
        with self._test_lock:
            raw = self.db.get_setting(key)
            state = json.loads(self.db.cipher.decrypt(raw)) if raw else {}
            if event_id in state.get("seen", []):
                return
            input_limit = int(getattr(self.settings, "history_chars", 16000))
            history_limit = int(getattr(self.settings, "history_messages", 30))
            memory_limit = max(history_limit, 80)
            history = state.get("history", []) + [{"direction": "in", "text": text[:input_limit]}]
            counter = int(state.get("counter", 0)) + 1
            answer, model, usage, kind, _ = self._prepare_answer(text[:input_limit], history[-memory_limit:], counter, None, f"owner-test-{event_id}")
            history.append({"direction": "out", "text": answer})
            state = {"history": history[-memory_limit:], "counter": counter, "seen": (state.get("seen", []) + [event_id])[-60:]}
            self.db.set_setting(key, self.db.cipher.encrypt(json.dumps(state, ensure_ascii=False)))
            self.db.record_agent_event(f"owner-test-{event_id}", None, "test", model,
                                       "fallback" if is_fallback(answer) else ("handoff" if kind == "handoff" else "answered"), usage)
            label = f"🧪 ТЕСТ · {model} · расчёт ${float(usage.get('cost_usd', 0)):.5f}\n\n"
            if model in {'approved-price','local-credit','local-price-clarify'}:
                price_state = self.preferences.get(f'test:{owner}').get('commerce',{})
                row=next((r for r in self.db.approved_prices(10000) if r['id']==price_state.get('price_id')),None)
                source=(f"утверждённая запись #{row['id']} · {row['label']}" if row else
                        ('карточка каталога' if price_state.get('catalog_url') else
                         ('сумма клиента' if price_state.get('amount') else 'цена не определена / требуется уточнение')))
                label += f"Источник: {source}.\n\n"
            self._send(owner, label + answer, self._response_markup(f'test:{owner}',text,answer), dedupe_key=f"owner-test-{event_id}")

    def _staff_candidate(self, telegram_id):
        client = self.db._execute('SELECT * FROM clients WHERE channel=%s AND external_id=%s',('telegram',str(telegram_id)),'one')
        if not client or client.get('do_not_contact') or telegram_id == self.settings.owner_id:
            self._send(self.settings.owner_id,'Сотрудник должен сначала написать этому агенту /start и /id. Пришлите полученный ID; владельца добавлять не нужно.')
            return
        # Verify identity through the configured Telegram API before granting access.
        try:
            info = self.telegram.call('getChat', {'chat_id':telegram_id}).get('result',{})
        except Exception:
            self._send(self.settings.owner_id,'Не удалось проверить Telegram ID. Доступ не предоставлен. Попросите сотрудника написать /start и повторите.')
            return
        if info.get('type') != 'private' or int(info.get('id',0)) != telegram_id:
            self._send(self.settings.owner_id,'Это не личный Telegram-аккаунт. Доступ не предоставлен.')
            return
        name = ' '.join(str(info.get(k) or '') for k in ('first_name','last_name')).strip() or str(telegram_id)
        self.db.set_setting(f'staff-candidate-{telegram_id}',json.dumps({'name':name,'username':info.get('username','')},ensure_ascii=False))
        self._send(self.settings.owner_id,f"Подтвердите сотрудника: {name}, @{info.get('username') or 'без username'}, ID {telegram_id}.\nОн получит доступ только к назначенным диалогам.",
            {'inline_keyboard':[[{'text':'Подтвердить сотрудника','callback_data':f'staff:confirm:{telegram_id}'}]]})

    def _handle_staff(self, actor, text, event_id):
        if text.startswith('/'):
            self.db.set_setting(f'owner-reply-target-{actor}','')
            self._send(actor, f'Вы сотрудник «Метрополь». Ваш ID: {actor}. Для ответа используйте кнопку в обращении. /cancel — отмена ввода.')
            return
        target = self.db.get_setting(f'owner-reply-target-{actor}')
        if not target or not self.staff.can_reply(actor,int(target)):
            self._send(actor,'Сначала нажмите «Ответить клиенту» в назначенном вам обращении.')
            return
        client = self.db.client_by_id(int(target))
        self.db.set_setting(f'owner-reply-target-{actor}','')
        if not client or client.get('do_not_contact') or client['mode'] != 'human':
            self._send(actor,'Диалог уже изменён или сообщения запрещены. Ответ не отправлен.')
            return
        self.db.enqueue_outbox(client['external_id'],text[:4000],metadata={'direction':'out','client_id':client['id'],'event_id':f'staff-{actor}-{event_id}','model':'human','staff_actor':actor},dedupe_key=f'staff-{actor}-{event_id}')
        self._send(actor,'Ответ поставлен в очередь клиенту.')

    def _accept_owner_correction(self, owner_id: int, draft_id: int, text: str) -> None:
        draft = self.db.get_draft(draft_id)
        if not draft or draft["status"] not in {"pending", "editing"}:
            self._send(owner_id, "Черновик уже недоступен.")
            return
        client = self.db.client_by_id(int(draft["client_id"]))
        if not client:
            self._send(owner_id, "Клиент для этого черновика не найден.")
            return
        self.db.update_draft(draft_id, "queued_edited", text)
        self.db.add_correction(client["id"], draft["text"], text, str(owner_id))
        self.db.enqueue_outbox(
            client["external_id"], text,
            metadata={"direction": "out", "client_id": client["id"], "event_id": f"owner-edit-{draft_id}", "model": "human-correction"},
            dedupe_key=f"owner-edit-{draft_id}",
        )
        self.db.audit(str(owner_id), "draft_corrected", {"draft_id": draft_id, "client_id": client["id"]})
        self._send(owner_id, "✅ Исправленный ответ поставлен в очередь отправки клиенту и сохранён как обучающий пример.")

    def _handle_client(self, update: dict, message: dict, sender: dict, chat_id: int, text: str) -> None:
        name = " ".join(x for x in (sender.get("first_name"), sender.get("last_name")) if x)
        client = self.db.upsert_client(str(chat_id), name, str(sender.get("username") or ""), self.settings.global_mode)
        event_id = f"tg-{update.get('update_id', message.get('message_id'))}"
        normalized = text.lower().replace("ё", "е")

        if any(phrase in normalized for phrase in ("удалите мои данные", "удалить мои данные", "забудьте меня")):
            self.db.forget_client(client["id"])
            self._send(
                chat_id,
                "Ваши сохранённые данные и история переписки удалены. Агент больше не будет инициировать общение.",
                dedupe_key=f"privacy-delete-{event_id}",
            )
            self.db.audit("client", "client_forgotten", {"client_id": client["id"]})
            return
        if any(phrase in normalized for phrase in ("не пишите мне", "не звоните мне", "не связывайтесь со мной")):
            self.db.set_do_not_contact(client["id"], True)
            self._send(
                chat_id,
                "Понял. Больше не будем инициировать сообщения или звонки.",
                dedupe_key=f"privacy-optout-{event_id}",
            )
            return
        if client.get("do_not_contact") and not text.startswith("/start"):
            return
        if client.get("do_not_contact") and text.startswith("/start"):
            self.db.set_do_not_contact(client["id"], False)

        if normalized == "/id":
            self.db.add_message(event_id, client["id"], "in", text)
            self._send(chat_id, f"Ваш Telegram ID: {chat_id}", dedupe_key=f"client-command-{event_id}")
            return
        if text.startswith("/start"):
            self.db.add_message(event_id, client["id"], "in", text)
            self._send(
                chat_id,
                "Здравствуйте! Я агент по продажам «Метрополь Авто». Помогу ответить на вопросы, "
                "показать актуальный автомобиль на нашем сайте или передать запрос сотруднику. Что вас интересует?",
                dedupe_key=f"client-command-{event_id}",
            )
            return
        self.db.enqueue_client_message(event_id, client["id"], text, self.settings.debounce_seconds)

    def process_due_jobs(self) -> int:
        processed = 0
        for job in self.db.claim_reply_jobs(1):
            job_id = int(job["id"])
            try:
                messages = self.db.reply_job_messages(job_id)
                if not messages:
                    self.db.complete_reply_job(job_id)
                    continue
                client = self.db.client_by_id(int(job["client_id"]))
                if not client:
                    self.db.complete_reply_job(job_id)
                    continue

                query = "\n".join(item["text"] for item in messages if item.get("text")).strip()
                if client["mode"] == "human":
                    self._notify_or_queue(client, "human_message", {"text": query, "job_id": job_id}, 40)
                    self.db.complete_reply_job(job_id)
                    processed += 1
                    continue

                if handoff_request(query) and not hasattr(self.ai, 'generate_agent'):
                    self.db.set_mode(client['id'], 'human')
                    self.handoffs.ensure(client['id'])
                    self.followups.consider({**client, 'mode':'human'}, query, int(messages[-1]['id']))
                    self._notify_or_queue(client, 'handoff', {'text':query, 'job_id':job_id}, 10)
                    notice = ("Запрос сотруднику сохранён. Сейчас ночь — передадим утром." if is_night()
                              else "Запрос сотруднику сохранён и поставлен в очередь уведомлений. Он сможет подключиться к переписке.")
                    self.db.enqueue_outbox(client['external_id'], notice,
                        metadata={'direction':'out','client_id':client['id'],'event_id':f'handoff-{job_id}','model':'handoff'},
                        dedupe_key=f'handoff-{job_id}')
                    self.db.complete_reply_job(job_id)
                    processed += 1
                    continue

                history = self.db.recent_messages(client["id"], max(80, int(getattr(self.settings, "history_messages", 30))))
                answer, model, usage, kind, priority = self._prepare_answer(
                    query, history, job_id, client["id"],
                    f"ai-job-{job_id}-attempt-{int(job.get('attempts') or 1)}")
                self.db.record_agent_event(
                    f"ai-job-{job_id}", client["id"], client.get("channel", "telegram"), model,
                    "fallback" if is_fallback(answer) else ("handoff" if kind == "handoff" else "answered"), usage,
                )

                source_message_id = int(messages[-1]["id"])
                client = self.db.client_by_id(client['id'])
                if not client or client.get('do_not_contact'):
                    self.db.complete_reply_job(job_id)
                    continue
                if client['mode'] == 'human' and kind != 'handoff':
                    self.db.complete_reply_job(job_id)
                    continue
                self.followups.consider(client, query, source_message_id)
                if client["mode"] == "auto" or kind == 'handoff':
                    self.db.enqueue_outbox(
                        client["external_id"], answer,
                        reply_markup=self._response_markup(f"client:{client['id']}",query,answer),
                        delay_seconds=self._human_delay_seconds(answer),
                        metadata={"direction": "out", "client_id": client["id"], "event_id": f"reply-job-{job_id}", "model": 'handoff' if kind == 'handoff' else model},
                        dedupe_key=f"reply-job-{job_id}",
                    )
                else:
                    draft_id = self.db.create_draft(client["id"], answer, source_message_id)
                    self._notify_or_queue(client, kind, {"text": query, "answer": answer, "draft_id": draft_id}, priority)
                self.db.complete_reply_job(job_id)
                processed += 1
            except Exception as exc:
                status = self.db.retry_reply_job(job_id, f"{type(exc).__name__}: {exc}", self.settings.max_job_attempts)
                log.exception("reply job failed id=%s status=%s", job_id, status)
        return processed

    def _prepare_answer(self, query, history, job_id, client_id, usage_event_id):
        if hasattr(self.ai, 'generate_agent'):
            return self._prepare_agent_answer(query, history, job_id, client_id, usage_event_id)
        if handoff_request(query):
            target = 'руководителю' if leader_request(query) else 'менеджеру'
            return f"Распознана передача {target}. В рабочем чате создаётся обращение и приостанавливаются автоответы; в тесте никого не уведомляем.", "local-handoff-preview", {}, "handoff", 10
        if hours_request(query, history):
            return 'Обе площадки Метрополь Авто работают ежедневно с 9:00 до 20:00. Приезжайте, будем рады!', 'local-hours', {}, 'schedule', 50
        dated=clock_answer(query)
        if dated:
            return dated, 'local-clock', {}, 'reply', 50
        mapped=map_answer(query,history)
        if mapped:
            return mapped, 'local-map', {}, 'reply', 50
        scope=f'client:{client_id}' if client_id is not None else f'test:{self.settings.owner_id}'
        previous_out=next((m.get('text','') for m in reversed(history) if m.get('direction')=='out'),'')
        consent=query.lower().strip(' .!?') in {'да','давай','давайте','покажи','покажите','да покажи'}
        if consent and 'Хотите посмотреть другие марки?' in previous_out:
            self.preferences.clear(scope)
            query='Покажите автомобили других марок'
        elif re.search(r'^(?:покажи(?:те)? |давай(?:те)? |хочу )?другие марки[.!?]*$',query.lower().strip()):
            self.preferences.clear(scope)
            query='Покажите автомобили других марок'
        if full_catalog_request(query):
            return f'Вот полный каталог Метрополь Авто: {CATALOG_URL} 🚗', 'local-full-catalog', {}, 'reply', 50
        inventory=count_answer(self.db,self.catalog,query)
        if inventory:
            return inventory,'local-inventory',{},'reply',50
        commercial=self.commerce.route(scope,query,history)
        if commercial:
            answer,model,_=commercial
            return answer,model,{},'reply',50
        local = deterministic_answer(query)
        effective, preferences, selection = self.preferences.pick(scope,query,self.db.catalog_rows(),history)
        if local and local.intent in {"complaint", "contacts", "callback", "schedule"}:
            selection = None
        approved = self.db.matching_approved_prices(query)
        availability = bool(re.search(r'налич|есть|ищу|интересует', query.lower())) and not any(w in query.lower() for w in ('почему','сравн','лучше','дороже'))
        catalog_topic = bool(selection and (selection[2] or re.search(r'авто|машин|каталог|модел',query.lower()) or (preferences.get('model') and re.search(r'вариант|дешевле|поновее|такую|такой',query.lower()))))
        direct_catalog = bool(catalog_topic and (explicit_catalog_request(query) or simple_price(query) or (availability and selection[2]) or re.search(r'дешевле|поновее|другие варианты',query.lower())))
        if selection and selection[2] and re.search(r'нужен|нужна|интересует',query,re.I) and not re.search(r'кредит|лизинг|сравн|почему',query,re.I):
            direct_catalog=True
        if approved and simple_price(query):
            answer = approved[0].removeprefix("УТВЕРЖДЁННАЯ ЦЕНА: ")
            model, usage, kind, priority = "approved-price", {}, "reply", 50
        elif local and simple_fact(query):
            answer, model, usage, kind, priority = local.text, "local", {}, local.intent, local.priority
        elif direct_catalog:
            answer, model, usage, kind, priority = "", "local-catalog", {}, "reply", 50
        else:
            extra_knowledge = list(approved)
            if preferences:
                extra_knowledge.append(self.preferences.context(preferences))
            if invitation_due(query, history):
                extra_knowledge.insert(0, 'Сейчас после ответа уместно один раз мягко пригласить в Метрополь Авто, связав с темой. Если обсуждался алкоголь — только в другой день. Не поучай, не затягивай разговор лишним вопросом.')
            if local:
                extra_knowledge.append("СПРАВКА, не шаблон ответа: " + local.text)
            if selection is not None and not smalltalk(query):
                status, rows, _ = selection
                extra_knowledge.append("КАТАЛОГ: " + ("точное совпадение" if status == "exact" else "ТОЧНОЕ СОВПАДЕНИЕ НЕ НАЙДЕНО; это другие варианты, не искомая модель") +
                    ". Не делай вывод об отсутствии на площадке. Не вставляй подборку без надобности.\n" +
                    "\n".join(r['title'] + ' — ' + r['url'] for r in rows))
            if not smalltalk(query):
                extra_knowledge.extend(self.db.search_knowledge(effective)[:1])
            result = self.ai.generate(
                query, history, float(self.db.monthly_usage()["cost_usd"]),
                extra_knowledge=extra_knowledge,
                corrections=self.db.approved_corrections(query),
            )
            answer, model, usage, kind, priority = result.text, result.model, result.usage, "reply", 50
            self.db.record_usage(
                usage_event_id,
                client_id, model, usage,
            )

        if direct_catalog and model == "local-catalog":
            status, rows, specific = selection
            self.preferences.shown(scope,preferences,rows)
            price_question = bool(re.search(r'сколько\s+стоит|поч[её]м|по\s+ч[её]м|цен[ауы]|стоимост', query, re.I))
            location_question = bool(re.search(r'где|площадк|адрес|находится', query, re.I))
            answer = catalog_reply((status, rows, specific), show_price=price_question,
                                   show_location=location_question,
                                   current=not bool(self.db.get_setting('catalog_last_error')))
            if self.db.get_setting('catalog_last_error'):
                answer = 'Каталог сейчас не удалось обновить; ниже — данные последней сохранённой версии.\n\n' + answer
        allowed_links = {r['url'] for r in selection[1]} if selection else set()
        if direct_catalog:
            allowed_links.add('https://metropol-auto.by/vehicles/')
        else:
            allowed_links -= previous_links(history)
        answer = check_answer(answer, allowed_links, exact=bool(selection and selection[0]=='exact' and selection[1] and not self.db.get_setting('catalog_last_error')))
        if model not in {'approved-price','local-catalog'}:
            answer = guard_money(answer,' '.join(filter(None,[preferences.get('brand'),preferences.get('model')])))
        if model not in {'approved-price','local-budget-limit','local-fallback'}:
            answer = with_statistic(answer, query, history)
        if not direct_catalog and model != 'approved-price':
            answer = add_invitation(answer, query, history, job_id)
        answer = decorate(answer, query, history, job_id)
        return plain_text(answer), model, usage, kind, priority

    def _prepare_agent_answer(self, query, history, job_id, client_id, usage_event_id):
        from .agent_tools import AgentTools
        scope = f'client:{client_id}' if client_id is not None else f'test:{self.settings.owner_id}'
        def handoff(target):
            if client_id is None:
                return 'Тест: распознана просьба позвать ' + ('руководителя' if target == 'leader' else 'менеджера') + '. В рабочем чате создаётся обращение; в тесте сотрудникам ничего не отправляется.'
            client = self.db.client_by_id(client_id)
            if not client or client.get('do_not_contact'):
                return 'Обращение не создано: отправка сообщений этому клиенту отключена.'
            if target == 'leader':
                self.staff.assign(client_id, self.settings.owner_id)
            self.handoffs.ensure(client_id)
            self._notify_or_queue(client, 'handoff', {'text': query, 'job_id': job_id}, 10)
            self.db.set_mode(client_id, 'human')
            return ('Запрос сотруднику сохранён. Сейчас ночь — передадим утром.' if is_night()
                    else 'Запрос сотруднику сохранён и поставлен в очередь уведомлений. Он сможет подключиться к переписке.')

        # Obvious catalogue turns are deterministic.  A bare brand/model,
        # "покажи их", "все" and the "Другие варианты" button must never be
        # reinterpreted as leasing or sent to public web search.
        catalogue_args = direct_catalog_args(
            self.db.catalog_rows(), query, self.preferences.get(scope),
        )
        if catalogue_args is not None:
            capabilities = AgentTools(self, scope, query, history, handoff, usage_event_id)
            result = capabilities.dispatch('catalog', json.dumps(catalogue_args, ensure_ascii=False))
            if result.get('fact_token'):
                answer = capabilities.render(result['fact_token'])
                from .dialogue_policy import apply as apply_dialogue
                answer = apply_dialogue(
                    self.preferences, scope, query, answer, 'business', '',
                    f'reply:{job_id}' if client_id is not None else usage_event_id,
                    history, business_tools=True,
                )
                self.db.audit('agent', 'direct_catalog_turn', {
                    'scope': scope, 'event': usage_event_id, 'arguments': catalogue_args,
                })
                return plain_text(answer), 'local-catalog', {
                    'input_tokens': 0, 'output_tokens': 0, 'cost_usd': 0.0,
                }, 'reply', 50

        capabilities = AgentTools(self, scope, query, history, handoff, usage_event_id)
        result = self.ai.generate_agent(query, history, float(self.db.monthly_usage()['cost_usd']),
            capabilities, lambda index, model, usage: self.db.record_usage(
                f'{usage_event_id}-round-{index}', client_id, model, usage),
            corrections=self.db.approved_corrections(query))
        self.db.audit('agent', 'tool_trace', {'scope': scope, 'tools': capabilities.trace,
                                           'model': result.model, 'event': usage_event_id})
        answer = result.text
        if not capabilities.handoff_text and not result.model.startswith(('ai-unavailable', 'ai-budget')) and ':api-error' not in result.model:
            from .dialogue_policy import apply as apply_dialogue
            answer = apply_dialogue(self.preferences, scope, query, answer, capabilities.topic, capabilities.invitation,
                f'reply:{job_id}' if client_id is not None else usage_event_id, history,
                business_tools=any(t not in {'internet_search'} for t in capabilities.trace))
            if client_id is not None and capabilities.invitation and capabilities.invitation in answer:
                self.db.record_funnel(usage_event_id + ':invitation', client_id, 'invitation')
        if capabilities.business_topic and needs_business_fallback(answer):
            answer = BUSINESS_FALLBACK
        answer = answer if capabilities.handoff_text else decorate(answer, query, history, job_id)
        return plain_text(answer), result.model, result.usage, ('handoff' if capabilities.handoff_text else 'reply'), (10 if capabilities.handoff_text else 50)

    @staticmethod
    def _human_delay_seconds(answer: str) -> float:
        return 0.0

    def process_outbox(self) -> int:
        sent = 0
        for item in self.db.claim_outbox(1):
            outbox_id = int(item["id"])
            try:
                if not self.followups.before_delivery(item):
                    continue
                meta = item.get('metadata') or {}
                if meta.get('handoff_escalation'):
                    receipt=self.db._execute('SELECT * FROM handoff_receipts WHERE client_id=%s',(meta['handoff_escalation'],),'one')
                    client=self.db.client_by_id(meta['handoff_escalation'])
                    if not receipt or receipt['request_id']!=meta.get('handoff_request') or receipt['status']!='escalated' or not client or client['mode']!='human' or client.get('do_not_contact'):
                        self.db._execute("UPDATE outbox SET status='cancelled' WHERE id=%s",(outbox_id,)); continue
                if meta.get('notice_client') or meta.get('handoff_escalation'):
                    if is_night():
                        current = datetime.now(MINSK)
                        next_day = current + timedelta(days=1) if current.hour >= 21 else current
                        next_time = next_day.replace(hour=8,minute=0,second=0,microsecond=0).astimezone(timezone.utc).isoformat()
                        self.db._execute("UPDATE outbox SET status='pending',send_after=%s WHERE id=%s",(next_time,outbox_id))
                        continue
                    if meta.get('notice_client'):
                        current=self.db.client_by_id(int(meta['notice_client']))
                        if not current or current['mode']!='human' or current.get('do_not_contact'):
                            self.db._execute("UPDATE outbox SET status='cancelled' WHERE id=%s",(outbox_id,)); continue
                        target = self.staff.responsible(int(meta['notice_client']))
                        item['chat_id'] = str(target)
                        self.db._execute('UPDATE outbox SET chat_id=%s WHERE id=%s',(str(target),outbox_id))
                if meta.get('staff_actor') and not self.staff.can_reply(int(meta['staff_actor']),int(meta['client_id'])):
                    self.db._execute("UPDATE outbox SET status='cancelled',last_error='Staff access revoked' WHERE id=%s",(outbox_id,))
                    continue
                if meta.get('direction') == 'out' and meta.get('client_id'):
                    current = self.db.client_by_id(int(meta['client_id']))
                    if not current or current.get('do_not_contact') or (current['mode'] == 'human' and meta.get('model') not in {'human','human-correction','handoff'}):
                        self.db._execute("UPDATE outbox SET status='cancelled',last_error='Client mode changed' WHERE id=%s", (outbox_id,))
                        continue
                self.telegram.send_message(item["chat_id"], item["text"], item.get("reply_markup") or None)
                if meta.get('notice_client') and meta.get('handoff_request'):
                    self.handoffs.delivered(int(meta['notice_client']),meta['handoff_request'])
                metadata = item.get("metadata") or {}
                if metadata.get("direction") == "out" and metadata.get("client_id"):
                    self.db.add_message(
                        str(metadata.get("event_id") or f"outbox-{outbox_id}"), int(metadata["client_id"]),
                        "out", item["text"], str(metadata.get("model") or ""), metadata.get("usage") or {},
                    )
                self.db.mark_outbox_sent(outbox_id)
                sent += 1
            except Exception as exc:
                meta = item.get('metadata') or {}
                if meta.get('notice_client') and str(item['chat_id']) != str(self.settings.owner_id) and int(item.get('attempts') or 0) >= 2:
                    self.staff.assign(int(meta['notice_client']),self.settings.owner_id)
                    self.db.audit('system','handoff_fallback_owner',{'client_id':meta['notice_client']})
                status = self.db.retry_outbox(outbox_id, f"{type(exc).__name__}: {exc}")
                log.warning("outbox delivery failed id=%s status=%s: %s", outbox_id, status, exc)
        return sent

    def _send(
        self, chat_id: int | str, text: str, markup: dict | None = None, dedupe_key: str = ""
    ) -> int:
        return self.db.enqueue_outbox(chat_id, text, markup, dedupe_key=dedupe_key)

    def _notify_or_queue(self, client: dict, kind: str, payload: dict, priority: int) -> None:
        receipt=None
        if kind in {'handoff','human_message'}:
            if leader_request(payload.get('text','')):
                self.staff.assign(client['id'],self.settings.owner_id)
            receipt=self.handoffs.ensure(client['id'])
        if is_night() or not self.settings.owner_id:
            dedupe = f"night-draft-{payload['draft_id']}" if payload.get("draft_id") else (
                f"night-job-{payload['job_id']}" if payload.get("job_id") else ""
            )
            self.db.queue_notification(client["id"], kind, payload, priority, dedupe)
            return
        draft_id = payload.get("draft_id")
        title = client["name"] or ("@" + client["username"] if client["username"] else client["external_id"])
        body = f"Новое обращение: {title} · №{client['id']}\nКлиент: {payload.get('text', '')}"
        markup = None
        if kind in {'handoff', 'human_message'}:
            body = '👤 Нужен сотрудник\n' + body
            markup = {'inline_keyboard': [[{'text':'Взял в работу','callback_data':f"take:{client['id']}:{receipt['request_id']}"}],[{'text':'Ответить клиенту','callback_data':f"humanreply:{client['id']}:0"}],
                [{'text':'Вернуть автоответ','callback_data':f"resume:{client['id']}:0"}]]}
        if draft_id:
            body += f"\n\nПредлагаемый ответ:\n{payload.get('answer', '')}"
            markup = owner_keyboard(client["id"], draft_id, getattr(self.settings, "public_base_url", ""))
        notice = kind in {'handoff','human_message'}
        if notice and (leader_request(payload.get('text','')) or any(word in payload.get('text','').lower() for word in ('жалоб','претенз','обман'))):
            self.staff.assign(client['id'], self.settings.owner_id)
        target = self.staff.responsible(client['id']) if notice else self.settings.owner_id
        self.db.enqueue_outbox(
            target, body[:3900], markup,
            metadata={'notice_client':client['id'],'handoff_request':receipt['request_id']} if notice else {},
            dedupe_key=(
                f"owner-draft-{draft_id}" if draft_id else
                (f"owner-job-{payload['job_id']}" if payload.get("job_id") else "")
            ),
        )

    def _handle_callback(self, callback: dict) -> None:
        callback_id = str(callback.get("id") or "")
        sender_id = int((callback.get("from") or {}).get("id") or 0)
        data = str(callback.get('data') or '')
        if data.startswith('owner:stats:'):
            if sender_id!=self.settings.owner_id:
                self.telegram.answer_callback(callback_id,'Недостаточно прав')
                return
            self.telegram.answer_callback(callback_id,'Статистика')
            self._handle_owner({'update_id':f'callback-{callback_id}'},{},'/stats '+data.rsplit(':',1)[-1])
            return
        if data.startswith('x:'):
            self._interaction_callback(callback)
            return
        if data=='owner:catalog' and sender_id==self.settings.owner_id:
            self.telegram.answer_callback(callback_id,'Диагностика каталога')
            self._handle_owner({'update_id':f'callback-{callback_id}'},{},'/catalog')
            return
        employee = sender_id != self.settings.owner_id
        if employee and (not self.staff.active(sender_id) or data.split(':')[0] not in {'humanreply','resume','take'}):
            self.telegram.answer_callback(callback_id, "Недостаточно прав")
            return
        if data.startswith('take:'):
            try:
                _,cid,request=data.split(':',2)
                cid=int(cid)
            except ValueError:
                self.telegram.answer_callback(callback_id,'Некорректная кнопка'); return
            client=self.db.client_by_id(cid)
            ok=bool(client and client['mode']=='human' and not client.get('do_not_contact') and self.handoffs.accept(cid,sender_id,request))
            self.telegram.answer_callback(callback_id,'Обращение принято' if ok else 'Обращение недоступно')
            return
        if data.startswith('staff:'):
            self._staff_callback(callback_id, data)
            return
        if data == 'owner:staff':
            self.telegram.answer_callback(callback_id,'Сотрудники')
            self._handle_owner({'update_id':f'callback-{callback_id}'},{},'/staff')
            return
        if callback.get("data") == "owner:test":
            self.telegram.answer_callback(callback_id, "Режим теста")
            self._handle_owner({"update_id": f"callback-{callback_id}"}, {}, "/test")
            return
        try:
            action, client_id_s, draft_id_s = str(callback.get("data") or "").split(":", 2)
            client_id, draft_id = int(client_id_s), int(draft_id_s)
        except ValueError:
            self.telegram.answer_callback(callback_id, "Некорректная команда")
            return

        draft = self.db.get_draft(draft_id)
        client = self.db.client_by_id(client_id)
        if action in {'humanreply', 'resume'}:
            if not client or client.get('do_not_contact') or not self.staff.can_reply(sender_id,client_id):
                self.telegram.answer_callback(callback_id, 'Клиент недоступен')
                return
            if action == 'humanreply':
                self.handoffs.accept(client_id,sender_id)
                self.db.set_mode(client_id, 'human')
                self.db.set_setting(f'owner-test-enabled-{sender_id}', '0')
                self.db.consume_owner_edit(sender_id)
                self.db.set_setting(f'owner-reply-target-{sender_id}', str(client_id))
                self._send(sender_id, f"Следующее текстовое сообщение уйдёт клиенту №{client_id}: {client['name'] or client['external_id']}. /menu — отменить.")
            else:
                self.handoffs.close(client_id)
                self.db.set_mode(client_id, 'auto')
                self.db.set_setting(f'owner-reply-target-{sender_id}', '')
            self.telegram.answer_callback(callback_id, 'Жду ваш ответ' if action == 'humanreply' else 'Автоответ включён')
            return
        if not draft or not client or int(draft["client_id"]) != client_id:
            self.telegram.answer_callback(callback_id, "Черновик не найден")
            return
        if client['mode'] == 'human' and action in {'send', 'edit'}:
            self.telegram.answer_callback(callback_id, 'Диалог передан человеку. Используйте «Ответить клиенту».')
            return
        if draft["status"] not in {"pending", "editing"} and action in {"send", "edit", "drop", "human"}:
            self.telegram.answer_callback(callback_id, "Уже обработано")
            return

        if action == "send":
            self.db.update_draft(draft_id, "queued")
            self.db.enqueue_outbox(
                client["external_id"], draft["text"],
                metadata={"direction": "out", "client_id": client_id, "event_id": f"approved-{draft_id}", "model": "approved"},
                dedupe_key=f"approved-draft-{draft_id}",
            )
            note = "Поставлено в очередь отправки"
            self.db.audit(str(sender_id), "draft_queued", {"draft_id": draft_id, "client_id": client_id})
        elif action == "edit" and getattr(self.settings, "public_base_url", ""):
            self._send(self.settings.owner_id, "Откройте ответ: текст уже заполнен в редакторе.",
                       {"inline_keyboard": [[{"text": "Исправить ответ", "url": f"{self.settings.public_base_url}/admin/drafts/{draft_id}"}]]})
            note = "Редактор отправлен"
        elif action == "edit":
            self.db.start_owner_edit(self.settings.owner_id, draft_id)
            self.db.update_draft(draft_id, "editing")
            self._send(self.settings.owner_id, "Скопируйте и исправьте текст ниже, затем отправьте его одним сообщением:\n\n" + draft["text"])
            note = "Жду исправленный текст"
        elif action == "drop":
            self.db.update_draft(draft_id, "dropped")
            note = "Не отправляем"
            self.db.audit(str(sender_id), "draft_dropped", {"draft_id": draft_id, "client_id": client_id})
        elif action == "human":
            self.db.set_mode(client_id, "human")
            self.db.update_draft(draft_id, "transferred")
            self._notify_or_queue(client,'handoff',{'text':'Владелец передал диалог сотруднику','job_id':f'draft-{draft_id}'},10)
            note = "Агент остановлен для клиента"
            self.db.audit(str(sender_id), "client_human_mode", {"client_id": client_id})
        elif action == "auto":
            self.db.set_mode(client_id, "auto")
            self.handoffs.close(client_id)
            note = "Автоответ включён"
            self.db.audit(str(sender_id), "client_auto_mode", {"client_id": client_id})
        else:
            note = "Неизвестная команда"
        self.telegram.answer_callback(callback_id, note)

    def _staff_callback(self, callback_id, data):
        try:
            _, action, value = data.split(':')
            target = int(value)
        except ValueError:
            self.telegram.answer_callback(callback_id,'Некорректная команда')
            return
        owner = self.settings.owner_id
        if action == 'add':
            self.db.set_setting(f'owner-test-enabled-{owner}','0')
            self.db.set_setting(f'owner-reply-target-{owner}','')
            self.db.consume_owner_edit(owner)
            self.db.set_setting('staff-await-id','1')
            self._send(owner,'Попросите сотрудника написать агенту /start, затем /id. Пришлите сюда его числовой Telegram ID. /menu — отменить.')
        elif action == 'confirm':
            raw = self.db.get_setting(f'staff-candidate-{target}')
            if raw:
                self.staff.register(target,json.loads(raw)['name'])
                self.db.set_setting(f'staff-candidate-{target}','')
                self._send(owner,'Сотрудник добавлен. Нажмите его имя, чтобы назначить ответственным за новые обращения.',self.staff.menu())
        elif action == 'primary' and (target == owner or self.staff.active(target)):
            self.db.set_setting('primary_staff',str(target))
            self._send(owner,'Ответственный за новые обращения назначен.',self.staff.menu())
        elif action == 'remove':
            if self.staff.active(target):
                self._send(owner,f'Отключить сотрудника ID {target}? Его диалоги вернутся владельцу.',{'inline_keyboard':[[{'text':'Подтвердить отключение','callback_data':f'staff:disable:{target}'}]]})
        elif action == 'disable':
            self.staff.remove(target)
            self._send(owner,'Доступ отключён. Назначенные диалоги теперь у владельца.',self.staff.menu())
        self.db.audit(str(owner),'staff_action',{'action':action,'telegram_id':target})
        self.telegram.answer_callback(callback_id,'Готово')

    def flush_morning_queue(self) -> int:
        if is_night() or not self.settings.owner_id:
            return 0
        sent = 0
        for row in self.db.pending_notifications(100):
            client = self.db.client_by_id(int(row["client_id"]))
            if not client:
                self.db.mark_notification_sent(int(row["id"]))
                continue
            payload = json.loads(row["payload"])
            self._notify_or_queue(client, row["kind"], payload, int(row["priority"]))
            self.db.mark_notification_sent(int(row["id"]))
            sent += 1
        return sent

    def send_daily_monitoring_report(self, current: datetime | None = None) -> int:
        """Send one owner-only channel/fallback summary after 20:30 Minsk."""
        if not self.settings.owner_id:
            return 0
        current = (current or datetime.now(MINSK)).astimezone(MINSK)
        if (current.hour, current.minute) < (20, 30):
            return 0
        day = current.date().isoformat()
        if self.db.get_setting("monitoring-daily-day") == day:
            return 0
        self.db.enqueue_outbox(
            self.settings.owner_id,
            "Ежедневный отчёт\n\n" + self.owner_stats.monitoring(current),
            dedupe_key=f"daily-monitoring-{day}",
        )
        self.db.set_setting("monitoring-daily-day", day)
        return 1

    def _status_text(self) -> str:
        stats = self.db.stats()
        catalog = self.catalog.status()
        models = self.ai.status()
        knowledge_search = models.get('knowledge_search') or {}
        memory = self.memory.status()
        return (
            f"Агент Метрополь v{VERSION}\nКлиентов: {stats['clients']}\nСообщений: {stats['messages']}\n"
            f"Заданий ответа: {stats['reply_jobs']}\nОчередь отправки: {stats['outbox']}\n"
            f"Ночная очередь: {stats['pending']}\nАвто в каталоге: {catalog['count']}\n"
            f"Модели OpenAI: {models['state']}\n"
            f"Качество: {models.get('quality_mode', 'balanced')} · рассуждение {models.get('reasoning_effort', 'low')}\n"
            f"Веб-модель: {models.get('web', 'не задана')} · контекст {getattr(self.settings, 'web_search_context_size', 'low')}\n"
            f"Поиск знаний: {knowledge_search.get('state', 'обычный')} · векторов {knowledge_search.get('vectors', 0)}\n"
            f"Память: {memory.get('state', 'disabled')} · сводок {memory.get('summaries', 0)} · векторов сообщений {memory.get('message_vectors', 0)}\n"
            f"Ответы за 24 часа: {stats['responses_24h']} · затруднения {stats['fallbacks_24h']}\n"
            f"Веб-поиск: {self.db.get_setting('web_search_status', 'ещё не проверен')}\nРасход месяца: ${float(stats['usage']['cost_usd']):.2f}\n\n" + self.exchange.diagnostics()
        )

    def _panel_keyboard(self):
        base = getattr(self.settings, "public_base_url", "")
        if not base:
            return {"inline_keyboard": [[{"text": "🧪 Тест агента", "callback_data": "owner:test"}], [{'text':'👥 Сотрудники','callback_data':'owner:staff'}], [{'text':'📊 Статистика','callback_data':'owner:stats:overview'}], [{'text':'Каталог: диагностика','callback_data':'owner:catalog'}]]}
        return {"inline_keyboard": [
            [{"text": "🚘 Изменить цены китайских авто", "url": base + "/admin/prices"}],
            [{"text": "⚙️ Панель управления", "url": base + "/admin"}],
            [{"text": "🧪 Тест агента", "callback_data": "owner:test"}], [{'text':'👥 Сотрудники','callback_data':'owner:staff'}], [{'text':'📊 Статистика','callback_data':'owner:stats:overview'}], [{'text':'Каталог: диагностика','callback_data':'owner:catalog'}]]}

    @staticmethod
    def _owner_menu() -> str:
        return (
            f"Агент Метрополь v{VERSION}\n\n/status — состояние\n/clients — клиенты\n"
            "/queue — ночная очередь\n/costs — токены и расходы\n/stats — статистика, наличие и курсы\n/stats monitoring — контроль ответов\n/id — ваш Telegram ID\n\n"
            "/prices — изменить цены китайских авто\n/panel — панель управления\n/test — тест агента\n/testoff — завершить тест\n/staff — сотрудники\n/catalog — диагностика каталога\n/rates — курсы НБРБ\n/preferences — пожелания в тесте\n/feedback — замечания теста"
        )


def panel_html(
    stats: dict, clients: list[dict], catalog: dict, models: dict,
    knowledge: list[dict], prices: list[dict],
) -> str:
    memory = models.get('memory') or {}
    rows = "".join(
        f"<tr><td>{html.escape(str(c['name'] or c['username'] or c['external_id']))}</td><td>{html.escape(c.get('channel') or 'unknown')}</td><td>{html.escape(c['mode'])}</td><td>{html.escape(c['status'])}</td></tr>"
        for c in clients
    )
    knowledge_rows = "".join(
        f"<tr><td>{int(item['id'])}</td><td>{html.escape(item['title'])}</td><td>{html.escape(item['body'][:180])}</td><td>{int(item['version'])}</td></tr>"
        for item in knowledge
    )
    price_rows = "".join(
        f"<tr><td>{int(item['id'])}</td><td>{html.escape(item['label'])}</td>"
        f"<td>{html.escape(item['matcher'])}</td><td>{html.escape(item['price_text'])}</td></tr>"
        for item in prices
    )
    return f"""<!doctype html><html lang='ru'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>Агент Метрополь</title><style>
body{{font-family:system-ui;background:#071a2d;color:#fff;margin:0;padding:20px;max-width:1100px;margin:auto}}
.card{{background:#102b47;border:1px solid #b99a52;border-radius:18px;padding:18px;margin:12px 0}}
h1,h2{{color:#e3c274}}table{{width:100%;border-collapse:collapse}}td,th{{padding:10px;border-bottom:1px solid #29445f;text-align:left}}
.n{{font-size:28px;color:#e3c274}}input,textarea{{box-sizing:border-box;width:100%;padding:12px;margin:6px 0 12px;border-radius:10px;border:1px solid #678;background:#eef;color:#071a2d}}
button{{background:#e3c274;color:#071a2d;border:0;border-radius:10px;padding:12px 18px;font-weight:700}}small{{color:#b9c8d8}}
table{{display:block;overflow-x:auto;max-width:100%}}.card{{min-width:0}}
</style><h1>Агент Метрополь v{VERSION}</h1>
<div class='card'><span class='n'>{stats['clients']}</span> клиентов · <span class='n'>{stats['messages']}</span> сообщений · задания {stats['reply_jobs']} · отправка {stats['outbox']}</div>
<div class='card'><h2>Контроль за 24 часа</h2><p>Ответов: {stats['responses_24h']} · затруднений: {stats['fallbacks_24h']}</p><small>Подробно по каналам: /stats monitoring</small></div>
<div class='card'><h2>Долговременная память</h2><p>Состояние: {html.escape(str(memory.get('state', 'disabled')))} · сводок: {int(memory.get('summaries', 0))} · векторов сообщений: {int(memory.get('message_vectors', 0))}</p></div>
<div class='card'><h2>Диагностика</h2><p>База: работает · каталог: {catalog['count']} авто · модели: {html.escape(models['state'])}</p><small>{html.escape(models.get('last_error') or catalog.get('last_error') or 'Ошибок нет')}</small></div>
<div class='card'><h2>Добавить правило в базу знаний</h2><form method='post' action='/admin/knowledge'><label>Название</label><input name='title' required maxlength='150'><label>Текст правила</label><textarea name='body' rows='7' required></textarea><button type='submit'>Сохранить</button></form></div>
<div class='card'><h2>База знаний</h2><table><tr><th>ID</th><th>Раздел</th><th>Текст</th><th>Версия</th></tr>{knowledge_rows}</table></div>
<div class='card'><h2>Утверждённые цены китайских авто</h2><p><a href='/admin/prices' style='color:#e3c274'>Открыть удобное изменение цен →</a></p><form method='post' action='/admin/prices'><label>Марка и модель</label><input name='label' placeholder='Geely Monjaro' required maxlength='150'><label>Другие названия (через точку с запятой)</label><input name='matcher' placeholder='geely monjaro' required maxlength='150'><label>Как назвать цену клиенту</label><input name='price_text' placeholder='от 125 000 BYN — актуальность уточняется на площадке' required maxlength='300'><button type='submit'>Утвердить цену</button></form><table><tr><th>ID</th><th>Модель</th><th>Совпадение</th><th>Утверждённая цена</th></tr>{price_rows}</table></div>
<div class='card'><h2>Последние клиенты</h2><table><tr><th>Клиент</th><th>Канал</th><th>Режим</th><th>Статус</th></tr>{rows}</table></div>
<p><a style='color:#e3c274' href='/admin/logout'>Выйти</a></p></html>"""
