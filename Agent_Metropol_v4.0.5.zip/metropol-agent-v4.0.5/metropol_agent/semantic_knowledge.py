from __future__ import annotations

import hashlib
import json
import math
import time


def _hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _cosine(left: list[float], right: list[float]) -> float:
    if not left or len(left) != len(right):
        return 0.0
    denom = math.sqrt(sum(x * x for x in left)) * math.sqrt(sum(x * x for x in right))
    return sum(x * y for x, y in zip(left, right)) / denom if denom else 0.0


class SemanticKnowledge:
    """Hybrid knowledge retrieval. Any API/database problem falls back to keyword search."""

    def __init__(self, settings, db, knowledge, client):
        self.settings, self.db, self.knowledge, self.client = settings, db, knowledge, client
        self.cache: dict[str, tuple[float, list[float]]] = {}
        self.state = "pending" if self.enabled else "disabled"
        self.last_error = ""

    @property
    def enabled(self):
        return bool(self.client and (getattr(self.settings, "embedding_enabled", True)
                                    or getattr(self.settings, "memory_messages_enabled", True)))

    @property
    def knowledge_enabled(self):
        return bool(self.client and getattr(self.settings, "embedding_enabled", True))

    @property
    def messages_enabled(self):
        return bool(self.client and getattr(self.settings, "memory_messages_enabled", True))

    def _embed(self, text: str, event: str, client_id: int | None = None) -> list[float] | None:
        if not self.enabled:
            return None
        key = _hash(text)
        cached = self.cache.get(key)
        if cached and time.monotonic() - cached[0] < 900:
            return cached[1]
        if float(self.db.monthly_usage()["cost_usd"]) >= float(self.settings.monthly_budget_usd):
            self.state = "budget_limit"
            return None
        try:
            response = self.client.embeddings.create(model=self.settings.embedding_model, input=text[:8000])
            vector = list(response.data[0].embedding)
            usage = getattr(response, "usage", None)
            tokens = int(getattr(usage, "total_tokens", 0) or getattr(usage, "prompt_tokens", 0) or 0)
            self.db.record_usage(event, client_id, "embedding:" + self.settings.embedding_model,
                {"input_tokens": tokens, "output_tokens": 0, "cost_usd": tokens * float(self.settings.embedding_rate) / 1_000_000})
            self.cache[key] = (time.monotonic(), vector)
            self.state, self.last_error = "ok", ""
            return vector
        except Exception as exc:
            self.state, self.last_error = "fallback", f"{type(exc).__name__}: {exc}"[:300]
            return None

    def _sources(self):
        self.knowledge.reload_if_changed()
        file_rows = [("file", _hash(title + "\n" + body), title, body) for title, body in self.knowledge.sections]
        admin_rows = [("admin", str(row["id"]), row["title"], row["body"]) for row in self.db.knowledge_entries(1000)]
        return file_rows + admin_rows

    def backfill(self) -> int:
        if not self.enabled:
            return 0
        indexed = {(r["ref_type"], r["ref_key"]): r for r in self.db.knowledge_vectors()}
        sources = self._sources() if self.knowledge_enabled else []
        valid = {"file": set(), "admin": set()}
        added = 0
        for kind, key, title, body in sources:
            valid[kind].add(key)
            text = title + "\n" + body
            digest = _hash(text)
            if indexed.get((kind, key), {}).get("text_hash") == digest:
                continue
            vector = self._embed(text, f"embedding-index-{kind}-{key}-{digest[:12]}")
            if vector is None:
                break
            self.db.upsert_knowledge_vector(kind, key, digest, vector)
            added += 1
            time.sleep(0.05)
        self.db.prune_knowledge_vectors("file", valid["file"])
        self.db.prune_knowledge_vectors("admin", valid["admin"])
        added += self._backfill_messages(indexed)
        if self.enabled and self.state != "fallback":
            self.state = "ok"
        return added

    def _backfill_messages(self, indexed: dict) -> int:
        if not self.messages_enabled:
            return 0
        valid, added, after_id = set(), 0, 0
        minimum = int(getattr(self.settings, "memory_message_min_chars", 15))
        while True:
            rows = self.db.incoming_messages_page(after_id, 500)
            if not rows:
                break
            for row in rows:
                after_id = int(row["id"])
                text = " ".join(str(row["text"]).split())
                if len(text) < minimum:
                    continue
                key = f"{row['client_id']}:{row['id']}"
                valid.add(key)
                digest = _hash(text)
                if indexed.get(("message", key), {}).get("text_hash") == digest:
                    continue
                vector = self._embed(text, f"embedding-message-{key}-{digest[:12]}", int(row["client_id"]))
                if vector is None:
                    self.db.prune_knowledge_vectors("message", valid | {
                        r["ref_key"] for r in self.db.knowledge_vectors("message")
                        if int(r["ref_key"].split(":", 1)[1]) > after_id
                    })
                    return added
                self.db.upsert_knowledge_vector("message", key, digest, vector)
                added += 1
                time.sleep(0.02)
            if len(rows) < 500:
                break
        self.db.prune_knowledge_vectors("message", valid)
        return added

    def search(self, query: str, limit: int, max_chars: int) -> list[str]:
        fallback = self.knowledge.search(query, limit=limit, max_chars=max_chars)
        admin_fallback = self.db.search_knowledge(query, limit=limit)
        if not self.knowledge_enabled:
            return (fallback + admin_fallback)[:limit]
        vector = self._embed(query, "embedding-query-" + _hash(query)[:24] + "-" + str(int(time.time() // 900)))
        if vector is None:
            return (fallback + admin_fallback)[:limit]
        sources = {(kind, key): (title, body) for kind, key, title, body in self._sources()}
        keyword = fallback + admin_fallback
        ranked = []
        for row in self.db.knowledge_vectors():
            source = sources.get((row["ref_type"], row["ref_key"]))
            if not source:
                continue
            score = _cosine(vector, json.loads(row["vector"]))
            if score >= 0.20:
                piece = f"## {source[0]}\n{source[1]}"
                ranked.append((score, piece))
        ranked.sort(reverse=True)
        merged = [piece for _, piece in ranked] + keyword
        result, seen, total = [], set(), 0
        for piece in merged:
            digest = _hash(piece)
            if digest in seen:
                continue
            seen.add(digest)
            clipped = piece[:max(0, max_chars - total)]
            if not clipped:
                break
            result.append(clipped); total += len(clipped)
            if len(result) >= limit:
                break
        return result

    def search_messages(self, client_id: int, query: str, recent_ids: set[int]) -> list[str]:
        if not self.messages_enabled:
            return []
        vector = self._embed(
            query, f"embedding-memory-query-{client_id}-{_hash(query)[:20]}-{int(time.time() // 900)}", client_id)
        if vector is None:
            return []
        rows = self.db._execute(
            "SELECT * FROM knowledge_vectors WHERE ref_type='message' AND ref_key LIKE %s",
            (str(client_id) + ':%',), "all")
        ranked = []
        for row in rows:
            try:
                message_id = int(str(row["ref_key"]).split(":", 1)[1])
                if message_id in recent_ids:
                    continue
                score = _cosine(vector, json.loads(row["vector"]))
                if score >= float(getattr(self.settings, "memory_message_min_score", 0.35)):
                    ranked.append((score, message_id))
            except (ValueError, TypeError, json.JSONDecodeError):
                continue
        ranked.sort(reverse=True)
        limit = int(getattr(self.settings, "memory_message_max_hits", 5))
        ids = [message_id for _, message_id in ranked[:limit]]
        sources = {int(row["id"]): row for row in self.db.messages_by_ids(client_id, ids)}
        result, used = [], 0
        max_chars = int(getattr(self.settings, "memory_message_max_chars", 800))
        for message_id in ids:
            row = sources.get(message_id)
            if not row:
                continue
            try:
                date = str(row["created_at"])[8:10] + "." + str(row["created_at"])[5:7]
            except Exception:
                date = "ранее"
            text = " ".join(str(row["text"]).split())
            line = f'- [{date}] «{text}»'
            if result and used + len(line) > max_chars:
                break
            line = line[:max_chars - used]
            result.append(line)
            used += len(line)
        return result

    def status(self):
        vectors = self.db.knowledge_vectors()
        return {"enabled": self.enabled, "state": self.state, "model": getattr(self.settings, "embedding_model", ""),
                "vectors": sum(1 for row in vectors if row["ref_type"] != "message"),
                "message_vectors": sum(1 for row in vectors if row["ref_type"] == "message"),
                "last_error": self.last_error}
