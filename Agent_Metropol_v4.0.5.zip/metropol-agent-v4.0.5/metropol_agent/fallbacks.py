"""Customer-facing fallbacks without internal implementation details."""
import re


BUSINESS_FALLBACK = (
    "Затрудняюсь дать точный ответ, чтобы не вводить вас в заблуждение. "
    "Лучше уточнить напрямую у сотрудников Метрополь Авто:\n"
    "• Горецкого, 6А — +375 29 678-22-55\n"
    "• Мазурова, 1, БЦ «Камелот» — +375 44 722-22-55\n"
    "Обе площадки работают ежедневно с 9:00 до 20:00."
)

GENERAL_FALLBACK = (
    "Сейчас не получилось надёжно проверить актуальную информацию. "
    "Попробуйте спросить немного позже."
)

_UNCERTAIN = re.compile(
    r"(?:не\s+знаю\s+(?:ответа|точно|этого|такой\s+информации)|"
    r"не\s+наш[её]л\s+(?:информац\w*|сведен\w*|данн\w*)|"
    r"не\s+могу\s+(?:найти|проверить|подтвердить|ответить)|"
    r"не\s+удалось\s+(?:найти|проверить|подтвердить|получить|подготовить)|"
    r"затрудняюсь\s+(?:ответить|дать)|неподтвержд[её]нн\w*\s+информац)",
    re.I,
)


def needs_business_fallback(text: str) -> bool:
    return bool(_UNCERTAIN.search(text or ""))


def is_fallback(text: str) -> bool:
    value = text or ""
    return value.startswith(BUSINESS_FALLBACK) or value.startswith(GENERAL_FALLBACK) or needs_business_fallback(value)
