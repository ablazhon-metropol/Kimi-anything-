"""Fault-isolated long-term conversation memory for one client at a time."""
from __future__ import annotations

import json
import logging
import re
from datetime import datetime

log = logging.getLogger(__name__)


SUMMARY_INSTRUCTION = """Ты сжимаешь историю переписки автосалона с клиентом. Верни строго JSON:
{"summary": "...", "profile": {...}}.

Правила для summary (русский, до 1000 символов, список тезисов):
- что клиент ищет: марки/модели, новый или б/у, рассматривал ли пригон;
- его ситуация: сроки решения, первое авто/замена, состав семьи если упоминал;
- до чего договорились: назначенный визит, обещания менеджера, открытые вопросы;
- возражения и сомнения клиента дословно кратко;
- ЗАПРЕЩЕНО: конкретные цены, скидки, платежи по кредиту (устаревают),
  приветствия, переписку ни о чём, пересказ ответов агента дословно.
Если предыдущая сводка есть — дополни её новым, удали потерявшее силу.
Профиль заполняй только явно сказанными клиентом сведениями. Не выдумывай пустые поля.
profile должен содержать ровно эти поля:
{"budget_max_byn": null, "trade_in": null, "decision_timeframe": null,
 "objections": [], "promises": [], "visit": null, "contact_phone": null}.
decision_timeframe допускает только: «сразу», «1-2 недели», «месяц+», «присматривается»."""


PROFILE_KEYS = (
    "budget_max_byn", "trade_in", "decision_timeframe", "objections",
    "promises", "visit", "contact_phone",
)


def _clip_summary(value: str, limit: int) -> str:
    # Prices and payments are deliberately excluded because they become stale.
    lines = []
    money = re.compile(r"(?:\d[\d\s.,]*\s*(?:BYN|руб\w*|доллар\w*|USD|EUR|€|\$)|(?:цена|плат[её]ж|скидк)\w*\s*[:—-]?\s*\d)", re.I)
    for line in str(value or "").splitlines():
        if line.strip() and not money.search(line):
            lines.append(line.strip())
    text = "\n".join(lines).strip()
    if len(text) <= limit:
        return text
    clipped = text[:limit + 1]
    boundary = max(clipped.rfind(". ", 0, limit), clipped.rfind("\n", 0, limit))
    return clipped[:boundary + 1].strip() if boundary >= max(80, limit // 2) else text[:limit].rstrip()


def _profile(value) -> dict:
    source = value if isinstance(value, dict) else {}
    result = {key: None if key not in {"objections", "promises"} else [] for key in PROFILE_KEYS}
    budget = source.get("budget_max_byn")
    if isinstance(budget, str):
        digits = re.sub(r"\D", "", budget)
        budget = int(digits) if digits else None
    if isinstance(budget, (int, float)) and 0 < budget < 1_000_000_000:
        result["budget_max_byn"] = int(budget)
    timeframe = source.get("decision_timeframe")
    if timeframe in {"сразу", "1-2 недели", "месяц+", "присматривается"}:
        result["decision_timeframe"] = timeframe
    for key in ("trade_in", "visit", "contact_phone"):
        item = source.get(key)
        if isinstance(item, str) and item.strip():
            result[key] = item.strip()[:300]
    for key in ("objections", "promises"):
        items = source.get(key)
        if isinstance(items, list):
            result[key] = [str(item).strip()[:240] for item in items[:8] if str(item).strip()]
    return result


class ConversationMemory:
    def __init__(self, settings, db, ai, preferences, semantic=None):
        self.settings, self.db, self.ai = settings, db, ai
        self.preferences, self.semantic = preferences, semantic
        self.state = "pending" if self.enabled else "disabled"
        self.last_error = ""

    @property
    def enabled(self) -> bool:
        return bool((getattr(self.settings, "memory_summary_enabled", True)
                     or getattr(self.settings, "memory_profile_enabled", True))
                    and getattr(self.ai, "client", None))

    def refresh_due(self, limit: int = 10) -> int:
        if not self.enabled:
            self.state = "disabled"
            return 0
        cursor = int(self.db.get_setting("memory-summary-client-cursor") or 0)
        rows = self.db._execute(
            "SELECT DISTINCT client_id FROM messages WHERE client_id>%s ORDER BY client_id LIMIT %s",
            (cursor, limit), "all")
        if not rows:
            self.db.set_setting("memory-summary-client-cursor", "0")
            return 0
        updated = 0
        for row in rows:
            try:
                updated += int(self.refresh_client(int(row["client_id"])))
            except Exception as exc:  # memory must never stop reply workers
                self.state = "fallback"
                self.last_error = f"{type(exc).__name__}: {exc}"[:300]
                log.exception("Conversation memory refresh failed for client %s", row["client_id"])
        self.db.set_setting("memory-summary-client-cursor", str(rows[-1]["client_id"]))
        return updated

    def refresh_client(self, client_id: int) -> bool:
        if not self.enabled:
            return False
        previous = self.db.conversation_summary(client_id)
        after_id = int((previous or {}).get("summarized_until_id") or 0)
        previous_text = (previous or {}).get("summary") or "нет"
        batch_chars = max(2000, 7600 - len(previous_text))
        rows = self.db.messages_for_summary(
            client_id, after_id, int(getattr(self.settings, "history_messages", 30)), batch_chars)
        if len(rows) < int(getattr(self.settings, "memory_summary_every", 20)):
            return False
        if float(self.db.monthly_usage()["cost_usd"]) >= float(self.settings.monthly_budget_usd):
            self.state = "budget_limit"
            return False
        transcript = "\n".join(
            f"{row['id']} · {'Клиент' if row['direction'] == 'in' else 'Агент'}: {row['text']}"
            for row in rows
        )[-8000:]
        prefix = "Предыдущая сводка:\n" + previous_text + "\n\nНовые сообщения:\n"
        prompt = prefix + transcript[:max(0, 8000 - len(prefix))]
        model = getattr(self.settings, "memory_summary_model", "") or self.settings.luna_model
        boundary = int(rows[-1]["id"])
        try:
            client = self.ai.client.with_options(max_retries=0, timeout=30)
            response = client.responses.create(
                model=model, instructions=SUMMARY_INSTRUCTION, input=prompt,
                reasoning={"effort": "none"}, max_output_tokens=650, store=False)
            raw = getattr(response, "usage", None)
            input_tokens = int(getattr(raw, "input_tokens", 0) or 0)
            output_tokens = int(getattr(raw, "output_tokens", 0) or 0)
            input_rate, output_rate = self.ai._rates(model, "luna")
            usage = {"input_tokens": input_tokens, "output_tokens": output_tokens,
                     "cost_usd": (input_tokens * input_rate + output_tokens * output_rate) / 1_000_000}
            self.db.record_usage(f"memory-summary-{client_id}-{boundary}", client_id,
                                 model + ":summary", usage)
            payload = json.loads(str(getattr(response, "output_text", "") or "").strip())
            if not isinstance(payload, dict) or not isinstance(payload.get("summary"), str):
                raise ValueError("invalid summary JSON")
            summary = _clip_summary(payload["summary"], int(getattr(self.settings, "memory_summary_max_chars", 1200)))
            if not summary:
                raise ValueError("empty summary")
            # The row also serves as the progress marker when only profile context is enabled.
            self.db.save_conversation_summary(client_id, summary, boundary)
            if getattr(self.settings, "memory_profile_enabled", True):
                self.preferences.save_profile(f"client:{client_id}", _profile(payload.get("profile")))
            self.state, self.last_error = "ok", ""
            return True
        except Exception as exc:
            self.state = "fallback"
            self.last_error = f"{type(exc).__name__}: {exc}"[:300]
            log.warning("Conversation summary was not saved for client %s: %s", client_id, type(exc).__name__)
            return False

    def context(self, client_id: int | None, query: str, recent_history: list[dict]) -> str:
        if client_id is None:
            return ""
        blocks = []
        if getattr(self.settings, "memory_profile_enabled", True):
            profile = self.preferences.profile_context(f"client:{client_id}")
            if profile:
                blocks.append("Профиль клиента (справочно, не источник цен и наличия):\n" + profile)
        if getattr(self.settings, "memory_summary_enabled", True):
            summary = self.db.conversation_summary(client_id)
            if summary and summary.get("summary"):
                blocks.append("Память о клиенте (справочно, не источник цен и наличия):\n" + summary["summary"])
        if getattr(self.settings, "memory_messages_enabled", True) and self.semantic is not None:
            live = int(getattr(self.settings, "history_messages", 60))
            recent_ids = {int(row["id"]) for row in recent_history[-live:] if row.get("id") is not None}
            try:
                old = self.semantic.search_messages(client_id, query, recent_ids)
            except Exception as exc:
                self.state = "fallback"
                self.last_error = f"{type(exc).__name__}: {exc}"[:300]
                old = []
            if old:
                blocks.append("Из прошлых разговоров с этим клиентом (справочно):\n" + "\n".join(old))
        if blocks:
            blocks.append("Память — только контекст. Цены, наличие, платежи и условия бери только из инструментов текущего хода.")
        return "\n\n".join(blocks)

    def status(self) -> dict:
        summaries = self.db._execute("SELECT COUNT(*) AS n FROM conversation_summaries", fetch="one")["n"]
        vectors = self.db._execute(
            "SELECT COUNT(*) AS n FROM knowledge_vectors WHERE ref_type='message'", fetch="one")["n"]
        return {"enabled": self.enabled, "state": self.state, "summaries": int(summaries),
                "message_vectors": int(vectors), "last_error": self.last_error}
