import unittest
from datetime import datetime
from zoneinfo import ZoneInfo

import test_reliability as reliability
import test_v390 as v390
import test_v401 as v401
from metropol_agent.fallbacks import BUSINESS_FALLBACK, GENERAL_FALLBACK
from metropol_agent.owner_stats import OwnerStats
from metropol_agent.exchange import ExchangeRates


class Release405(unittest.TestCase):
    setUp = reliability.ReliabilityTests.setUp
    tearDown = reliability.ReliabilityTests.tearDown

    def app(self, responses=()):
        return v401.Adaptive401.app(self, responses)

    def answer(self, app, query, history=(), event='v405'):
        return app._prepare_answer(query, list(history), 1, None, event)

    def test_business_search_failure_gives_both_real_contacts(self):
        app = self.app([
            v390.response(tool='internet_search', args={'query':'условия услуги для автомобиля'}),
            RuntimeError('temporary'), RuntimeError('temporary retry'),
            v390.response('Ничего не найдено.'),
        ])
        text = self.answer(app, 'Найди актуальные условия услуги для автомобиля')[0]
        self.assertTrue(text.startswith(BUSINESS_FALLBACK))
        self.assertIn('+375 29 678-22-55', text)
        self.assertIn('+375 44 722-22-55', text)
        self.assertNotIn('интернет', text.lower())

    def test_general_search_failure_has_no_dealership_phone(self):
        app = self.app([
            v390.response(tool='internet_search', args={'query':'Новости мира сегодня'}),
            RuntimeError('temporary'), RuntimeError('temporary retry'),
            v390.response('Ничего не найдено.'),
        ])
        text = self.answer(app, 'Какие новости сегодня?')[0]
        self.assertTrue(text.startswith(GENERAL_FALLBACK))
        self.assertNotIn('+375', text)
        self.assertNotIn('интернет', text.lower())

    def test_ai_unavailable_uses_complete_business_fallback(self):
        app = self.app()
        app.ai.client = None
        text = self.answer(app, 'Расскажите о нестандартной услуге Метрополь Авто')[0]
        self.assertIn('+375 29 678-22-55', text)
        self.assertIn('+375 44 722-22-55', text)

    def test_ordinary_dialogue_keeps_full_live_window_and_older_customer_memory(self):
        history = []
        for index in range(20):
            incoming = 'Мне важен автомобиль с большим багажником' if index == 0 else f'Вопрос клиента {index}'
            history.extend((
                {'direction':'in', 'text':incoming},
                {'direction':'out', 'text':f'Ответ агента {index}'},
            ))
        app = self.app([v390.response('[[TOPIC:offtopic]]Помню ваш разговор.')])
        self.answer(app, 'Что я говорил раньше?', history)
        call = app.ai.client.calls[0]
        self.assertEqual(len(call['input']), 30)
        self.assertIn('Мне важен автомобиль с большим багажником', call['instructions'])

    def test_agent_events_are_idempotent_and_grouped_by_channel(self):
        self.db.record_agent_event('r1', None, 'test', 'gpt-5.6-luna', 'answered', {'cost_usd':.01})
        self.db.record_agent_event('r1', None, 'test', 'gpt-5.6-luna', 'fallback', {'cost_usd':.99})
        client = self.db.upsert_client('instagram-1', 'Клиент', '', 'auto')
        self.db._execute('UPDATE clients SET channel=%s WHERE id=%s', ('instagram', client['id']))
        self.db.record_agent_event('r2', client['id'], 'instagram', 'gpt-5.6-luna', 'fallback', {'cost_usd':.02})
        stats = self.db.stats()
        self.assertEqual(stats['responses_24h'], 2)
        self.assertEqual(stats['fallbacks_24h'], 1)
        text = OwnerStats(self.db, app_catalog(self.db), ExchangeRates(self.db), '4.0.5').render('monitoring')
        self.assertIn('instagram', text)
        self.assertIn('test', text)

    def test_daily_monitoring_report_is_sent_only_once(self):
        app = self.app()
        app.settings.owner_id = 777
        current = datetime(2026, 9, 8, 20, 30, tzinfo=ZoneInfo('Europe/Minsk'))
        self.assertEqual(app.send_daily_monitoring_report(current), 1)
        self.assertEqual(app.send_daily_monitoring_report(current), 0)
        row = self.db._execute(
            "SELECT text FROM outbox WHERE dedupe_key=%s", ('daily-monitoring-2026-09-08',), 'one')
        self.assertIn('Контроль ответов по каналам', row['text'])


def app_catalog(db):
    from metropol_agent.catalog import Catalog
    return Catalog(db)


if __name__ == '__main__':
    unittest.main()
