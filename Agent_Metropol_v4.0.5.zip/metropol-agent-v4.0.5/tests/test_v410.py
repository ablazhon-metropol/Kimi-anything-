import json
import unittest
from types import SimpleNamespace

import test_reliability as reliability
import test_v390 as v390
import test_v401 as v401
from metropol_agent.ai import AIEngine
from metropol_agent.catalog import Catalog
from metropol_agent.knowledge import KnowledgeBase
from metropol_agent.semantic_knowledge import SemanticKnowledge


class Embeddings:
    def __init__(self):
        self.calls = []

    def create(self, model, input):
        self.calls.append(input)
        return SimpleNamespace(
            data=[SimpleNamespace(embedding=[1.0, 0.0])],
            usage=SimpleNamespace(total_tokens=5),
        )


class Release410(unittest.TestCase):
    setUp = reliability.ReliabilityTests.setUp
    tearDown = reliability.ReliabilityTests.tearDown

    def app(self, responses=()):
        app = v401.Adaptive401.app(self, responses)
        cfg = app.settings
        cfg.history_messages = 5
        cfg.memory_summary_enabled = True
        cfg.memory_summary_model = 'gpt-5.6-luna'
        cfg.memory_summary_max_chars = 120
        cfg.memory_summary_every = 20
        cfg.memory_profile_enabled = True
        cfg.memory_messages_enabled = True
        cfg.memory_message_min_chars = 15
        cfg.memory_message_min_score = .35
        cfg.memory_message_max_hits = 5
        cfg.memory_message_max_chars = 800
        return app

    def add_dialogue(self, client_id, start, count):
        for index in range(start, start + count):
            self.db.add_message(f'm-{client_id}-{index}', client_id, 'in', f'Сообщение клиента номер {index} про автомобиль')

    def summary_response(self, summary='- Ищет красный автомобиль для семьи.', profile=None):
        payload = {'summary': summary, 'profile': profile or {}}
        return v390.response(json.dumps(payload, ensure_ascii=False))

    def semantic(self, app):
        app.settings.embedding_enabled = False
        app.settings.embedding_model = 'text-embedding-3-small'
        app.settings.embedding_rate = .02
        client = SimpleNamespace(embeddings=Embeddings())
        return SemanticKnowledge(app.settings, self.db, KnowledgeBase('knowledge/metropol.md'), client)

    def test_01_summary_threshold_limit_and_no_stale_money(self):
        client = self.db.upsert_client('410-1', 'Клиент', '', 'auto')
        self.add_dialogue(client['id'], 0, 25)
        app = self.app([self.summary_response(
            '- Цена 80 000 BYN обсуждалась.\n- Ищет красный семейный автомобиль с большим багажником и автоматом.')])
        self.assertTrue(app.memory.refresh_client(client['id']))
        row = self.db.conversation_summary(client['id'])
        self.assertLessEqual(len(row['summary']), app.settings.memory_summary_max_chars)
        self.assertNotRegex(row['summary'], r'80\s*000\s*BYN')

    def test_02_repeated_summary_moves_boundary_and_uses_previous(self):
        client = self.db.upsert_client('410-2', 'Клиент', '', 'auto')
        self.add_dialogue(client['id'], 0, 25)
        app = self.app([self.summary_response('- Ищет Volvo.'), self.summary_response('- Теперь ищет Peugeot.')])
        self.assertTrue(app.memory.refresh_client(client['id']))
        first = self.db.conversation_summary(client['id'])
        self.add_dialogue(client['id'], 25, 20)
        self.assertTrue(app.memory.refresh_client(client['id']))
        second = self.db.conversation_summary(client['id'])
        self.assertGreater(second['summarized_until_id'], first['summarized_until_id'])
        self.assertIn('Ищет Volvo', app.ai.client.calls[1]['input'])

    def test_03_summary_failure_does_not_block_delivered_answer(self):
        client = self.db.upsert_client('410-3', 'Клиент', '', 'auto')
        self.add_dialogue(client['id'], 0, 25)
        app = self.app([RuntimeError('summary offline')])
        self.db.enqueue_outbox(client['external_id'], 'Полный ответ клиенту',
            metadata={'direction':'out', 'client_id':client['id'], 'event_id':'delivered', 'model':'luna'})
        self.assertEqual(app.process_outbox(), 1)
        self.assertFalse(app.memory.refresh_client(client['id']))
        self.assertEqual(app.telegram.sent[0][1], 'Полный ответ клиенту')
        self.assertIsNone(self.db.conversation_summary(client['id']))

    def test_04_profile_extracts_only_supplied_fields(self):
        client = self.db.upsert_client('410-4', 'Клиент', '', 'auto')
        self.add_dialogue(client['id'], 0, 25)
        profile = {'budget_max_byn': 80000, 'trade_in': 'Geely Coolray 2021',
                   'decision_timeframe': None, 'objections': [], 'promises': [],
                   'visit': None, 'contact_phone': None}
        app = self.app([self.summary_response(profile=profile)])
        self.assertTrue(app.memory.refresh_client(client['id']))
        saved = app.preferences.profile(f"client:{client['id']}")
        self.assertEqual(saved['budget_max_byn'], 80000)
        self.assertEqual(saved['trade_in'], 'Geely Coolray 2021')
        self.assertIsNone(saved['contact_phone'])

    def test_05_forget_selection_removes_profile_too(self):
        app = self.app()
        app.preferences.save_profile('client:5', {'trade_in':'Coolray 2021'})
        app.preferences.update('client:5', 'Забудь подбор', [])
        self.assertEqual(app.preferences.get('client:5'), {})

    def test_06_message_vectors_only_incoming_long_and_embed_once(self):
        client = self.db.upsert_client('410-6', 'Клиент', '', 'auto')
        self.db.add_message('short', client['id'], 'in', 'Ок')
        self.db.add_message('long-in', client['id'], 'in', 'Жена хочет красный автомобиль')
        self.db.add_message('long-out', client['id'], 'out', 'Агент ответил достаточно длинным сообщением')
        app = self.app()
        semantic = self.semantic(app)
        self.assertEqual(semantic.backfill(), 1)
        calls = len(semantic.client.embeddings.calls)
        self.assertEqual(semantic.backfill(), 0)
        self.assertEqual(len(semantic.client.embeddings.calls), calls)
        self.assertEqual(len(self.db.knowledge_vectors('message')), 1)

    def test_07_semantic_memory_isolated_between_clients(self):
        first = self.db.upsert_client('410-a', 'А', '', 'auto')
        second = self.db.upsert_client('410-b', 'Б', '', 'auto')
        self.db.add_message('a-long', first['id'], 'in', 'Жена хочет красный автомобиль')
        self.db.add_message('b-long', second['id'], 'in', 'Другой клиент хочет только чёрный внедорожник')
        semantic = self.semantic(self.app())
        semantic.backfill()
        result = '\n'.join(semantic.search_messages(first['id'], 'цвет автомобиля', set()))
        self.assertIn('красный', result)
        self.assertNotIn('чёрный', result)

    def test_08_deleted_message_vector_is_pruned(self):
        client = self.db.upsert_client('410-8', 'Клиент', '', 'auto')
        self.db.add_message('prune-me', client['id'], 'in', 'Старое пожелание надо удалить')
        semantic = self.semantic(self.app())
        semantic.backfill()
        self.assertEqual(len(self.db.knowledge_vectors('message')), 1)
        self.db._execute("DELETE FROM messages WHERE event_id=%s", ('prune-me',))
        semantic.backfill()
        self.assertEqual(self.db.knowledge_vectors('message'), [])

    def test_09_all_memory_flags_disable_new_work_and_prompt_blocks(self):
        app = self.app([v390.response('Обычный ответ.')])
        app.settings.memory_summary_enabled = False
        app.settings.memory_profile_enabled = False
        app.settings.memory_messages_enabled = False
        history = [{'direction':'in', 'text':'старое сообщение'}] * 40
        app._prepare_answer('Как дела?', history, 1, None, 'flags-off')
        instructions = app.ai.client.calls[0]['instructions']
        self.assertNotIn('Память о клиенте', instructions)
        self.assertNotIn('Более ранние сообщения', instructions)
        self.assertEqual(app.memory.refresh_due(), 0)

    def test_10_summary_from_early_dialogue_reaches_live_prompt(self):
        client = self.db.upsert_client('410-10', 'Клиент', '', 'auto')
        app = self.app([v390.response('Учту это пожелание.')])
        self.add_dialogue(client['id'], 0, 205)
        self.db.save_conversation_summary(client['id'], '- Красный автомобиль нужен для жены; бюджет обсуждать без старых цифр.', 20)
        history = self.db.recent_messages(client['id'], 80)
        app._prepare_answer('Что я говорил раньше?', history, 1, client['id'], 'memory-live')
        instructions = app.ai.client.calls[0]['instructions']
        self.assertIn('Красный автомобиль нужен для жены', instructions)
        self.assertIn('не источник цен и наличия', instructions)


if __name__ == '__main__':
    unittest.main()
